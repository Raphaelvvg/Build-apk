import React from 'react';
import { X, Settings, Mouse, Cpu, Monitor, Shield, Check } from 'lucide-react';
import { BlueStacksSettings } from '../types/bluestacks';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  settings: BlueStacksSettings;
  onUpdateSettings: (updated: Partial<BlueStacksSettings>) => void;
}

export const BlueStacksSettingsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm select-none">
      <div className="bg-[#0e1626] border-2 border-[#1f2d48] rounded-2xl w-full max-w-lg shadow-2xl text-white overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 bg-[#0b101b] border-b border-[#1f2d48] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#0084ff]/20 border border-[#0084ff] flex items-center justify-center text-[#0084ff]">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">
                Configurações do BlueStacks
              </h3>
              <span className="text-[10px] text-[#94a3b8] font-mono">
                Desempenho, Taxa de Polling e Preferências de Exibição
              </span>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded text-[#94a3b8] hover:text-white hover:bg-[#1a263c]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {/* Polling Rate */}
          <div className="p-3.5 rounded-xl bg-[#131d31] border border-[#1f2d48] space-y-2">
            <div className="flex items-center gap-2 text-white font-bold text-xs">
              <Mouse className="w-4 h-4 text-[#0084ff]" />
              Taxa de Polling do Mouse (Hardware Rate)
            </div>
            <p className="text-[10px] text-[#64748b]">
              Taxas mais altas reduzem o jitter e garantem resposta instantânea no Free Fire:
            </p>
            <div className="grid grid-cols-3 gap-2 pt-1">
              {([500, 800, 1000] as const).map((hz) => (
                <button
                  key={hz}
                  onClick={() => onUpdateSettings({ mousePollingHz: hz })}
                  className={`py-2 rounded-lg font-bold text-xs transition border ${
                    settings.mousePollingHz === hz
                      ? 'bg-[#0084ff] text-white border-[#38bdf8] shadow'
                      : 'bg-[#162238] text-[#94a3b8] border-[#233554] hover:text-white'
                  }`}
                >
                  {hz} Hz {hz === 1000 ? '⚡ (1ms)' : ''}
                </button>
              ))}
            </div>
          </div>

          {/* Cursor Style */}
          <div className="p-3.5 rounded-xl bg-[#131d31] border border-[#1f2d48] space-y-2">
            <span className="text-white font-bold text-xs block">
              Estilo do Cursor do BlueStacks
            </span>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'classic', label: 'Clássico BlueStacks' },
                { id: 'yellow', label: 'Amarelo Pro Gamer' },
                { id: 'gamer_crosshair', label: 'Mira FPS Crosshair' },
                { id: 'neon_blue', label: 'Azul Neon Futurista' }
              ].map((c) => (
                <button
                  key={c.id}
                  onClick={() => onUpdateSettings({ cursorStyle: c.id as any })}
                  className={`p-2 rounded-lg text-xs font-semibold text-left transition border ${
                    settings.cursorStyle === c.id
                      ? 'bg-[#0084ff]/30 text-white border-[#0084ff]'
                      : 'bg-[#162238] text-[#94a3b8] border-[#233554] hover:text-white'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* FPS Limit */}
          <div className="p-3.5 rounded-xl bg-[#131d31] border border-[#1f2d48] space-y-2">
            <div className="flex items-center gap-2 text-white font-bold text-xs">
              <Monitor className="w-4 h-4 text-emerald-400" />
              Taxa de Quadros (FPS)
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {([60, 90, 120, 240] as const).map((fps) => (
                <button
                  key={fps}
                  onClick={() => onUpdateSettings({ fpsLimit: fps })}
                  className={`py-1.5 rounded-lg font-bold text-xs font-mono transition border ${
                    settings.fpsLimit === fps
                      ? 'bg-emerald-500 text-black border-emerald-400 shadow'
                      : 'bg-[#162238] text-[#94a3b8] border-[#233554] hover:text-white'
                  }`}
                >
                  {fps} FPS
                </button>
              ))}
            </div>
          </div>

          {/* Engine Optimizations */}
          <div className="p-3.5 rounded-xl bg-[#131d31] border border-[#1f2d48] space-y-2.5">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-white font-bold text-xs block">
                  Modo de Baixa Latência (Ultra Low Latency)
                </span>
                <span className="text-[10px] text-[#64748b]">
                  Reduz o atraso de injeção de toques para menos de 0.5ms
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.lowLatencyEngine}
                onChange={(e) => onUpdateSettings({ lowLatencyEngine: e.target.checked })}
                className="w-4 h-4 accent-[#0084ff] rounded"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#0b101b] border-t border-[#1f2d48] flex justify-end">
          <button
            onClick={onClose}
            className="py-2 px-6 rounded-lg bg-[#0084ff] hover:bg-[#0074e0] text-white font-bold text-xs shadow flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" />
            Salvar e Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
