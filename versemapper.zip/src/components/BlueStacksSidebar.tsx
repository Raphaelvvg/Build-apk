import React, { useState } from 'react';
import {
  Maximize2,
  Volume2,
  VolumeX,
  Keyboard,
  Sliders,
  Play,
  RotateCw,
  Camera,
  FolderOpen,
  Settings,
  MousePointer,
  Zap,
  Eye,
  EyeOff,
  Crosshair,
  Layers,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface Props {
  isEditorOpen: boolean;
  onToggleEditor: () => void;
  showControlsOnScreen: boolean;
  onToggleShowControls: () => void;
  hudOpacity: number;
  onChangeHudOpacity: (val: number) => void;
  onOpenMacroManager: () => void;
  onOpenSettings: () => void;
  onTakeScreenshot: () => void;
  isPointerLocked: boolean;
  onTogglePointerLock: () => void;
  activeSchemeName: string;
}

export const BlueStacksSidebar: React.FC<Props> = ({
  isEditorOpen,
  onToggleEditor,
  showControlsOnScreen,
  onToggleShowControls,
  hudOpacity,
  onChangeHudOpacity,
  onOpenMacroManager,
  onOpenSettings,
  onTakeScreenshot,
  isPointerLocked,
  onTogglePointerLock,
  activeSchemeName
}) => {
  const [showQuickMenu, setShowQuickMenu] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  return (
    <aside className="w-11 bg-[#0b101b] border-l border-[#1b263b] flex flex-col items-center py-2 justify-between z-30 select-none">
      {/* Top action icons */}
      <div className="flex flex-col items-center gap-1 w-full">
        {/* Fullscreen (F11) */}
        <button
          onClick={() => {
            if (!document.fullscreenElement) {
              document.documentElement.requestFullscreen().catch(() => {});
            } else {
              document.exitFullscreen().catch(() => {});
            }
          }}
          className="w-8 h-8 rounded-lg flex items-center justify-center text-[#94a3b8] hover:text-white hover:bg-[#1a263c] transition relative group"
          title="Alternar Tela Cheia (F11)"
        >
          <Maximize2 className="w-4 h-4" />
          <span className="absolute right-10 px-2 py-1 bg-black/95 text-white text-[10px] rounded shadow-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-[#223554]">
            Tela Cheia (F11)
          </span>
        </button>

        {/* Volume */}
        <button
          onClick={() => setIsMuted(!isMuted)}
          className="w-8 h-8 rounded-lg flex items-center justify-center text-[#94a3b8] hover:text-white hover:bg-[#1a263c] transition relative group"
          title={isMuted ? 'Desmutar' : 'Volume do Jogo'}
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
          <span className="absolute right-10 px-2 py-1 bg-black/95 text-white text-[10px] rounded shadow-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-[#223554]">
            {isMuted ? 'Volume: Mudo' : 'Volume: 100%'}
          </span>
        </button>

        {/* Lock Cursor / Pointer Lock (F1 / F10) */}
        <button
          onClick={onTogglePointerLock}
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition relative group ${
            isPointerLocked
              ? 'bg-[#0084ff] text-white shadow-[0_0_12px_rgba(0,132,255,0.7)]'
              : 'text-[#94a3b8] hover:text-white hover:bg-[#1a263c]'
          }`}
          title="Travar / Liberar Cursor do Mouse (F1 ou F10)"
        >
          <Crosshair className="w-4 h-4" />
          <span className="absolute right-10 px-2 py-1 bg-black/95 text-white text-[10px] rounded shadow-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-[#223554]">
            {isPointerLocked ? 'Cursor Travado (Pressione F1 para liberar)' : 'Travar Cursor no Jogo (F1)'}
          </span>
        </button>

        <div className="w-6 h-[1px] bg-[#1e2a40] my-1" />

        {/* CONTROLS EDITOR BUTTON (ICONIC BLUESTACKS KEYBOARD ICON - Ctrl+Shift+A) */}
        <div className="relative">
          <button
            onClick={onToggleEditor}
            className={`w-8 h-8 rounded-lg flex items-center justify-center transition relative group ${
              isEditorOpen
                ? 'bg-[#0084ff] text-white shadow-[0_0_15px_rgba(0,132,255,0.8)]'
                : 'text-[#94a3b8] hover:text-white hover:bg-[#1a263c]'
            }`}
            title="Controles do Jogo (Ctrl+Shift+A) - Clique para abrir o Editor de Controles"
          >
            <Keyboard className="w-4 h-4" />
            <span className="absolute right-10 px-2 py-1 bg-black/95 text-white text-[10px] rounded shadow-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-[#223554]">
              Editor de Controles (Ctrl+Shift+A)
            </span>
          </button>
        </div>

        {/* Quick Game Controls Floating Mini-Panel Trigger */}
        <button
          onClick={() => setShowQuickMenu(!showQuickMenu)}
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition relative group ${
            showQuickMenu
              ? 'bg-[#1e293b] text-cyan-400'
              : 'text-[#94a3b8] hover:text-white hover:bg-[#1a263c]'
          }`}
          title="Menu Rápido de Controles"
        >
          <Sliders className="w-4 h-4" />
          <span className="absolute right-10 px-2 py-1 bg-black/95 text-white text-[10px] rounded shadow-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-[#223554]">
            Opacidade e Controles Rápidos
          </span>
        </button>

        {/* Quick Menu Popover (Same as BlueStacks 5 game controls flyout) */}
        {showQuickMenu && (
          <div className="absolute right-12 top-28 z-50 w-64 bg-[#0d1524] border border-[#233554] rounded-xl p-3.5 shadow-2xl text-xs space-y-3 backdrop-blur-md">
            <div className="flex items-center justify-between pb-2 border-b border-[#1f2d48]">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Keyboard className="w-4 h-4 text-[#0084ff]" />
                Controles do Jogo
              </span>
              <button
                onClick={() => setShowQuickMenu(false)}
                className="text-[#64748b] hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            {/* Toggle on-screen controls */}
            <div className="flex items-center justify-between">
              <span className="text-[#cbd5e1] text-[11px]">Controles na tela</span>
              <button
                onClick={onToggleShowControls}
                className={`w-9 h-5 rounded-full transition-colors relative flex items-center px-0.5 ${
                  showControlsOnScreen ? 'bg-[#0084ff]' : 'bg-[#334155]'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white shadow-md transform transition-transform ${
                    showControlsOnScreen ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Opacity slider */}
            <div>
              <div className="flex items-center justify-between text-[11px] text-[#94a3b8] mb-1">
                <span>Opacidade dos botões</span>
                <span className="font-mono text-white font-bold">{hudOpacity}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={hudOpacity}
                onChange={(e) => onChangeHudOpacity(parseInt(e.target.value))}
                className="w-full h-1.5 bg-[#1f2d48] rounded-lg appearance-none cursor-pointer accent-[#0084ff]"
              />
            </div>

            <div className="pt-2 border-t border-[#1f2d48] flex flex-col gap-2">
              <div className="text-[10px] text-[#94a3b8] truncate">
                Esquema: <b className="text-white">{activeSchemeName}</b>
              </div>

              <button
                onClick={() => {
                  setShowQuickMenu(false);
                  onToggleEditor();
                }}
                className="w-full py-2 bg-[#0084ff] hover:bg-[#0074e0] text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition shadow"
              >
                <Sliders className="w-3.5 h-3.5" />
                Abrir Editor Avançado
              </button>
            </div>
          </div>
        )}

        {/* Macro Manager (Ctrl + Shift + 7) */}
        <button
          onClick={onOpenMacroManager}
          className="w-8 h-8 rounded-lg flex items-center justify-center text-[#94a3b8] hover:text-white hover:bg-[#1a263c] transition relative group"
          title="Gerenciador de Macros (Ctrl+Shift+7)"
        >
          <Zap className="w-4 h-4 text-amber-400" />
          <span className="absolute right-10 px-2 py-1 bg-black/95 text-white text-[10px] rounded shadow-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-[#223554]">
            Gravador de Macro (Ctrl+Shift+7)
          </span>
        </button>

        {/* Screenshot */}
        <button
          onClick={onTakeScreenshot}
          className="w-8 h-8 rounded-lg flex items-center justify-center text-[#94a3b8] hover:text-white hover:bg-[#1a263c] transition relative group"
          title="Capturar Tela (Ctrl+Shift+S)"
        >
          <Camera className="w-4 h-4" />
          <span className="absolute right-10 px-2 py-1 bg-black/95 text-white text-[10px] rounded shadow-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-[#223554]">
            Capturar Tela (Screenshot)
          </span>
        </button>
      </div>

      {/* Bottom Settings Button */}
      <div className="flex flex-col items-center gap-1 w-full">
        <button
          onClick={onOpenSettings}
          className="w-8 h-8 rounded-lg flex items-center justify-center text-[#94a3b8] hover:text-white hover:bg-[#1a263c] transition relative group"
          title="Configurações do BlueStacks"
        >
          <Settings className="w-4 h-4" />
          <span className="absolute right-10 px-2 py-1 bg-black/95 text-white text-[10px] rounded shadow-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-[#223554]">
            Configurações
          </span>
        </button>
      </div>
    </aside>
  );
};
