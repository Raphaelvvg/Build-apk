import React from 'react';
import { Minus, Square, X, Settings, HelpCircle, Activity, Sparkles } from 'lucide-react';

interface Props {
  fpsLimit: number;
  onOpenSettings: () => void;
  onToggleFps: () => void;
  isPointerLocked: boolean;
}

export const BlueStacksTitleBar: React.FC<Props> = ({
  fpsLimit,
  onOpenSettings,
  onToggleFps,
  isPointerLocked
}) => {
  return (
    <header className="h-9 bg-[#0b101b] border-b border-[#1b263b] flex items-center justify-between px-3 text-xs select-none z-40">
      {/* BlueStacks Brand & Instance Identity */}
      <div className="flex items-center gap-2.5">
        {/* BlueStacks Iconic 4-Color Stacked Diamond Logo */}
        <div className="flex items-center gap-1 group cursor-pointer" title="BlueStacks 5 App Player (Versemapper Edition)">
          <div className="relative w-4 h-4 flex items-center justify-center">
            {/* 4 layered diamonds */}
            <div className="absolute w-2.5 h-2.5 bg-[#0084ff] rotate-45 -translate-y-1 rounded-[1px] shadow-sm" />
            <div className="absolute w-2.5 h-2.5 bg-[#00e676] rotate-45 -translate-x-1 rounded-[1px] opacity-90" />
            <div className="absolute w-2.5 h-2.5 bg-[#ffd600] rotate-45 translate-x-1 rounded-[1px] opacity-90" />
            <div className="absolute w-2.5 h-2.5 bg-[#ff1744] rotate-45 translate-y-1 rounded-[1px] opacity-90" />
          </div>
          <span className="font-extrabold text-[#f1f5f9] tracking-tight ml-1 text-[13px]">
            BlueStacks <span className="text-[#00a8ff] font-semibold text-[11px]">5</span>
          </span>
        </div>

        <div className="h-3.5 w-[1px] bg-[#223048]" />

        <span className="text-[11px] text-[#94a3b8] font-medium hidden sm:inline-block">
          Versemapper Mobilador Engine (Nougat 64-bit)
        </span>

        {/* Pointer Lock Badge */}
        {isPointerLocked ? (
          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-bold flex items-center gap-1 animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            CURSOR TRAVADO (F1/ALT LIBERA)
          </span>
        ) : (
          <span className="px-2 py-0.5 rounded bg-[#1e293b] text-[#94a3b8] text-[10px] font-semibold hidden md:inline-block">
            Pressione F1 para travar a mira
          </span>
        )}
      </div>

      {/* Right controls: FPS, RAM, Window actions */}
      <div className="flex items-center gap-3">
        {/* Real-time FPS Toggle */}
        <button
          onClick={onToggleFps}
          className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#162238] border border-[#233554] text-[#38bdf8] hover:text-white font-mono text-[11px] font-bold transition"
          title="Clique para alternar entre 60 FPS e 120 FPS"
        >
          <Activity className="w-3 h-3 text-[#38bdf8]" />
          <span>{fpsLimit}.0 FPS</span>
        </button>

        <span className="text-[10px] font-mono text-[#64748b] hidden lg:inline-block">
          CPU: 3% · RAM: 1.6 GB
        </span>

        <button
          onClick={onOpenSettings}
          className="p-1 rounded text-[#94a3b8] hover:text-white hover:bg-[#1e293b] transition"
          title="Configurações do BlueStacks"
        >
          <Settings className="w-3.5 h-3.5" />
        </button>

        <div className="flex items-center gap-1 border-l border-[#1b263b] pl-2 text-[#94a3b8]">
          <button className="p-1 hover:text-white hover:bg-[#1e293b] rounded transition" title="Minimizar">
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button className="p-1 hover:text-white hover:bg-[#1e293b] rounded transition" title="Maximizar">
            <Square className="w-3 h-3" />
          </button>
          <button className="p-1 hover:text-red-400 hover:bg-red-500/10 rounded transition" title="Fechar">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
