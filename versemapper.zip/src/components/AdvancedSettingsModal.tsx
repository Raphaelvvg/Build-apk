import React, { useState } from 'react';
import { ControlItem } from '../types/bluestacks';
import { BLUESTACKS_TWEAKS_PRESETS } from '../data/defaultSchemes';
import { X, Crosshair, Move, Settings, Check, Sparkles, HelpCircle, Code } from 'lucide-react';

interface Props {
  control: ControlItem | null;
  onClose: () => void;
  onSave: (updated: ControlItem) => void;
}

export const AdvancedSettingsModal: React.FC<Props> = ({
  control,
  onClose,
  onSave
}) => {
  if (!control) return null;

  const [item, setItem] = useState<ControlItem>({ ...control });

  const handleSave = () => {
    onSave(item);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm select-none">
      <div className="bg-[#0e1626] border-2 border-[#1f2d48] rounded-2xl w-full max-w-lg shadow-[0_20px_60px_rgba(0,0,0,0.9)] text-white overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-[#0b101b] border-b border-[#1f2d48] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#0084ff]/20 border border-[#0084ff] flex items-center justify-center text-[#0084ff]">
              {item.type === 'AIM_PAN_SHOOT' ? (
                <Crosshair className="w-4 h-4" />
              ) : item.type === 'DPAD' ? (
                <Move className="w-4 h-4" />
              ) : (
                <Settings className="w-4 h-4" />
              )}
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">
                Configurações Avançadas
              </h3>
              <span className="text-[11px] text-[#38bdf8] font-mono">
                {item.type === 'AIM_PAN_SHOOT'
                  ? 'Olhar, Mirar e Atirar (BlueStacks FPS Engine)'
                  : item.type === 'DPAD'
                  ? 'Controle de Movimento D-Pad (WASD)'
                  : item.name}
              </span>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded text-[#94a3b8] hover:text-white hover:bg-[#1a263c]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {/* 1. AIM, PAN AND SHOOT SPECIFIC ADVANCED BLUESTACKS SETTINGS */}
          {item.type === 'AIM_PAN_SHOOT' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                {/* Start / Stop Key */}
                <div className="p-3 rounded-xl bg-[#131d31] border border-[#1f2d48]">
                  <label className="text-[11px] text-[#94a3b8] font-semibold block mb-1">
                    Tecla Iniciar / Parar (Modo FPS)
                  </label>
                  <input
                    type="text"
                    value={item.startStopKey || 'F1'}
                    onChange={(e) => setItem({ ...item, startStopKey: e.target.value })}
                    className="w-full p-2 bg-black border border-[#233554] rounded-lg text-sm font-black text-center text-[#38bdf8] focus:border-[#0084ff] outline-none"
                  />
                  <span className="text-[9px] text-[#64748b] block mt-1">
                    Ativa a mira e esconde o cursor do mouse
                  </span>
                </div>

                {/* Suspend Key */}
                <div className="p-3 rounded-xl bg-[#131d31] border border-[#1f2d48]">
                  <label className="text-[11px] text-[#94a3b8] font-semibold block mb-1">
                    Tecla de Suspensão
                  </label>
                  <input
                    type="text"
                    value={item.suspendKey || 'L-Alt'}
                    onChange={(e) => setItem({ ...item, suspendKey: e.target.value })}
                    className="w-full p-2 bg-black border border-[#233554] rounded-lg text-sm font-black text-center text-amber-400 focus:border-[#0084ff] outline-none"
                  />
                  <span className="text-[9px] text-[#64748b] block mt-1">
                    Libera a seta para lootear/clicar
                  </span>
                </div>
              </div>

              {/* Sensitivity X & Y */}
              <div className="p-3.5 rounded-xl bg-[#131d31] border border-[#1f2d48] space-y-3">
                <span className="text-[11px] font-bold text-white block">
                  Sensibilidade do Mouse BlueStacks
                </span>

                {/* Sens X */}
                <div>
                  <div className="flex justify-between items-center text-[11px] mb-1">
                    <span className="text-[#94a3b8]">Sensibilidade do Mouse X (Horizontal):</span>
                    <span className="font-mono font-bold text-[#38bdf8] text-sm">{(item.sensX || 1.4).toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="5.0"
                    step="0.05"
                    value={item.sensX || 1.4}
                    onChange={(e) => setItem({ ...item, sensX: parseFloat(e.target.value) })}
                    className="w-full accent-[#0084ff]"
                  />
                </div>

                {/* Sens Y */}
                <div>
                  <div className="flex justify-between items-center text-[11px] mb-1">
                    <span className="text-[#94a3b8]">Sensibilidade do Mouse Y (Vertical / Puxada de Capa):</span>
                    <span className="font-mono font-bold text-emerald-400 text-sm">{(item.sensY || 1.85).toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="5.0"
                    step="0.05"
                    value={item.sensY || 1.85}
                    onChange={(e) => setItem({ ...item, sensY: parseFloat(e.target.value) })}
                    className="w-full accent-emerald-500"
                  />
                </div>
              </div>

              {/* THE FAMOUS BLUESTACKS TWEAKS (AJUSTES) */}
              <div className="p-3.5 rounded-xl bg-[#131d31] border border-[#1f2d48] space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-amber-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    Ajustes do BlueStacks (Tweaks):
                  </span>
                  <input
                    type="number"
                    value={item.tweaks || 16450}
                    onChange={(e) => setItem({ ...item, tweaks: parseInt(e.target.value) || 16450 })}
                    className="w-24 p-1.5 bg-black border border-amber-500/50 rounded text-center font-mono font-bold text-amber-300 text-xs"
                  />
                </div>
                <p className="text-[10px] text-[#64748b]">
                  O código de Ajuste (Tweak) dita a velocidade de polling e calibração de aceleração interna de mira no Free Fire e outros FPS.
                </p>

                {/* Tweak quick preset chips */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {BLUESTACKS_TWEAKS_PRESETS.map((tw) => (
                    <button
                      key={tw.value}
                      onClick={() => setItem({ ...item, tweaks: tw.value })}
                      className={`px-2 py-1 rounded text-[10px] font-mono font-bold transition border ${
                        item.tweaks === tw.value
                          ? 'bg-amber-400 text-black border-amber-300 shadow'
                          : 'bg-[#162238] text-[#94a3b8] border-[#233554] hover:text-white'
                      }`}
                      title={tw.label}
                    >
                      {tw.value}
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggles */}
              <div className="p-3 rounded-xl bg-[#131d31] border border-[#1f2d48] space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-[#cbd5e1]">Atirar com o Clique Esquerdo do Mouse</span>
                  <input
                    type="checkbox"
                    checked={item.fireWithLeftClick ?? true}
                    onChange={(e) => setItem({ ...item, fireWithLeftClick: e.target.checked })}
                    className="w-4 h-4 accent-[#0084ff] rounded"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-[#cbd5e1]">Aceleração do Mouse</span>
                  <input
                    type="checkbox"
                    checked={item.mouseAcceleration ?? false}
                    onChange={(e) => setItem({ ...item, mouseAcceleration: e.target.checked })}
                    className="w-4 h-4 accent-[#0084ff] rounded"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 2. D-PAD SETTINGS */}
          {item.type === 'DPAD' && (
            <div className="space-y-3">
              <span className="text-[11px] font-bold text-white block">Teclas de Direção (WASD)</span>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-[#94a3b8] block mb-1">Mover para Cima:</label>
                  <input
                    value={item.upKey || 'W'}
                    onChange={(e) => setItem({ ...item, upKey: e.target.value })}
                    className="w-full p-2 bg-black border border-[#233554] rounded font-bold text-center text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#94a3b8] block mb-1">Mover para Baixo:</label>
                  <input
                    value={item.downKey || 'S'}
                    onChange={(e) => setItem({ ...item, downKey: e.target.value })}
                    className="w-full p-2 bg-black border border-[#233554] rounded font-bold text-center text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#94a3b8] block mb-1">Mover para a Esquerda:</label>
                  <input
                    value={item.leftKey || 'A'}
                    onChange={(e) => setItem({ ...item, leftKey: e.target.value })}
                    className="w-full p-2 bg-black border border-[#233554] rounded font-bold text-center text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#94a3b8] block mb-1">Mover para a Direita:</label>
                  <input
                    value={item.rightKey || 'D'}
                    onChange={(e) => setItem({ ...item, rightKey: e.target.value })}
                    className="w-full p-2 bg-black border border-[#233554] rounded font-bold text-center text-white"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 3. REPEATED TAP SETTINGS */}
          {item.type === 'REPEATED_TAP' && (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-[#131d31] border border-[#1f2d48]">
                <label className="text-[11px] text-[#94a3b8] block mb-1">Tecla de Disparo Turbo:</label>
                <input
                  value={item.hotkey}
                  onChange={(e) => setItem({ ...item, hotkey: e.target.value })}
                  className="w-full p-2 bg-black border border-[#233554] rounded font-bold text-center text-[#38bdf8]"
                />
              </div>

              <div>
                <div className="flex justify-between items-center text-[11px] mb-1">
                  <span>Toques por Segundo (Frequência):</span>
                  <span className="font-mono font-bold text-amber-400">{item.repeatCount || 10} toques/s</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="40"
                  value={item.repeatCount || 10}
                  onChange={(e) => setItem({ ...item, repeatCount: parseInt(e.target.value) })}
                  className="w-full accent-amber-400"
                />
              </div>
            </div>
          )}

          {/* 4. SCRIPT / MACRO CODE EDITOR */}
          {item.type === 'SCRIPT' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-white flex items-center gap-1.5">
                  <Code className="w-3.5 h-3.5 text-amber-400" />
                  Editor de Código de Script BlueStacks:
                </span>
                <input
                  value={item.hotkey}
                  onChange={(e) => setItem({ ...item, hotkey: e.target.value })}
                  placeholder="Tecla de Execução"
                  className="w-20 p-1 bg-black border border-[#233554] rounded text-center text-xs font-bold text-[#38bdf8]"
                />
              </div>

              <textarea
                rows={6}
                value={
                  item.scriptCode ||
                  `// Script BlueStacks\ntap 88 34\nwait 50\ntap 14 18`
                }
                onChange={(e) => setItem({ ...item, scriptCode: e.target.value })}
                className="w-full p-3 bg-black border border-[#233554] rounded-lg font-mono text-xs text-emerald-400 focus:outline-none focus:border-[#0084ff]"
              />
              <span className="text-[10px] text-[#64748b]">
                Comandos suportados: <code>tap X Y</code>, <code>wait ms</code>, <code>keyDown key</code>, <code>keyUp key</code>.
              </span>
            </div>
          )}

          {/* 5. STANDARD TAP SPOT */}
          {item.type === 'TAP' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-[#94a3b8] block mb-1">Tecla Física do Teclado:</label>
                <input
                  value={item.hotkey}
                  onChange={(e) => setItem({ ...item, hotkey: e.target.value })}
                  className="w-full p-2.5 bg-black border border-[#233554] rounded-lg text-sm font-bold text-center text-[#38bdf8]"
                />
              </div>
              <div>
                <label className="text-[11px] text-[#94a3b8] block mb-1">Nome da Ação / Descrição:</label>
                <input
                  value={item.name}
                  onChange={(e) => setItem({ ...item, name: e.target.value })}
                  className="w-full p-2.5 bg-black border border-[#233554] rounded-lg text-xs text-white"
                />
              </div>
            </div>
          )}

          {/* Coordinates in % */}
          <div className="pt-2 border-t border-[#1f2d48] flex items-center justify-between text-[11px] text-[#64748b] font-mono">
            <span>Coordenadas de tela:</span>
            <span>X: {item.x}% · Y: {item.y}%</span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#0b101b] border-t border-[#1f2d48] flex items-center justify-between">
          <button
            onClick={onClose}
            className="py-2 px-4 rounded-lg bg-[#162238] hover:bg-[#1e2d4a] text-[#94a3b8] hover:text-white font-bold text-xs"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            className="py-2 px-6 rounded-lg bg-[#0084ff] hover:bg-[#0074e0] text-white font-bold text-xs shadow-[0_0_15px_rgba(0,132,255,0.4)] flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" />
            Salvar Configurações
          </button>
        </div>
      </div>
    </div>
  );
};
