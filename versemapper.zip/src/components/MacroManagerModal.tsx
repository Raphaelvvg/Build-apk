import React, { useState } from 'react';
import { X, Play, Square, Plus, Trash2, Zap, Clock, Code, Check } from 'lucide-react';

interface MacroItem {
  id: string;
  name: string;
  hotkey: string;
  duration: string;
  code: string;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onExecuteMacro: (macro: MacroItem) => void;
}

const DEFAULT_MACROS: MacroItem[] = [
  {
    id: 'm_gelo',
    name: 'Gelo Agachado Instantâneo (Free Fire)',
    hotkey: 'Q',
    duration: '0.08s',
    code: 'tap 86 76\nwait 20\ntap 52 78\nwait 25\ntap 88 34'
  },
  {
    id: 'm_quick_switch',
    name: 'Troca Rápida de Arma (AWM / Sniper)',
    hotkey: '3',
    duration: '0.05s',
    code: 'tap 72 14\nwait 20\ntap 78 14'
  },
  {
    id: 'm_jump_shot',
    name: 'Pulo com Tiro Sincronizado',
    hotkey: 'T',
    duration: '0.12s',
    code: 'tap 92 62\nwait 40\ntap 88 34'
  }
];

export const MacroManagerModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onExecuteMacro
}) => {
  if (!isOpen) return null;

  const [macros, setMacros] = useState<MacroItem[]>(DEFAULT_MACROS);
  const [selectedMacro, setSelectedMacro] = useState<MacroItem | null>(null);
  const [isRecording, setIsRecording] = useState(false);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm select-none">
      <div className="bg-[#0e1626] border-2 border-[#1f2d48] rounded-2xl w-full max-w-lg shadow-2xl text-white overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 bg-[#0b101b] border-b border-[#1f2d48] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500 flex items-center justify-center text-amber-400">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">
                Gerenciador de Macros do BlueStacks
              </h3>
              <span className="text-[10px] text-[#94a3b8] font-mono">
                Atalhos e automações de toque com latência zero
              </span>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded text-[#94a3b8] hover:text-white hover:bg-[#1a263c]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action bar */}
        <div className="p-3 bg-[#111c30] border-b border-[#1f2d48] flex items-center justify-between">
          <button
            onClick={() => {
              if (isRecording) {
                setIsRecording(false);
              } else {
                setIsRecording(true);
                setTimeout(() => {
                  setIsRecording(false);
                  const newM: MacroItem = {
                    id: `macro_${Date.now()}`,
                    name: `Macro Gravado #${macros.length + 1}`,
                    hotkey: 'G',
                    duration: '0.15s',
                    code: 'tap 88 34\nwait 50\ntap 92 62'
                  };
                  setMacros((prev) => [...prev, newM]);
                }, 2000);
              }
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition ${
              isRecording
                ? 'bg-red-600 text-white animate-pulse'
                : 'bg-[#0084ff] hover:bg-[#0074e0] text-white shadow'
            }`}
          >
            {isRecording ? <Square className="w-3.5 h-3.5 fill-current" /> : <Plus className="w-3.5 h-3.5" />}
            {isRecording ? 'Gravando toques... (Parar)' : 'Gravar Novo Macro'}
          </button>

          <span className="text-[11px] text-[#64748b]">
            {macros.length} Macros Criados
          </span>
        </div>

        {/* Macro List */}
        <div className="p-4 overflow-y-auto space-y-2 flex-1 text-xs">
          {macros.map((m) => (
            <div
              key={m.id}
              className="p-3 rounded-xl bg-[#131d31] border border-[#1f2d48] hover:border-[#0084ff]/50 flex items-center justify-between transition"
            >
              <div>
                <h4 className="font-bold text-white text-xs">{m.name}</h4>
                <div className="flex items-center gap-3 text-[10px] text-[#94a3b8] mt-1">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-[#38bdf8]" />
                    {m.duration}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-black/60 font-mono text-cyan-300 border border-[#233554]">
                    Atalho: <b>{m.hotkey}</b>
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => onExecuteMacro(m)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-xs flex items-center gap-1 shadow"
                  title="Executar Macro Agora"
                >
                  <Play className="w-3 h-3 fill-current" />
                  Executar
                </button>

                <button
                  onClick={() => setMacros((prev) => prev.filter((item) => item.id !== m.id))}
                  className="p-1.5 text-[#64748b] hover:text-red-400 hover:bg-red-500/10 rounded transition"
                  title="Excluir"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#0b101b] border-t border-[#1f2d48] flex justify-end">
          <button
            onClick={onClose}
            className="py-1.5 px-5 rounded-lg bg-[#162238] hover:bg-[#1e2d4a] text-white font-bold text-xs"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
