import React from 'react';
import {
  X,
  Crosshair,
  Move,
  MousePointer,
  RotateCcw,
  Zap,
  Eye,
  Sliders,
  Download,
  Upload,
  Plus,
  Compass,
  Repeat,
  ZoomIn,
  MoveRight,
  Shield,
  Layers,
  HelpCircle,
  Check
} from 'lucide-react';
import { ControlType, ControlScheme } from '../types/bluestacks';

interface Props {
  schemes: ControlScheme[];
  activeSchemeId: string;
  onSelectScheme: (id: string) => void;
  onCreateNewScheme: () => void;
  onExportScheme: () => void;
  onImportScheme: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onResetScheme: () => void;
  onClose: () => void;
  onSave: () => void;
  onDiscard: () => void;
  onAddControlDirectly: (type: ControlType) => void;
  hasUnsavedChanges: boolean;
}

interface WidgetItem {
  type: ControlType;
  title: string;
  desc: string;
  icon: React.ElementType;
  badge?: string;
}

const CONTROL_WIDGETS: WidgetItem[] = [
  {
    type: 'TAP',
    title: 'Ponto de Toque',
    desc: 'Toque simples na tela com tecla do teclado',
    icon: MousePointer
  },
  {
    type: 'REPEATED_TAP',
    title: 'Repetir Toque',
    desc: 'Múltiplos toques contínuos mantendo pressionado',
    icon: Repeat,
    badge: 'Turbo'
  },
  {
    type: 'DPAD',
    title: 'D-Pad',
    desc: 'Analógico de movimento com teclas WASD',
    icon: Move,
    badge: 'WASD'
  },
  {
    type: 'AIM_PAN_SHOOT',
    title: 'Olhar, Mirar e Atirar',
    desc: 'Modo FPS do BlueStacks com F1, Sensi X/Y e Tweaks',
    icon: Crosshair,
    badge: 'Modo FPS'
  },
  {
    type: 'FIRE_BUTTON',
    title: 'Gatilho de Tiro',
    desc: 'Atirar com o clique esquerdo do mouse no Modo FPS',
    icon: Crosshair,
    badge: 'Mouse 1'
  },
  {
    type: 'FREE_LOOK',
    title: 'Mirar Livremente',
    desc: 'Olhar em volta com o botão direito ou Alt',
    icon: Eye
  },
  {
    type: 'ZOOM',
    title: 'Zoom / Pinça',
    desc: 'Aumentar ou diminuir zoom com a roda do mouse',
    icon: ZoomIn
  },
  {
    type: 'SWIPE',
    title: 'Deslizar',
    desc: 'Gesto de arrasto direcional rápido',
    icon: MoveRight
  },
  {
    type: 'MOBA_SKILL',
    title: 'Roda de Habilidade MOBA',
    desc: 'Controle de mira direcional 360° para habilidades',
    icon: Compass,
    badge: 'MOBA'
  },
  {
    type: 'SCRIPT',
    title: 'Script / Macro',
    desc: 'Sequência programável de ações automáticas',
    icon: Zap,
    badge: 'Macro'
  }
];

export const BlueStacksControlsEditor: React.FC<Props> = ({
  schemes,
  activeSchemeId,
  onSelectScheme,
  onCreateNewScheme,
  onExportScheme,
  onImportScheme,
  onResetScheme,
  onClose,
  onSave,
  onDiscard,
  onAddControlDirectly,
  hasUnsavedChanges
}) => {
  return (
    <aside className="w-80 bg-[#0d1524] border-l border-[#1f2d48] flex flex-col h-full shadow-2xl z-40 select-none animate-in slide-in-from-right duration-200">
      {/* Editor Header */}
      <div className="p-3.5 border-b border-[#1f2d48] flex items-center justify-between bg-[#0b101b]">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-[#0084ff]" />
          <h2 className="text-sm font-bold text-white tracking-wide">Editor de controles</h2>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded text-[#94a3b8] hover:text-white hover:bg-[#1a263c] transition"
          title="Fechar Editor"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Scheme Management Section */}
      <div className="p-3.5 border-b border-[#1f2d48] space-y-2.5 bg-[#0e1728]">
        <div className="flex items-center justify-between text-[11px] text-[#94a3b8]">
          <span className="font-semibold uppercase tracking-wider text-[10px]">Esquema de controle</span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={onCreateNewScheme}
              className="text-[#0084ff] hover:underline font-bold flex items-center gap-0.5"
              title="Criar novo esquema limpo"
            >
              <Plus className="w-3 h-3" /> Novo
            </button>
            <span>·</span>
            <button
              onClick={onResetScheme}
              className="text-[#94a3b8] hover:text-white font-medium flex items-center gap-0.5"
              title="Redefinir para o padrão"
            >
              <RotateCcw className="w-3 h-3" /> Redefinir
            </button>
          </div>
        </div>

        {/* Scheme Selector Dropdown */}
        <div className="relative">
          <select
            value={activeSchemeId}
            onChange={(e) => onSelectScheme(e.target.value)}
            className="w-full bg-[#162238] border border-[#233554] text-white text-xs font-semibold rounded-lg px-3 py-2 pr-8 focus:outline-none focus:border-[#0084ff] transition cursor-pointer"
          >
            {schemes.map((s) => (
              <option key={s.id} value={s.id} className="bg-[#0e1728] text-white py-1">
                {s.name} ({s.resolution})
              </option>
            ))}
          </select>
        </div>

        {/* Scheme Import / Export Buttons */}
        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={onExportScheme}
            className="flex-1 py-1.5 px-2 bg-[#162238] hover:bg-[#1f2d48] border border-[#233554] rounded text-[11px] font-semibold text-[#cbd5e1] flex items-center justify-center gap-1.5 transition"
            title="Exportar esquema para arquivo .json"
          >
            <Download className="w-3 h-3 text-[#0084ff]" />
            Exportar
          </button>

          <label className="flex-1 py-1.5 px-2 bg-[#162238] hover:bg-[#1f2d48] border border-[#233554] rounded text-[11px] font-semibold text-[#cbd5e1] flex items-center justify-center gap-1.5 transition cursor-pointer">
            <Upload className="w-3 h-3 text-emerald-400" />
            Importar
            <input type="file" accept=".json" onChange={onImportScheme} className="hidden" />
          </label>
        </div>
      </div>

      {/* Widgets Palette (Controles do BlueStacks) */}
      <div className="flex-1 overflow-y-auto p-3.5 space-y-3">
        <div>
          <h3 className="text-[11px] font-bold text-[#94a3b8] uppercase tracking-wider mb-1">
            Controles
          </h3>
          <p className="text-[10px] text-[#64748b] leading-tight">
            Clique em qualquer controle para adicioná-lo ou arraste para posicionar sobre o botão do jogo:
          </p>
        </div>

        <div className="space-y-1.5">
          {CONTROL_WIDGETS.map((w) => {
            const Icon = w.icon;
            return (
              <div
                key={w.type}
                onClick={() => onAddControlDirectly(w.type)}
                className="group p-2.5 rounded-xl bg-[#131d31] hover:bg-[#1a2842] border border-[#1f2d48] hover:border-[#0084ff]/60 cursor-pointer transition flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#1a263c] border border-[#233554] group-hover:border-[#0084ff] flex items-center justify-center text-[#0084ff] shadow-sm">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-bold text-white group-hover:text-[#38bdf8] transition">
                        {w.title}
                      </h4>
                      {w.badge && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#0084ff]/20 text-[#38bdf8] border border-[#0084ff]/30 font-semibold font-mono">
                          {w.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-[#64748b] line-clamp-1">{w.desc}</p>
                  </div>
                </div>

                <div className="text-[10px] text-[#0084ff] font-bold opacity-0 group-hover:opacity-100 transition pr-1">
                  + Add
                </div>
              </div>
            );
          })}
        </div>

        {/* Tip Box */}
        <div className="p-3 rounded-xl bg-[#111c30] border border-[#1f2d48] space-y-1 text-[11px] text-[#94a3b8]">
          <div className="font-bold text-[#38bdf8] flex items-center gap-1 text-[11px]">
            <HelpCircle className="w-3.5 h-3.5" />
            Dica BlueStacks 5:
          </div>
          <p className="text-[10px] leading-relaxed text-[#64748b]">
            Clique com o botão direito em qualquer controle na tela para abrir suas configurações avançadas (Sensibilidade X/Y, Tweaks 16450, Tecla de Suspensão).
          </p>
        </div>
      </div>

      {/* Editor Footer (Save / Discard) */}
      <div className="p-3 border-t border-[#1f2d48] bg-[#0b101b] flex items-center gap-2">
        <button
          onClick={onDiscard}
          className="flex-1 py-2 px-3 rounded-lg bg-[#162238] hover:bg-[#1e2d4a] text-[#94a3b8] hover:text-white font-bold text-xs transition border border-[#233554]"
        >
          Descartar
        </button>
        <button
          onClick={onSave}
          className="flex-1 py-2 px-3 rounded-lg bg-[#0084ff] hover:bg-[#0074e0] text-white font-bold text-xs transition shadow-[0_0_15px_rgba(0,132,255,0.4)] flex items-center justify-center gap-1.5"
        >
          <Check className="w-3.5 h-3.5" />
          Salvar
        </button>
      </div>
    </aside>
  );
};
