import React, { useState } from 'react';
import {
  X,
  Shield,
  Wifi,
  Cpu,
  Usb,
  CheckCircle,
  AlertCircle,
  Copy,
  Terminal,
  ExternalLink,
  Smartphone
} from 'lucide-react';
import { AndroidActivationMethod } from '../types/bluestacks';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  isActivated: boolean;
  activeMethod: AndroidActivationMethod;
  onActivate: (method: AndroidActivationMethod) => void;
}

export const AndroidActivationModal: React.FC<Props> = ({
  isOpen,
  onClose,
  isActivated,
  activeMethod,
  onActivate
}) => {
  if (!isOpen) return null;

  const [selectedMethod, setSelectedMethod] = useState<AndroidActivationMethod>(activeMethod);
  const [wirelessPort, setWirelessPort] = useState('42153');
  const [pairingCode, setPairingCode] = useState('954120');
  const [isProcessing, setIsProcessing] = useState(false);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm select-none">
      <div className="bg-[#0e1626] border-2 border-[#1f2d48] rounded-2xl w-full max-w-lg shadow-2xl text-white overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-[#0b101b] border-b border-[#1f2d48] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500 flex items-center justify-center text-emerald-400">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">
                Central de Ativação do Mapeador Android
              </h3>
              <span className="text-[10px] text-[#38bdf8] font-mono">
                Injeção de toques nativa multi-touch sem delay (0.4ms)
              </span>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded text-[#94a3b8] hover:text-white hover:bg-[#1a263c]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status card */}
        <div className="p-4 bg-[#111c30] border-b border-[#1f2d48]">
          <div className={`p-3 rounded-xl border flex items-center justify-between ${
            isActivated ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300' : 'bg-amber-950/30 border-amber-500/40 text-amber-300'
          }`}>
            <div className="flex items-center gap-2.5 text-xs font-bold">
              {isActivated ? <CheckCircle className="w-5 h-5 text-emerald-400" /> : <AlertCircle className="w-5 h-5 text-amber-400" />}
              <div>
                <div>{isActivated ? `MAPEADOR ATIVADO (${activeMethod.toUpperCase()})` : 'MAPEADOR NÃO ATIVADO'}</div>
                <span className="text-[10px] font-normal text-[#94a3b8] block">
                  {isActivated ? 'Injeção de toques com latência zero pronta para partidas' : 'Toques de teclado e mouse requerem ativação única'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Method selection */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1 text-xs">
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'Shizuku', title: 'Shizuku (1-Clique)', desc: 'Recomendado sem PC', icon: Shield, badge: 'Rápido' },
              { id: 'Wireless', title: 'Depuração Wi-Fi', desc: 'Android 11+ via rede', icon: Wifi, badge: 'Wi-Fi' },
              { id: 'Root', title: 'Acesso Root', desc: 'Magisk / KernelSU', icon: Cpu, badge: 'Kernel' },
              { id: 'Wired', title: 'Cabo USB / PC', desc: 'Script ADB de PC', icon: Usb, badge: 'Cabo' }
            ].map((m) => {
              const Icon = m.icon;
              return (
                <div
                  key={m.id}
                  onClick={() => setSelectedMethod(m.id as any)}
                  className={`p-3 rounded-xl border cursor-pointer transition ${
                    selectedMethod === m.id
                      ? 'bg-[#0084ff]/25 border-[#0084ff] shadow-[0_0_12px_rgba(0,132,255,0.3)]'
                      : 'bg-[#131d31] border-[#1f2d48] hover:border-[#2a3c5a]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white flex items-center gap-1.5 text-xs">
                      <Icon className="w-3.5 h-3.5 text-[#38bdf8]" />
                      {m.title}
                    </span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-black/60 text-[#38bdf8] font-bold">
                      {m.badge}
                    </span>
                  </div>
                  <span className="text-[10px] text-[#64748b] block mt-1">{m.desc}</span>
                </div>
              );
            })}
          </div>

          {/* Interactive Method Panel */}
          {selectedMethod === 'Shizuku' && (
            <div className="p-4 rounded-xl bg-[#131d31] border border-cyan-500/30 space-y-3">
              <div className="font-bold text-cyan-300 flex items-center gap-1.5 text-xs">
                <Shield className="w-4 h-4 text-emerald-400" />
                Ativação Shizuku no Celular (Sem Computador)
              </div>
              <p className="text-[11px] text-[#cbd5e1] leading-relaxed">
                O serviço Shizuku executa diretamente no seu celular Android com permissões de <code>IInputManager.injectMotionEvent</code> para garantir resposta instantânea idêntica ao BlueStacks.
              </p>
              <div className="flex items-center justify-between text-xs pt-1">
                <span className="text-[#94a3b8]">Status do Shizuku:</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" /> EM EXECUÇÃO (V13.5)
                </span>
              </div>
              <button
                onClick={() => {
                  onActivate('Shizuku');
                  onClose();
                }}
                className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs rounded-xl transition shadow"
              >
                CONCEDER PERMISSÃO SHIZUKU & ATIVAR
              </button>
            </div>
          )}

          {selectedMethod === 'Wireless' && (
            <div className="p-4 rounded-xl bg-[#131d31] border border-cyan-500/30 space-y-3">
              <div className="font-bold text-cyan-300 flex items-center gap-1.5 text-xs">
                <Wifi className="w-4 h-4 text-[#38bdf8]" />
                Depuração Sem Fio (Android 11, 12, 13, 14, 15)
              </div>
              <p className="text-[11px] text-[#cbd5e1]">
                Vá em <b>Opções do Desenvolvedor</b> &gt; <b>Depuração por Wi-Fi</b> &gt; <b>Parear com código</b>.
              </p>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-[#94a3b8] block mb-1">Porta Wi-Fi:</label>
                  <input
                    value={wirelessPort}
                    onChange={(e) => setWirelessPort(e.target.value)}
                    className="w-full p-2 bg-black border border-[#233554] rounded text-xs font-mono text-[#38bdf8]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#94a3b8] block mb-1">Código de Pareamento (6 dígitos):</label>
                  <input
                    value={pairingCode}
                    onChange={(e) => setPairingCode(e.target.value)}
                    className="w-full p-2 bg-black border border-[#233554] rounded text-xs font-mono text-[#38bdf8]"
                  />
                </div>
              </div>
              <button
                disabled={isProcessing}
                onClick={() => {
                  setIsProcessing(true);
                  setTimeout(() => {
                    setIsProcessing(false);
                    onActivate('Wireless');
                    onClose();
                  }, 800);
                }}
                className="w-full py-2.5 bg-[#0084ff] hover:bg-[#0074e0] text-white font-black text-xs rounded-xl transition shadow"
              >
                {isProcessing ? 'Conectando ao daemon ADB...' : 'PAREAR E ATIVAR AGORA'}
              </button>
            </div>
          )}

          {selectedMethod === 'Root' && (
            <div className="p-4 rounded-xl bg-[#131d31] border border-purple-500/30 space-y-3">
              <div className="font-bold text-purple-300 flex items-center gap-1.5 text-xs">
                <Cpu className="w-4 h-4 text-purple-400" />
                Modo Superusuário Root (/dev/uinput)
              </div>
              <p className="text-[11px] text-[#cbd5e1]">
                Cria nós virtuais de hardware diretamente no kernel Linux do smartphone via Magisk / KernelSU / APatch para 0.1ms de delay.
              </p>
              <button
                onClick={() => {
                  onActivate('Root');
                  onClose();
                }}
                className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-black text-xs rounded-xl transition shadow"
              >
                SOLICITAR ACESSO ROOT E ATIVAR
              </button>
            </div>
          )}

          {selectedMethod === 'Wired' && (
            <div className="p-4 rounded-xl bg-[#131d31] border border-cyan-500/30 space-y-3">
              <div className="font-bold text-cyan-300 flex items-center gap-1.5 text-xs">
                <Terminal className="w-4 h-4 text-[#38bdf8]" />
                Ativação por Computador / Cabo USB
              </div>
              <p className="text-[11px] text-[#cbd5e1]">
                Conecte o smartphone no PC com Depuração USB ligada e execute no terminal do PC:
              </p>
              <div className="p-2 bg-black border border-[#1f2d48] rounded font-mono text-[10.5px] text-emerald-400 flex items-center justify-between">
                <span>adb shell sh /sdcard/Android/data/com.versemapper/activate.sh</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText('adb shell sh /sdcard/Android/data/com.versemapper/activate.sh');
                  }}
                  className="p-1 hover:text-white"
                  title="Copiar comando"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
              <button
                onClick={() => {
                  onActivate('Wired');
                  onClose();
                }}
                className="w-full py-2.5 bg-white text-black font-black text-xs rounded-xl transition shadow"
              >
                CONFIRMAR ATIVAÇÃO
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#0b101b] border-t border-[#1f2d48] flex justify-end">
          <button onClick={onClose} className="py-1.5 px-5 bg-[#162238] hover:bg-[#1e2d4a] text-white font-bold text-xs rounded-lg">
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
