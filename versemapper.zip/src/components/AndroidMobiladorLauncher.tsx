import React, { useState } from 'react';
import {
  Gamepad2,
  Mouse,
  Keyboard,
  Shield,
  Plus,
  Play,
  RotateCcw,
  Sliders,
  CheckCircle,
  AlertCircle,
  Activity,
  Layers,
  Settings,
  Search,
  Check,
  X,
  Sparkles,
  Zap,
  Cpu,
  Usb,
  Smartphone
} from 'lucide-react';
import { ControlScheme, AndroidActivationMethod } from '../types/bluestacks';

interface AndroidApp {
  id: string;
  title: string;
  category: string;
  iconColor: string;
}

const INSTALLED_PHONE_GAMES: AndroidApp[] = [
  { id: 'freefire_smart', title: 'Free Fire MAX', category: 'Battle Royale', iconColor: 'from-amber-600 to-orange-700' },
  { id: 'ff_classic', title: 'Free Fire', category: 'Battle Royale', iconColor: 'from-red-600 to-amber-700' },
  { id: 'blood_strike_pro', title: 'Blood Strike', category: 'FPS Rápido', iconColor: 'from-red-700 to-rose-950' },
  { id: 'pubg_smart', title: 'PUBG MOBILE', category: 'Battle Royale', iconColor: 'from-yellow-600 to-amber-800' },
  { id: 'cod_mobile', title: 'Call of Duty: Mobile', category: 'FPS Militar', iconColor: 'from-slate-700 to-gray-900' },
  { id: 'standoff2', title: 'Standoff 2', category: 'FPS Tático', iconColor: 'from-zinc-700 to-neutral-900' },
  { id: 'arena_b', title: 'Arena Breakout', category: 'Tiro Tático', iconColor: 'from-emerald-700 to-teal-900' },
  { id: 'farlight', title: 'Farlight 84', category: 'Hero Shooter', iconColor: 'from-cyan-600 to-blue-800' },
  { id: 'roblox', title: 'Roblox', category: 'Sandbox / Aventura', iconColor: 'from-red-600 to-gray-800' },
  { id: 'minecraft', title: 'Minecraft', category: 'Sobrevivência', iconColor: 'from-green-700 to-emerald-900' },
  { id: 'carx', title: 'CarX Street', category: 'Corrida', iconColor: 'from-purple-700 to-pink-900' }
];

interface Props {
  schemes: ControlScheme[];
  activeSchemeId: string;
  onSelectScheme: (id: string) => void;
  onLaunchGame: () => void;
  onOpenActivation: () => void;
  isActivated: boolean;
  activationMethod: AndroidActivationMethod;
  lastKeyPressed: string;
  lastMouseAction: string;
  inputLatency: number;
  mousePollingHz: number;
}

export const AndroidMobiladorLauncher: React.FC<Props> = ({
  schemes,
  activeSchemeId,
  onSelectScheme,
  onLaunchGame,
  onOpenActivation,
  isActivated,
  activationMethod,
  lastKeyPressed,
  lastMouseAction,
  inputLatency,
  mousePollingHz
}) => {
  const [activeTab, setActiveTab] = useState<'JOGOS' | 'HARDWARE' | 'CONFIG'>('JOGOS');
  const [isAppPickerOpen, setIsAppPickerOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const currentScheme = schemes.find((s) => s.id === activeSchemeId) || schemes[0];

  return (
    <div className="flex-1 flex flex-col bg-[#090e1a] text-white select-none overflow-y-auto">
      {/* Top Mobile Status Header */}
      <div className="px-5 py-3 bg-[#0b1120] border-b border-[#1b263b] flex flex-col gap-2.5">
        <div className="flex items-center justify-between">
          {/* BlueStacks Mobilador Logo */}
          <div className="flex items-center gap-2.5">
            <div className="relative w-7 h-7 flex items-center justify-center">
              <div className="absolute w-3.5 h-3.5 bg-[#0084ff] rotate-45 -translate-y-1.5 rounded-[1.5px] shadow" />
              <div className="absolute w-3.5 h-3.5 bg-[#00e676] rotate-45 -translate-x-1.5 rounded-[1.5px] opacity-95" />
              <div className="absolute w-3.5 h-3.5 bg-[#ffd600] rotate-45 translate-x-1.5 rounded-[1.5px] opacity-95" />
              <div className="absolute w-3.5 h-3.5 bg-[#ff1744] rotate-45 translate-y-1.5 rounded-[1.5px] opacity-95" />
            </div>
            <div>
              <h1 className="text-base font-black tracking-wider text-white">
                BLUESTACKS <span className="text-[#0084ff] font-extrabold">MOBILADOR</span>
              </h1>
              <span className="text-[10px] text-[#38bdf8] font-mono tracking-widest uppercase block -mt-0.5">
                Mapeador Nativo Android de Teclado & Mouse
              </span>
            </div>
          </div>

          {/* Peripherals Status Badges */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 text-xs font-bold">
              <Mouse className="w-3.5 h-3.5" />
              <span>MOUSE OK ({mousePollingHz}Hz)</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 text-xs font-bold">
              <Keyboard className="w-3.5 h-3.5" />
              <span>TECLADO OK</span>
            </div>
          </div>
        </div>

        {/* Android Activation Status Banner */}
        <div
          onClick={onOpenActivation}
          className={`px-4 py-2 rounded-xl border flex items-center justify-between cursor-pointer transition ${
            isActivated
              ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
              : 'bg-amber-950/20 border-amber-500/40 text-amber-300 hover:bg-amber-950/30'
          }`}
        >
          <div className="flex items-center gap-2 text-xs font-semibold">
            <div className={`w-2.5 h-2.5 rounded-full ${isActivated ? 'bg-emerald-400 shadow-[0_0_8px_#10b981]' : 'bg-amber-400 animate-pulse'}`} />
            <span>
              {isActivated
                ? `ATIVADO VIA ${activationMethod.toUpperCase()} · Injeção multi-touch nativa ativa (Latência: 0.4ms)`
                : 'Mapeador não ativado. Toque aqui para ativar via Shizuku (1-clique sem PC) ou Wi-Fi.'}
            </span>
          </div>
          <span className="text-xs font-bold text-[#38bdf8] hover:underline">
            {isActivated ? 'VERIFICAR' : 'ATIVAR AGORA'} &gt;
          </span>
        </div>
      </div>

      {/* Main Content per Tab */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-5 space-y-6">
        {activeTab === 'JOGOS' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setIsAppPickerOpen(true)}
                className="px-4 py-2 bg-[#0084ff] hover:bg-[#0074e0] rounded-xl text-xs font-black text-white flex items-center gap-2 shadow-[0_0_15px_rgba(0,132,255,0.4)] transition"
              >
                <Plus className="w-4 h-4" />
                + ADICIONAR JOGO DO CELULAR
              </button>
              <span className="text-xs text-[#94a3b8] font-mono">
                {schemes.length} Jogos no Mapeador
              </span>
            </div>

            {/* Selected Game Showcase Card */}
            <div className="relative w-full rounded-2xl border-2 border-[#0084ff]/50 bg-gradient-to-b from-[#131d31] to-[#0a101d] p-7 flex flex-col items-center justify-center text-center shadow-2xl overflow-hidden">
              <div className="w-80 h-80 rounded-full bg-[#0084ff]/10 blur-3xl absolute -top-12 pointer-events-none" />

              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-600 to-orange-700 border-2 border-[#38bdf8] flex items-center justify-center shadow-xl mb-3">
                <Gamepad2 className="w-10 h-10 text-white" />
              </div>

              <h2 className="text-2xl font-black text-white tracking-wide">
                {currentScheme.gameTitle || currentScheme.name}
              </h2>
              <p className="text-xs text-[#38bdf8] font-medium mt-0.5">
                {currentScheme.category} · {currentScheme.resolution}
              </p>

              <div className="mt-3 flex items-center gap-3 text-xs">
                <span className="px-3 py-1 rounded-full bg-[#0084ff]/20 text-[#38bdf8] font-bold border border-[#0084ff]/30">
                  {currentScheme.controls.length} Controles BlueStacks Mapeados
                </span>
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                  Tweaks: 16450
                </span>
              </div>

              {/* BIG LAUNCH BUTTON (Inicia o jogo no celular com o motor BlueStacks) */}
              <button
                onClick={onLaunchGame}
                className="mt-6 px-12 py-3.5 bg-[#0084ff] hover:bg-[#0074e0] text-white font-black rounded-xl text-base tracking-widest flex items-center gap-2.5 shadow-[0_0_25px_rgba(0,132,255,0.7)] transition transform hover:scale-105 active:scale-95"
              >
                <Play className="w-5 h-5 fill-current" />
                ENTRAR NO JOGO COM MOTOR BLUESTACKS
              </button>
            </div>

            {/* Games Carousel */}
            <div>
              <h3 className="text-xs font-bold text-[#38bdf8] tracking-wider uppercase mb-3">
                JOGOS INSTALADOS NO CELULAR
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
                {schemes.map((s) => (
                  <div
                    key={s.id}
                    onClick={() => onSelectScheme(s.id)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition flex flex-col items-center text-center ${
                      activeSchemeId === s.id
                        ? 'bg-[#18263e] border-[#0084ff] shadow-[0_0_15px_rgba(0,132,255,0.4)]'
                        : 'bg-[#101726] border-[#1b263b] hover:border-[#2a3c5a]'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#0084ff] to-[#0052a3] flex items-center justify-center text-white mb-2 shadow">
                      <Gamepad2 className="w-5 h-5" />
                    </div>
                    <h4 className="text-xs font-bold text-white truncate w-full">{s.gameTitle || s.name}</h4>
                    <span className="text-[10px] text-[#64748b] mt-0.5">{s.controls.length} teclas BlueStacks</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB: HARDWARE LAB (Teste de Teclas e Mouse em tempo real) */}
        {activeTab === 'HARDWARE' && (
          <div className="space-y-5 max-w-xl mx-auto">
            <div className="text-center py-2">
              <h3 className="text-lg font-black text-white">TESTADOR DE HARDWARE MOBILADOR</h3>
              <p className="text-xs text-[#94a3b8] mt-1">
                Pressione teclas no teclado físico ou clique botões do mouse para testar a resposta do OTG.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#101726] border border-[#1f2d48] space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-black border border-[#1f2d48] text-center">
                  <span className="text-[10px] font-bold text-[#64748b] uppercase block mb-1">ÚLTIMA TECLA FÍSICA</span>
                  <div className="text-sm font-black text-[#38bdf8] truncate">{lastKeyPressed || 'Nenhuma'}</div>
                </div>

                <div className="p-4 rounded-xl bg-black border border-[#1f2d48] text-center">
                  <span className="text-[10px] font-bold text-[#64748b] uppercase block mb-1">ÚLTIMO CLIQUE MOUSE</span>
                  <div className="text-sm font-black text-emerald-400 truncate">{lastMouseAction || 'Nenhum'}</div>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-black border border-[#1f2d48] text-xs">
                <span className="text-[#94a3b8]">Latência estimada de entrada USB:</span>
                <span className="font-mono font-bold text-cyan-400">{inputLatency} ms (Zero Delay)</span>
              </div>

              <div className="p-3 rounded-xl bg-[#0084ff]/10 border border-[#0084ff]/30 text-xs text-[#cbd5e1] leading-relaxed">
                <b className="text-white">Dica BlueStacks:</b> Durante a partida no celular, use a tecla <b>F1</b> ou <b>Alt</b> para suspender a seta do mouse, saquear loot rapidamente e travar de volta para a mira 3D.
              </div>
            </div>
          </div>
        )}

        {/* TAB: CONFIGURAÇÕES */}
        {activeTab === 'CONFIG' && (
          <div className="space-y-4 max-w-xl mx-auto text-xs">
            <h3 className="text-xs font-bold text-[#38bdf8] uppercase tracking-wider mb-2">
              CONFIGURAÇÕES DO MOTOR BLUESTACKS
            </h3>
            <div className="rounded-xl border border-[#1f2d48] bg-black divide-y divide-[#1f2d48]">
              <div onClick={onOpenActivation} className="p-4 flex items-center justify-between cursor-pointer hover:bg-white/5 transition">
                <div>
                  <div className="text-sm font-bold text-white">Método de Ativação Android</div>
                  <div className="text-xs text-[#38bdf8]">{activationMethod} (Injeção nativa) &gt;</div>
                </div>
                <span className="text-emerald-400 font-bold">ATIVADO</span>
              </div>

              <div className="p-4 flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-white">Ajustes Padrão do BlueStacks (Tweaks)</div>
                  <div className="text-xs text-[#64748b]">Código 16450 (Padrão Ouro Free Fire)</div>
                </div>
                <span className="px-2 py-1 bg-amber-400/20 text-amber-300 rounded font-mono font-bold">16450</span>
              </div>

              <div className="p-4 flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-white">Sensibilidade do Mouse X e Y</div>
                  <div className="text-xs text-[#64748b]">Horizontal: 1.40 · Vertical: 1.85</div>
                </div>
                <span className="text-[#38bdf8] font-bold">CALIBRADO</span>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Navigation Bar for Mobilador */}
      <nav className="border-t border-[#1b263b] bg-[#0b1120] py-2 px-6 flex items-center justify-around">
        <button
          onClick={() => setActiveTab('JOGOS')}
          className={`flex items-center gap-2 py-2 px-4 rounded-xl text-xs font-bold transition ${
            activeTab === 'JOGOS' ? 'bg-[#0084ff]/20 text-[#0084ff] font-black' : 'text-[#94a3b8] hover:text-white'
          }`}
        >
          <Gamepad2 className="w-4 h-4" />
          MEUS JOGOS
        </button>

        <button
          onClick={() => setActiveTab('HARDWARE')}
          className={`flex items-center gap-2 py-2 px-4 rounded-xl text-xs font-bold transition ${
            activeTab === 'HARDWARE' ? 'bg-[#0084ff]/20 text-[#0084ff] font-black' : 'text-[#94a3b8] hover:text-white'
          }`}
        >
          <Activity className="w-4 h-4" />
          TESTE TECLADO & MOUSE
        </button>

        <button
          onClick={() => setActiveTab('CONFIG')}
          className={`flex items-center gap-2 py-2 px-4 rounded-xl text-xs font-bold transition ${
            activeTab === 'CONFIG' ? 'bg-[#0084ff]/20 text-[#0084ff] font-black' : 'text-[#94a3b8] hover:text-white'
          }`}
        >
          <Settings className="w-4 h-4" />
          CONFIGURAÇÕES
        </button>
      </nav>

      {/* App Picker Modal */}
      {isAppPickerOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-[#0e1626] border-2 border-[#0084ff] rounded-2xl w-full max-w-lg p-5 space-y-4 text-white max-h-[85vh] flex flex-col shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1f2d48] pb-3">
              <div>
                <h3 className="text-sm font-bold text-white">ADICIONAR JOGOS DO CELULAR</h3>
                <p className="text-[10px] text-[#94a3b8]">Selecione qualquer jogo instalado no seu Android:</p>
              </div>
              <button onClick={() => setIsAppPickerOpen(false)} className="p-1 text-[#64748b] hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar jogo instalado..."
                className="w-full pl-9 pr-3 py-2 bg-black border border-[#233554] rounded-xl text-xs text-white placeholder-[#64748b] outline-none focus:border-[#0084ff]"
              />
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {INSTALLED_PHONE_GAMES.filter((g) =>
                g.title.toLowerCase().includes(searchQuery.toLowerCase())
              ).map((app) => (
                <div
                  key={app.id}
                  className="p-3 rounded-xl bg-[#131d31] border border-[#1f2d48] hover:border-[#0084ff] flex items-center justify-between transition"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${app.iconColor} flex items-center justify-center text-white shadow`}>
                      <Gamepad2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">{app.title}</h4>
                      <span className="text-[10px] text-[#64748b]">{app.category}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setIsAppPickerOpen(false);
                      onSelectScheme(app.id);
                    }}
                    className="px-3 py-1.5 bg-[#0084ff] hover:bg-[#0074e0] text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow"
                  >
                    <Plus className="w-3.5 h-3.5" /> Adicionar
                  </button>
                </div>
              ))}
            </div>

            {/* Custom Game Name Input */}
            <div className="pt-2 border-t border-[#1f2d48] flex items-center justify-between text-xs text-[#94a3b8]">
              <span>Não encontrou seu jogo?</span>
              <button
                onClick={() => {
                  const customName = prompt('Digite apenas o nome do jogo ou app:');
                  if (customName && customName.trim()) {
                    setIsAppPickerOpen(false);
                  }
                }}
                className="text-[#38bdf8] hover:underline font-bold"
              >
                + Digitar nome personalizado
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
