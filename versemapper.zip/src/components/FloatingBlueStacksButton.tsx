import React, { useState, useRef } from 'react';
import {
  Keyboard,
  Crosshair,
  Sliders,
  Eye,
  Check,
  X,
  Plus,
  Play,
  RotateCcw,
  Zap,
  LogOut,
  Maximize2
} from 'lucide-react';

interface Props {
  isEditorOpen: boolean;
  onToggleEditor: () => void;
  isPointerLocked: boolean;
  onTogglePointerLock: () => void;
  isEditMode: boolean;
  onToggleEditMode: () => void;
  hudOpacity: number;
  onChangeHudOpacity: (val: number) => void;
  onExitGame: () => void;
  onSave: () => void;
  onOpenMacro: () => void;
  gameTitle: string;
}

export const FloatingBlueStacksButton: React.FC<Props> = ({
  isEditorOpen,
  onToggleEditor,
  isPointerLocked,
  onTogglePointerLock,
  isEditMode,
  onToggleEditMode,
  hudOpacity,
  onChangeHudOpacity,
  onExitGame,
  onSave,
  onOpenMacro,
  gameTitle
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 8, y: 35 }); // percentage
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ startX: number; startY: number; initPos: { x: number; y: number } } | null>(null);

  const handlePointerDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initPos: { ...position }
    };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging || !dragStartRef.current) return;
    const parent = (e.currentTarget as HTMLElement).parentElement;
    if (!parent) return;

    const rect = parent.getBoundingClientRect();
    const deltaX = ((e.clientX - dragStartRef.current.startX) / rect.width) * 100;
    const deltaY = ((e.clientY - dragStartRef.current.startY) / rect.height) * 100;

    const newX = Math.max(4, Math.min(96, dragStartRef.current.initPos.x + deltaX));
    const newY = Math.max(5, Math.min(95, dragStartRef.current.initPos.y + deltaY));

    setPosition({ x: Math.round(newX * 10) / 10, y: Math.round(newY * 10) / 10 });
  };

  const handlePointerUp = () => {
    setIsDragging(false);
    dragStartRef.current = null;
  };

  return (
    <>
      {/* Draggable BlueStacks Floating Bubble */}
      <div
        style={{ left: `${position.x}%`, top: `${position.y}%` }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className={`absolute -translate-x-1/2 -translate-y-1/2 z-50 select-none cursor-grab active:cursor-grabbing transition-transform ${
          isDragging ? 'scale-110 drop-shadow-[0_0_25px_#0084ff]' : ''
        }`}
      >
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setIsOpen(!isOpen);
          }}
          className="w-13 h-13 rounded-full bg-[#0b101b]/95 border-2 border-[#0084ff] flex flex-col items-center justify-center shadow-[0_0_20px_rgba(0,132,255,0.7)] hover:scale-105 transition"
          title="Menu Flutuante BlueStacks Mobilador"
        >
          {/* BlueStacks 4-Color Stacked Diamond Logo */}
          <div className="relative w-5 h-5 flex items-center justify-center pointer-events-none">
            <div className="absolute w-3 h-3 bg-[#0084ff] rotate-45 -translate-y-1.5 rounded-[1.5px] shadow" />
            <div className="absolute w-3 h-3 bg-[#00e676] rotate-45 -translate-x-1.5 rounded-[1.5px] opacity-95" />
            <div className="absolute w-3 h-3 bg-[#ffd600] rotate-45 translate-x-1.5 rounded-[1.5px] opacity-95" />
            <div className="absolute w-3 h-3 bg-[#ff1744] rotate-45 translate-y-1.5 rounded-[1.5px] opacity-95" />
          </div>
          <span className="text-[7.5px] font-black tracking-tighter text-[#38bdf8] mt-0.5 pointer-events-none">
            BSTACKS
          </span>
        </button>

        {/* Pulse indicator when menu is open */}
        {isOpen && (
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 border-2 border-black rounded-full animate-ping pointer-events-none" />
        )}
      </div>

      {/* Floating Toolbar (Expands when tapping the BlueStacks bubble) */}
      {isOpen && (
        <div
          style={{
            left: `${Math.min(75, Math.max(25, position.x))}%`,
            top: `${position.y > 50 ? position.y - 12 : position.y + 12}%`
          }}
          className="absolute -translate-x-1/2 -translate-y-1/2 z-50 bg-[#0d1524]/95 border-2 border-[#0084ff] rounded-2xl p-2.5 shadow-[0_15px_50px_rgba(0,0,0,0.9)] backdrop-blur-md flex flex-wrap items-center justify-center gap-2 max-w-xl text-xs select-none"
        >
          {/* Header */}
          <div className="w-full flex items-center justify-between pb-1.5 border-b border-[#1f2d48] px-1">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-white text-xs">BLUESTACKS MOBILADOR</span>
              <span className="text-[10px] text-[#38bdf8] font-mono">· {gameTitle}</span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-[#64748b] hover:text-white rounded"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Buttons */}
          <button
            onClick={() => {
              onToggleEditor();
              setIsOpen(false);
            }}
            className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition ${
              isEditorOpen
                ? 'bg-[#0084ff] text-white shadow-[0_0_12px_rgba(0,132,255,0.6)]'
                : 'bg-[#162238] hover:bg-[#1f2d48] text-white'
            }`}
          >
            <Keyboard className="w-3.5 h-3.5 text-[#38bdf8]" />
            Editor de Controles (Ctrl+Shift+A)
          </button>

          <button
            onClick={onTogglePointerLock}
            className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition ${
              isPointerLocked
                ? 'bg-emerald-500 text-black shadow-[0_0_12px_#10b981]'
                : 'bg-[#162238] hover:bg-[#1f2d48] text-[#38bdf8]'
            }`}
          >
            <Crosshair className="w-3.5 h-3.5" />
            {isPointerLocked ? 'Trava Ativa (F1)' : 'Travar Mira (F1)'}
          </button>

          <button
            onClick={onToggleEditMode}
            className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition ${
              isEditMode
                ? 'bg-amber-400 text-black shadow'
                : 'bg-[#162238] hover:bg-[#1f2d48] text-[#cbd5e1]'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            {isEditMode ? 'Modo Edição (Arrastar)' : 'Modo Jogo (Ativo)'}
          </button>

          <button
            onClick={onOpenMacro}
            className="px-3 py-1.5 bg-[#162238] hover:bg-[#1f2d48] rounded-xl font-bold text-amber-300 flex items-center gap-1"
          >
            <Zap className="w-3.5 h-3.5" />
            Macros
          </button>

          <div className="flex items-center gap-1.5 px-2 bg-black/60 rounded-xl py-1 border border-[#1f2d48]">
            <Eye className="w-3.5 h-3.5 text-[#38bdf8]" />
            <input
              type="range"
              min="0"
              max="100"
              value={hudOpacity}
              onChange={(e) => onChangeHudOpacity(parseInt(e.target.value))}
              className="w-16 h-1.5 accent-[#0084ff]"
              title="Opacidade das teclas na tela"
            />
            <span className="text-[10px] font-mono text-white w-6">{hudOpacity}%</span>
          </div>

          <button
            onClick={() => {
              onSave();
              setIsOpen(false);
            }}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold flex items-center gap-1 shadow"
          >
            <Check className="w-3.5 h-3.5" />
            Salvar HUD
          </button>

          <button
            onClick={onExitGame}
            className="px-3 py-1.5 bg-red-600/30 hover:bg-red-600 border border-red-500/40 text-red-300 hover:text-white rounded-xl font-bold flex items-center gap-1 transition"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sair do Jogo
          </button>
        </div>
      )}
    </>
  );
};
