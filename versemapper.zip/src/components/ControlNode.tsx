import React, { useState } from 'react';
import { ControlItem } from '../types/bluestacks';
import { Settings, X, Crosshair, Move, Repeat, Eye, ZoomIn, Zap, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';

interface Props {
  control: ControlItem;
  isEditorOpen: boolean;
  isSelected: boolean;
  onSelect: (id: string) => void;
  onPointerDown: (e: React.PointerEvent, id: string) => void;
  onOpenSettings: (control: ControlItem) => void;
  onDelete: (id: string) => void;
  isKeyPressed: boolean;
  hudOpacity: number;
}

export const ControlNode: React.FC<Props> = ({
  control,
  isEditorOpen,
  isSelected,
  onSelect,
  onPointerDown,
  onOpenSettings,
  onDelete,
  isKeyPressed,
  hudOpacity
}) => {
  const [isHovered, setIsHovered] = useState(false);

  // Render D-Pad (Classic BlueStacks 4-way WASD circle)
  if (control.type === 'DPAD') {
    return (
      <div
        style={{
          left: `${control.x}%`,
          top: `${control.y}%`,
          opacity: isEditorOpen ? 1 : hudOpacity / 100,
          touchAction: 'none'
        }}
        onPointerDown={(e) => onPointerDown(e, control.id)}
        onContextMenu={(e) => {
          e.preventDefault();
          onOpenSettings(control);
        }}
        onClick={(e) => {
          e.stopPropagation();
          onSelect(control.id);
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className={`absolute -translate-x-1/2 -translate-y-1/2 select-none z-20 ${
          isEditorOpen ? 'cursor-grab active:cursor-grabbing' : 'pointer-events-none'
        } ${isSelected && isEditorOpen ? 'ring-2 ring-[#0084ff] ring-offset-2 ring-offset-black rounded-full' : ''}`}
      >
        <div className={`relative w-28 h-28 rounded-full border-2 border-[#0084ff]/80 bg-[#0084ff]/10 backdrop-blur-sm flex items-center justify-center transition-all ${
          isKeyPressed ? 'scale-105 border-[#38bdf8] bg-[#0084ff]/30 shadow-[0_0_20px_rgba(0,132,255,0.6)]' : ''
        }`}>
          {/* Central crosshair */}
          <div className="w-2.5 h-2.5 rounded-full bg-[#0084ff]" />

          {/* Up (W) */}
          <div className={`absolute top-1.5 w-6 h-6 rounded-full border border-white/80 bg-black/85 flex items-center justify-center text-[10px] font-black text-white ${
            isKeyPressed ? 'bg-[#0084ff] border-white' : ''
          }`}>
            {control.upKey || 'W'}
          </div>

          {/* Down (S) */}
          <div className="absolute bottom-1.5 w-6 h-6 rounded-full border border-white/80 bg-black/85 flex items-center justify-center text-[10px] font-black text-white">
            {control.downKey || 'S'}
          </div>

          {/* Left (A) */}
          <div className="absolute left-1.5 w-6 h-6 rounded-full border border-white/80 bg-black/85 flex items-center justify-center text-[10px] font-black text-white">
            {control.leftKey || 'A'}
          </div>

          {/* Right (D) */}
          <div className="absolute right-1.5 w-6 h-6 rounded-full border border-white/80 bg-black/85 flex items-center justify-center text-[10px] font-black text-white">
            {control.rightKey || 'D'}
          </div>

          {/* Label */}
          <span className="absolute -bottom-5 px-1.5 py-0.5 rounded bg-black/80 border border-[#1f2d48] text-[9px] font-semibold text-[#94a3b8] whitespace-nowrap">
            D-Pad (WASD)
          </span>

          {/* Edit / Delete quick buttons */}
          {isEditorOpen && (isHovered || isSelected) && (
            <div className="absolute -top-3 -right-3 flex items-center gap-1 z-30">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenSettings(control);
                }}
                className="w-5 h-5 rounded-full bg-[#162238] border border-[#233554] hover:bg-[#0084ff] text-white flex items-center justify-center text-[10px] shadow"
                title="Configurações Avançadas"
              >
                <Settings className="w-2.5 h-2.5" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(control.id);
                }}
                className="w-5 h-5 rounded-full bg-red-600/90 hover:bg-red-500 text-white flex items-center justify-center text-[10px] shadow"
                title="Excluir controle"
              >
                <X className="w-2.5 h-2.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Render Aim, Pan and Shoot (Modo FPS - Legendary BlueStacks Crosshair Hub)
  if (control.type === 'AIM_PAN_SHOOT') {
    return (
      <div
        style={{
          left: `${control.x}%`,
          top: `${control.y}%`,
          opacity: isEditorOpen ? 1 : hudOpacity / 100,
          touchAction: 'none'
        }}
        onPointerDown={(e) => onPointerDown(e, control.id)}
        onContextMenu={(e) => {
          e.preventDefault();
          onOpenSettings(control);
        }}
        onClick={(e) => {
          e.stopPropagation();
          onSelect(control.id);
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className={`absolute -translate-x-1/2 -translate-y-1/2 select-none z-20 ${
          isEditorOpen ? 'cursor-grab active:cursor-grabbing' : 'pointer-events-none'
        } ${isSelected && isEditorOpen ? 'ring-2 ring-[#0084ff] ring-offset-2 ring-offset-black rounded-full' : ''}`}
      >
        <div className="relative w-20 h-20 rounded-full border-2 border-dashed border-[#0084ff] bg-[#0084ff]/15 flex items-center justify-center shadow-[0_0_15px_rgba(0,132,255,0.4)]">
          {/* Inner solid circle with Hotkey */}
          <div className="w-11 h-11 rounded-full bg-[#0084ff] border-2 border-white flex flex-col items-center justify-center text-white shadow-lg">
            <Crosshair className="w-3.5 h-3.5" />
            <span className="text-[10px] font-black leading-none mt-0.5">{control.startStopKey || 'F1'}</span>
          </div>

          <span className="absolute -bottom-5 px-1.5 py-0.5 rounded bg-black/90 border border-[#0084ff] text-[9px] font-mono font-bold text-[#38bdf8] whitespace-nowrap shadow">
            FPS Mode · X:{control.sensX} Y:{control.sensY} (Tw:{control.tweaks || 16450})
          </span>

          {/* Quick buttons */}
          {isEditorOpen && (isHovered || isSelected) && (
            <div className="absolute -top-2 -right-2 flex items-center gap-1 z-30">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenSettings(control);
                }}
                className="w-5 h-5 rounded-full bg-[#162238] border border-[#233554] hover:bg-[#0084ff] text-white flex items-center justify-center text-[10px] shadow"
                title="Configurações Avançadas do Modo FPS"
              >
                <Settings className="w-2.5 h-2.5" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(control.id);
                }}
                className="w-5 h-5 rounded-full bg-red-600/90 hover:bg-red-500 text-white flex items-center justify-center text-[10px] shadow"
                title="Excluir"
              >
                <X className="w-2.5 h-2.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Render Fire Button (Gatilho de Tiro - Mouse 1)
  if (control.type === 'FIRE_BUTTON') {
    return (
      <div
        style={{
          left: `${control.x}%`,
          top: `${control.y}%`,
          opacity: isEditorOpen ? 1 : hudOpacity / 100,
          touchAction: 'none'
        }}
        onPointerDown={(e) => onPointerDown(e, control.id)}
        onContextMenu={(e) => {
          e.preventDefault();
          onOpenSettings(control);
        }}
        onClick={(e) => {
          e.stopPropagation();
          onSelect(control.id);
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className={`absolute -translate-x-1/2 -translate-y-1/2 select-none z-20 ${
          isEditorOpen ? 'cursor-grab active:cursor-grabbing' : 'pointer-events-none'
        } ${isSelected && isEditorOpen ? 'ring-2 ring-red-400 ring-offset-2 ring-offset-black rounded-full' : ''}`}
      >
        <div className={`w-12 h-12 rounded-full border-2 border-red-500 bg-red-600/30 flex flex-col items-center justify-center text-white shadow-[0_0_15px_rgba(239,68,68,0.5)] transition ${
          isKeyPressed ? 'scale-110 bg-red-500 text-black shadow-[0_0_25px_rgba(239,68,68,0.9)]' : ''
        }`}>
          <Crosshair className="w-4 h-4 text-white" />
          <span className="text-[8px] font-black uppercase tracking-tight">Tiro</span>

          {isEditorOpen && (isHovered || isSelected) && (
            <div className="absolute -top-2 -right-2 flex items-center gap-1 z-30">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(control.id);
                }}
                className="w-4 h-4 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center text-[9px] shadow"
              >
                <X className="w-2.5 h-2.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Standard Tap Spot (Ponto de Toque) or Repeated Tap or Free Look
  return (
    <div
      style={{
        left: `${control.x}%`,
        top: `${control.y}%`,
        opacity: isEditorOpen ? 1 : hudOpacity / 100,
        touchAction: 'none'
      }}
      onPointerDown={(e) => onPointerDown(e, control.id)}
      onContextMenu={(e) => {
        e.preventDefault();
        onOpenSettings(control);
      }}
      onClick={(e) => {
        e.stopPropagation();
        onSelect(control.id);
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`absolute -translate-x-1/2 -translate-y-1/2 select-none z-20 ${
        isEditorOpen ? 'cursor-grab active:cursor-grabbing' : 'pointer-events-none'
      } ${isSelected && isEditorOpen ? 'ring-2 ring-[#0084ff] ring-offset-2 ring-offset-black rounded-full' : ''}`}
    >
      <div className={`min-w-8 h-8 px-2 rounded-full border-2 border-white/90 bg-black/90 flex items-center justify-center text-white text-[11px] font-black shadow-xl transition-all ${
        isKeyPressed ? 'scale-125 bg-[#0084ff] border-[#38bdf8] text-white shadow-[0_0_15px_#0084ff]' : ''
      }`}>
        {control.type === 'FREE_LOOK' && <Eye className="w-3 h-3 mr-1 text-cyan-400" />}
        {control.type === 'REPEATED_TAP' && <Repeat className="w-3 h-3 mr-1 text-amber-400" />}
        {control.type === 'SCRIPT' && <Zap className="w-3 h-3 mr-1 text-amber-400" />}
        <span>{control.hotkey}</span>

        {/* Quick action handles in editor */}
        {isEditorOpen && (isHovered || isSelected) && (
          <div className="absolute -top-2.5 -right-2.5 flex items-center gap-0.5 z-30">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onOpenSettings(control);
              }}
              className="w-4 h-4 rounded-full bg-[#162238] border border-[#233554] hover:bg-[#0084ff] text-white flex items-center justify-center text-[9px] shadow"
              title="Configurar"
            >
              <Settings className="w-2.5 h-2.5" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDelete(control.id);
              }}
              className="w-4 h-4 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center text-[9px] shadow"
              title="Excluir"
            >
              <X className="w-2.5 h-2.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
