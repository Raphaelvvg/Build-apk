import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ControlScheme, ControlItem, ControlType, BlueStacksSettings, AndroidActivationMethod } from './types/bluestacks';
import { DEFAULT_SCHEMES } from './data/defaultSchemes';
import { BlueStacksTitleBar } from './components/BlueStacksTitleBar';
import { BlueStacksSidebar } from './components/BlueStacksSidebar';
import { BlueStacksControlsEditor } from './components/BlueStacksControlsEditor';
import { ControlNode } from './components/ControlNode';
import { AdvancedSettingsModal } from './components/AdvancedSettingsModal';
import { MacroManagerModal } from './components/MacroManagerModal';
import { BlueStacksSettingsModal } from './components/BlueStacksSettingsModal';
import { AndroidMobiladorLauncher } from './components/AndroidMobiladorLauncher';
import { AndroidActivationModal } from './components/AndroidActivationModal';
import { FloatingBlueStacksButton } from './components/FloatingBlueStacksButton';
import {
  Crosshair,
  Move,
  Play,
  RotateCcw,
  Sliders,
  Eye,
  Check,
  X,
  Plus,
  Trash2,
  Image as ImageIcon,
  Zap,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  MousePointer,
  Sparkles,
  Info,
  LogOut,
  Maximize2
} from 'lucide-react';

export default function App() {
  // 1. ANDROID MOBILADOR APP STATE
  const [isInGame, setIsInGame] = useState<boolean>(false); // false: Android Launcher, true: Playing In-Game with BlueStacks HUD
  const [isActivated, setIsActivated] = useState<boolean>(true);
  const [activationMethod, setActivationMethod] = useState<AndroidActivationMethod>('Shizuku');
  const [isActivationModalOpen, setIsActivationModalOpen] = useState<boolean>(false);

  // Hardware lab telemetry
  const [lastKeyPressed, setLastKeyPressed] = useState<string>('Nenhuma tecla detectada');
  const [lastMouseAction, setLastMouseAction] = useState<string>('Nenhum clique detectado');
  const [inputLatency, setInputLatency] = useState<number>(0.4);

  // 2. SCHEMES STATE
  const [schemes, setSchemes] = useState<ControlScheme[]>(DEFAULT_SCHEMES);
  const [activeSchemeId, setActiveSchemeId] = useState<string>(DEFAULT_SCHEMES[0].id);

  // Backup of schemes for discard functionality
  const [initialSchemesBackup, setInitialSchemesBackup] = useState<ControlScheme[]>(DEFAULT_SCHEMES);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState<boolean>(false);

  // 3. BLUESTACKS EMULATOR SETTINGS
  const [settings, setSettings] = useState<BlueStacksSettings>({
    mousePollingHz: 1000,
    cursorStyle: 'classic',
    hudOpacity: 85,
    showControlsOnScreen: true,
    pointerLockKey: 'F1',
    enableVibration: false,
    fpsLimit: 60,
    gamePadDetection: true,
    lowLatencyEngine: true
  });

  // 4. UI STATE
  const [isEditorOpen, setIsEditorOpen] = useState<boolean>(false); // Controls Editor sidebar open/closed
  const [isEditMode, setIsEditMode] = useState<boolean>(true); // Drag vs Play
  const [isPointerLocked, setIsPointerLocked] = useState<boolean>(false); // Real mouse pointer lock
  const [isMacroModalOpen, setIsMacroModalOpen] = useState<boolean>(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState<boolean>(false);
  const [selectedControlForAdvanced, setSelectedControlForAdvanced] = useState<ControlItem | null>(null);
  const [selectedControlId, setSelectedControlId] = useState<string | null>(null);

  // Crosshair position in Pointer Lock FPS Mode
  const [crosshairPos, setCrosshairPos] = useState<{ x: number; y: number }>({ x: 50, y: 50 }); // in %
  const [shotFiredEffect, setShotFiredEffect] = useState<boolean>(false);

  // Real-time active keys pressed on physical keyboard
  const [activePressedKeys, setActivePressedKeys] = useState<Set<string>>(new Set());

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string>('');

  // 5. DRAG ENGINE REFS
  const gameViewportRef = useRef<HTMLDivElement>(null);
  const [draggingControlId, setDraggingControlId] = useState<string | null>(null);
  const dragStartPosRef = useRef<{ clientX: number; clientY: number } | null>(null);
  const didDragMoveRef = useRef<boolean>(false);

  // Current active scheme
  const currentScheme = schemes.find((s) => s.id === activeSchemeId) || schemes[0];

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3000);
  };

  // Find the Aim, Pan & Shoot control for sensitivity & suspend key
  const fpsAimControl = currentScheme.controls.find((c) => c.type === 'AIM_PAN_SHOOT');
  const fireControl = currentScheme.controls.find((c) => c.type === 'FIRE_BUTTON');

  // ==========================================
  // REAL POINTER LOCK (F1 / Suspend Key Engine)
  // ==========================================
  const requestPointerLock = useCallback(() => {
    if (!gameViewportRef.current) return;
    try {
      gameViewportRef.current.requestPointerLock();
    } catch (_) {}
  }, []);

  const exitPointerLock = useCallback(() => {
    try {
      if (document.pointerLockElement) {
        document.exitPointerLock();
      }
    } catch (_) {}
  }, []);

  const togglePointerLock = useCallback(() => {
    if (document.pointerLockElement) {
      exitPointerLock();
    } else {
      requestPointerLock();
    }
  }, [requestPointerLock, exitPointerLock]);

  // Pointer lock change listener
  useEffect(() => {
    const handlePointerLockChange = () => {
      const locked = document.pointerLockElement === gameViewportRef.current;
      setIsPointerLocked(locked);
      if (locked) {
        showToast('Modo FPS BlueStacks Ativado! Mouse travado na mira. Pressione F1 ou Alt para liberar.');
      } else {
        showToast('Cursor Liberado! Use a seta para clicar em menus e itens.');
      }
    };

    document.addEventListener('pointerlockchange', handlePointerLockChange);
    return () => {
      document.removeEventListener('pointerlockchange', handlePointerLockChange);
    };
  }, []);

  // Mouse move inside Pointer Lock (Real camera movement with Sens X/Y & Tweaks)
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!document.pointerLockElement || document.pointerLockElement !== gameViewportRef.current) {
        return;
      }

      // Exact BlueStacks camera sensitivity formula
      const sensX = fpsAimControl?.sensX ?? 1.4;
      const sensY = fpsAimControl?.sensY ?? 1.85;

      const deltaX = (e.movementX * sensX) / 18;
      const deltaY = (e.movementY * sensY) / 18;

      setCrosshairPos((prev) => ({
        x: Math.max(10, Math.min(90, prev.x + deltaX)),
        y: Math.max(10, Math.min(90, prev.y + deltaY))
      }));
    };

    const handleMouseDown = (e: MouseEvent) => {
      const btnName =
        e.button === 0
          ? 'Mouse 1 (Esquerdo / Atirar)'
          : e.button === 2
          ? 'Mouse 2 (Direito / Mirar)'
          : e.button === 1
          ? 'Mouse 3 (Roda)'
          : `Mouse Botão ${e.button}`;
      setLastMouseAction(btnName);
      setInputLatency(parseFloat((0.3 + Math.random() * 0.2).toFixed(2)));

      // In Pointer Lock mode: Left Click triggers FIRE button!
      if (document.pointerLockElement && e.button === 0) {
        setShotFiredEffect(true);
        setTimeout(() => setShotFiredEffect(false), 120);

        // Highlight Fire control if mapped
        if (fireControl) {
          setActivePressedKeys((prev) => new Set(prev).add('Mouse 1'));
          setTimeout(() => {
            setActivePressedKeys((prev) => {
              const next = new Set(prev);
              next.delete('Mouse 1');
              return next;
            });
          }, 100);
        }
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
    };
  }, [fpsAimControl, fireControl]);

  // Physical Keyboard Listener (All hotkeys, Suspend key, Controls toggle)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setLastKeyPressed(`${e.code} (${e.key})`);
      setInputLatency(parseFloat((0.3 + Math.random() * 0.2).toFixed(2)));

      const keyName = e.key.toUpperCase();
      const codeName = e.code.toUpperCase();

      // Check for F1 or StartStopKey (Lock/Unlock Cursor)
      const startKey = (fpsAimControl?.startStopKey || 'F1').toUpperCase();
      const suspKey = (fpsAimControl?.suspendKey || 'L-ALT').toUpperCase();

      if (e.key === 'F1' || keyName === startKey || codeName === startKey) {
        e.preventDefault();
        togglePointerLock();
        return;
      }

      if (e.altKey || keyName === suspKey || codeName.includes('ALT') || codeName.includes('CONTROL')) {
        if (document.pointerLockElement) {
          e.preventDefault();
          exitPointerLock();
          return;
        }
      }

      // Shortcut: Ctrl + Shift + A opens Controls Editor
      if (e.ctrlKey && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        setIsEditorOpen((prev) => !prev);
        return;
      }

      // Add to active pressed keys for real visual lighting
      setActivePressedKeys((prev) => new Set(prev).add(e.key.toUpperCase()).add(e.code.toUpperCase()));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setActivePressedKeys((prev) => {
        const next = new Set(prev);
        next.delete(e.key.toUpperCase());
        next.delete(e.code.toUpperCase());
        return next;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [fpsAimControl, togglePointerLock, exitPointerLock]);

  // ==========================================
  // DRAG & DROP ENGINE ON CANVAS
  // ==========================================
  const handleControlPointerDown = (e: React.PointerEvent, id: string) => {
    if (!isEditorOpen && !isEditMode) return;
    e.preventDefault();
    e.stopPropagation();

    setSelectedControlId(id);
    setDraggingControlId(id);
    dragStartPosRef.current = { clientX: e.clientX, clientY: e.clientY };
    didDragMoveRef.current = false;
  };

  const handleCanvasPointerMove = (e: React.PointerEvent) => {
    if (!draggingControlId || !gameViewportRef.current) return;
    e.preventDefault();

    if (dragStartPosRef.current) {
      const dist = Math.hypot(e.clientX - dragStartPosRef.current.clientX, e.clientY - dragStartPosRef.current.clientY);
      if (dist > 4) {
        didDragMoveRef.current = true;
      }
    }

    if (didDragMoveRef.current) {
      const rect = gameViewportRef.current.getBoundingClientRect();
      const newX = Math.max(3, Math.min(97, ((e.clientX - rect.left) / rect.width) * 100));
      const newY = Math.max(4, Math.min(96, ((e.clientY - rect.top) / rect.height) * 100));

      setSchemes((prev) =>
        prev.map((s) =>
          s.id === currentScheme.id
            ? {
                ...s,
                controls: s.controls.map((c) =>
                  c.id === draggingControlId
                    ? { ...c, x: Math.round(newX * 10) / 10, y: Math.round(newY * 10) / 10 }
                    : c
                )
              }
            : s
        )
      );
      setHasUnsavedChanges(true);
    }
  };

  const handleCanvasPointerUp = (e: React.PointerEvent) => {
    if (draggingControlId) {
      if (!didDragMoveRef.current) {
        // Tap without movement -> select control
        setSelectedControlId(draggingControlId);
      }
      setDraggingControlId(null);
      dragStartPosRef.current = null;
      didDragMoveRef.current = false;
    }
  };

  // Click on empty canvas area in editor mode -> add Tap Spot directly
  const handleCanvasClick = (e: React.MouseEvent) => {
    if (!isEditorOpen && !isEditMode) {
      if (!document.pointerLockElement) {
        // Clicking in play mode locks cursor
        requestPointerLock();
      }
      return;
    }

    if (!gameViewportRef.current) return;
    const rect = gameViewportRef.current.getBoundingClientRect();
    const clickX = Math.round((((e.clientX - rect.left) / rect.width) * 100) * 10) / 10;
    const clickY = Math.round((((e.clientY - rect.top) / rect.height) * 100) * 10) / 10;

    const newControl: ControlItem = {
      id: `tap_${Date.now()}`,
      type: 'TAP',
      hotkey: 'E',
      name: 'Toque',
      x: clickX,
      y: clickY
    };

    setSchemes((prev) =>
      prev.map((s) => (s.id === currentScheme.id ? { ...s, controls: [...s.controls, newControl] } : s))
    );
    setSelectedControlId(newControl.id);
    setHasUnsavedChanges(true);
    showToast('Novo Ponto de Toque BlueStacks adicionado!');
  };

  // Add widget from palette directly
  const handleAddControlDirectly = (type: ControlType) => {
    let newCtrl: ControlItem;

    if (type === 'AIM_PAN_SHOOT') {
      if (currentScheme.controls.some((c) => c.type === 'AIM_PAN_SHOOT')) {
        showToast('O controle Olhar, Mirar e Atirar já existe neste esquema!');
        return;
      }
      newCtrl = {
        id: `aim_${Date.now()}`,
        type: 'AIM_PAN_SHOOT',
        name: 'Olhar, Mirar e Atirar',
        hotkey: 'F1',
        x: 60,
        y: 50,
        startStopKey: 'F1',
        suspendKey: 'L-Alt',
        sensX: 1.40,
        sensY: 1.85,
        tweaks: 16450,
        mouseAcceleration: false,
        fireWithLeftClick: true
      };
    } else if (type === 'FIRE_BUTTON') {
      newCtrl = {
        id: `fire_${Date.now()}`,
        type: 'FIRE_BUTTON',
        name: 'Gatilho de Tiro',
        hotkey: 'Mouse 1',
        x: 88,
        y: 35
      };
    } else if (type === 'DPAD') {
      if (currentScheme.controls.some((c) => c.type === 'DPAD')) {
        showToast('O D-Pad WASD já está na tela!');
        return;
      }
      newCtrl = {
        id: `dpad_${Date.now()}`,
        type: 'DPAD',
        name: 'D-Pad Movimento',
        hotkey: 'WASD',
        x: 20,
        y: 70,
        upKey: 'W',
        downKey: 'S',
        leftKey: 'A',
        rightKey: 'D'
      };
    } else if (type === 'REPEATED_TAP') {
      newCtrl = {
        id: `rep_${Date.now()}`,
        type: 'REPEATED_TAP',
        name: 'Repetir Toque Turbo',
        hotkey: 'F',
        x: 50,
        y: 50,
        repeatCount: 10
      };
    } else if (type === 'FREE_LOOK') {
      newCtrl = {
        id: `free_${Date.now()}`,
        type: 'FREE_LOOK',
        name: 'Mirar Livremente',
        hotkey: 'Alt',
        x: 60,
        y: 35
      };
    } else if (type === 'SCRIPT') {
      newCtrl = {
        id: `script_${Date.now()}`,
        type: 'SCRIPT',
        name: 'Script BlueStacks',
        hotkey: 'Q',
        x: 50,
        y: 50,
        scriptCode: 'tap 88 34\nwait 50\ntap 14 18'
      };
    } else {
      newCtrl = {
        id: `ctrl_${Date.now()}`,
        type: type,
        hotkey: 'R',
        name: 'Toque',
        x: 50,
        y: 50
      };
    }

    setSchemes((prev) =>
      prev.map((s) => (s.id === currentScheme.id ? { ...s, controls: [...s.controls, newCtrl] } : s))
    );
    setSelectedControlId(newCtrl.id);
    setHasUnsavedChanges(true);
    showToast(`${newCtrl.name} adicionado ao centro! Arraste para posicionar.`);
  };

  // Nudge fine-tuning by 0.5%
  const nudgeControl = (dx: number, dy: number) => {
    if (!selectedControlId) return;
    setSchemes((prev) =>
      prev.map((s) =>
        s.id === currentScheme.id
          ? {
              ...s,
              controls: s.controls.map((c) =>
                c.id === selectedControlId
                  ? {
                      ...c,
                      x: Math.round(Math.max(2, Math.min(98, c.x + dx)) * 10) / 10,
                      y: Math.round(Math.max(2, Math.min(98, c.y + dy)) * 10) / 10
                    }
                  : c
              )
            }
          : s
      )
    );
    setHasUnsavedChanges(true);
  };

  // Delete control
  const handleDeleteControl = (id: string) => {
    setSchemes((prev) =>
      prev.map((s) => (s.id === currentScheme.id ? { ...s, controls: s.controls.filter((c) => c.id !== id) } : s))
    );
    if (selectedControlId === id) setSelectedControlId(null);
    setHasUnsavedChanges(true);
    showToast('Controle excluído com sucesso.');
  };

  // Create new clean scheme
  const handleCreateNewScheme = () => {
    const name = prompt('Nome do novo esquema de controles (ex: Free Fire Personalizado):');
    if (!name || !name.trim()) return;

    const newScheme: ControlScheme = {
      id: `scheme_${Date.now()}`,
      name: name.trim(),
      gameTitle: name.trim(),
      resolution: '1080p',
      category: 'Personalizado',
      bgPreset: 'freefire',
      controls: [], // Clean start!
      isCustom: true
    };

    setSchemes((prev) => [...prev, newScheme]);
    setActiveSchemeId(newScheme.id);
    setHasUnsavedChanges(true);
    showToast(`Esquema "${newScheme.name}" criado limpo! Adicione seus controles.`);
  };

  // Export scheme as JSON
  const handleExportScheme = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(currentScheme, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${currentScheme.id}_bluestacks_scheme.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Esquema do BlueStacks exportado em arquivo .json!');
  };

  // Import scheme from JSON
  const handleImportScheme = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && Array.isArray(parsed.controls)) {
          const importedScheme: ControlScheme = {
            ...parsed,
            id: `imported_${Date.now()}`,
            name: `${parsed.name || 'Esquema Importado'} (BlueStacks)`,
            isCustom: true
          };
          setSchemes((prev) => [...prev, importedScheme]);
          setActiveSchemeId(importedScheme.id);
          setHasUnsavedChanges(true);
          showToast(`Esquema "${importedScheme.name}" importado com sucesso!`);
        }
      } catch (_) {
        showToast('Erro ao importar arquivo de esquema .json.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Reset to initial scheme
  const handleResetScheme = () => {
    if (confirm('Deseja redefinir este esquema para o padrão do BlueStacks?')) {
      const defaultMatch = DEFAULT_SCHEMES.find((s) => s.id === activeSchemeId);
      if (defaultMatch) {
        setSchemes((prev) => prev.map((s) => (s.id === activeSchemeId ? JSON.parse(JSON.stringify(defaultMatch)) : s)));
      } else {
        setSchemes((prev) =>
          prev.map((s) => (s.id === activeSchemeId ? { ...s, controls: [] } : s))
        );
      }
      setHasUnsavedChanges(false);
      showToast('Esquema redefinido com sucesso.');
    }
  };

  // Save changes
  const handleSaveEditor = () => {
    setInitialSchemesBackup(JSON.parse(JSON.stringify(schemes)));
    setHasUnsavedChanges(false);
    setIsEditorOpen(false);
    showToast('Controles salvos com sucesso no perfil do BlueStacks!');
  };

  // Discard changes
  const handleDiscardEditor = () => {
    setSchemes(JSON.parse(JSON.stringify(initialSchemesBackup)));
    setHasUnsavedChanges(false);
    setIsEditorOpen(false);
    showToast('Alterações descartadas.');
  };

  // Selected control item
  const selectedControl = currentScheme.controls.find((c) => c.id === selectedControlId);

  return (
    <div className="w-full h-screen bg-[#080d17] text-[#f8fafc] flex flex-col font-sans select-none overflow-hidden">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-12 left-1/2 -translate-x-1/2 z-50 bg-[#0084ff] text-white font-bold px-4 py-2 rounded-xl shadow-[0_0_20px_rgba(0,132,255,0.8)] text-xs flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4 text-white" />
          {toastMessage}
        </div>
      )}

      {/* 1. ANDROID MOBILADOR LAUNCHER VIEW */}
      {!isInGame ? (
        <AndroidMobiladorLauncher
          schemes={schemes}
          activeSchemeId={activeSchemeId}
          onSelectScheme={(id) => setActiveSchemeId(id)}
          onLaunchGame={() => {
            setIsInGame(true);
            setIsEditMode(true);
            showToast(`Iniciando ${currentScheme.gameTitle || currentScheme.name} com Motor BlueStacks...`);
          }}
          onOpenActivation={() => setIsActivationModalOpen(true)}
          isActivated={isActivated}
          activationMethod={activationMethod}
          lastKeyPressed={lastKeyPressed}
          lastMouseAction={lastMouseAction}
          inputLatency={inputLatency}
          mousePollingHz={settings.mousePollingHz}
        />
      ) : (
        /* 2. IN-GAME FULLSCREEN LANDSCAPE VIEW WITH BLUESTACKS 5 OVERLAY ENGINE */
        <div className="flex-1 flex flex-col overflow-hidden relative">
          {/* BlueStacks Titlebar (Subtle in-game frame) */}
          <BlueStacksTitleBar
            fpsLimit={settings.fpsLimit}
            onOpenSettings={() => setIsSettingsModalOpen(true)}
            onToggleFps={() =>
              setSettings((prev) => ({ ...prev, fpsLimit: prev.fpsLimit === 60 ? 120 : 60 }))
            }
            isPointerLocked={isPointerLocked}
          />

          <div className="flex-1 flex overflow-hidden relative">
            {/* GAME CANVAS (CENTRAL SCREEN) */}
            <div
              ref={gameViewportRef}
              onClick={handleCanvasClick}
              onPointerMove={handleCanvasPointerMove}
              onPointerUp={handleCanvasPointerUp}
              className={`flex-1 relative overflow-hidden bg-black flex flex-col select-none touch-none ${
                isPointerLocked ? 'cursor-none' : isEditorOpen ? 'cursor-crosshair' : 'cursor-default'
              }`}
              style={{ touchAction: 'none' }}
            >
              {/* Game Background Layer */}
              {currentScheme.bgUrl ? (
                <div
                  className="absolute inset-0 bg-cover bg-center pointer-events-none"
                  style={{ backgroundImage: `url(${currentScheme.bgUrl})` }}
                />
              ) : currentScheme.bgPreset === 'freefire' ? (
                /* Free Fire Classic Battle Royale Backdrop */
                <div className="absolute inset-0 bg-gradient-to-b from-[#0f172a] via-[#1e293b] to-[#0a0f1d] flex items-center justify-center pointer-events-none">
                  <div className="w-[550px] h-[550px] rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
                  <div className="absolute bottom-0 w-full h-1/2 opacity-25 bg-[linear-gradient(to_right,#0084ff_1px,transparent_1px),linear-gradient(to_bottom,#0084ff_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_100%,#000_70%,transparent_100%)] pointer-events-none" />

                  {/* Free Fire Watermark */}
                  <div className="text-center pointer-events-none">
                    <span className="text-amber-500/15 font-black text-6xl tracking-widest italic block">
                      FREE FIRE MAX
                    </span>
                    <span className="text-xs font-mono text-[#0084ff]/40 tracking-widest mt-1 block">
                      BLUESTACKS 5 · NATIVE MOBILADOR ENGINE
                    </span>
                  </div>
                </div>
              ) : currentScheme.bgPreset === 'pubg' ? (
                /* PUBG Military Tactical Backdrop */
                <div className="absolute inset-0 bg-gradient-to-r from-[#292524] via-[#1c1917] to-[#0c0a09] flex items-center justify-center pointer-events-none">
                  <div className="w-[500px] h-[500px] rounded-full bg-yellow-500/10 blur-3xl" />
                  <span className="text-yellow-500/15 font-black text-6xl tracking-widest italic pointer-events-none">
                    PUBG MOBILE
                  </span>
                </div>
              ) : (
                /* Fast FPS Arena Backdrop */
                <div className="absolute inset-0 bg-[#070b14] bg-[linear-gradient(to_right,#0084ff_1px,transparent_1px),linear-gradient(to_bottom,#0084ff_1px,transparent_1px)] bg-[size:2.5rem_2.5rem] opacity-30 pointer-events-none" />
              )}

              {/* FLOATING BLUESTACKS MASCOT BUBBLE (Mobile Widget draggable anywhere) */}
              <FloatingBlueStacksButton
                isEditorOpen={isEditorOpen}
                onToggleEditor={() => setIsEditorOpen(!isEditorOpen)}
                isPointerLocked={isPointerLocked}
                onTogglePointerLock={togglePointerLock}
                isEditMode={isEditMode}
                onToggleEditMode={() => {
                  setIsEditMode(!isEditMode);
                  showToast(!isEditMode ? 'Modo Edição Ativado! Arraste os botões.' : 'Modo Partida Ativado! Teclas prontas para jogar.');
                }}
                hudOpacity={settings.hudOpacity}
                onChangeHudOpacity={(val) => setSettings((prev) => ({ ...prev, hudOpacity: val }))}
                onExitGame={() => {
                  exitPointerLock();
                  setIsInGame(false);
                  showToast('Voltando para o Launcher do Mobilador...');
                }}
                onSave={handleSaveEditor}
                onOpenMacro={() => setIsMacroModalOpen(true)}
                gameTitle={currentScheme.gameTitle || currentScheme.name}
              />

              {/* Pointer Lock Camera Crosshair (Smooth FPS aim movement) */}
              {isPointerLocked && (
                <div
                  style={{ left: `${crosshairPos.x}%`, top: `${crosshairPos.y}%` }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none z-30 flex items-center justify-center"
                >
                  <div className={`relative flex items-center justify-center transition-transform ${
                    shotFiredEffect ? 'scale-150' : 'scale-100'
                  }`}>
                    {/* Crosshair lines */}
                    <div className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]" />
                    <div className="absolute w-5 h-[1.5px] bg-white/70" />
                    <div className="absolute h-5 w-[1.5px] bg-white/70" />
                    <div className="absolute w-8 h-8 rounded-full border border-white/30" />
                  </div>
                </div>
              )}

              {/* Gunshot Muzzle Flash Visual Effect */}
              {shotFiredEffect && (
                <div
                  style={{ left: `${crosshairPos.x}%`, top: `${crosshairPos.y}%` }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none z-30 w-16 h-16 rounded-full bg-amber-400/40 blur-md animate-ping"
                />
              )}

              {/* ON-SCREEN CONTROLS (Identical to BlueStacks 5 rendering) */}
              {settings.showControlsOnScreen &&
                currentScheme.controls.map((ctrl) => {
                  const isKeyActive =
                    activePressedKeys.has(ctrl.hotkey.toUpperCase()) ||
                    (ctrl.upKey && activePressedKeys.has(ctrl.upKey.toUpperCase())) ||
                    (ctrl.downKey && activePressedKeys.has(ctrl.downKey.toUpperCase())) ||
                    (ctrl.leftKey && activePressedKeys.has(ctrl.leftKey.toUpperCase())) ||
                    (ctrl.rightKey && activePressedKeys.has(ctrl.rightKey.toUpperCase())) ||
                    (ctrl.type === 'FIRE_BUTTON' && shotFiredEffect);

                  return (
                    <ControlNode
                      key={ctrl.id}
                      control={ctrl}
                      isEditorOpen={isEditorOpen || isEditMode}
                      isSelected={selectedControlId === ctrl.id}
                      onSelect={setSelectedControlId}
                      onPointerDown={handleControlPointerDown}
                      onOpenSettings={setSelectedControlForAdvanced}
                      onDelete={handleDeleteControl}
                      isKeyPressed={!!isKeyActive}
                      hudOpacity={settings.hudOpacity}
                    />
                  );
                })}

              {/* Empty Scheme Prompt */}
              {currentScheme.controls.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                  <div className="p-6 rounded-2xl bg-[#0b101b]/90 border-2 border-dashed border-[#0084ff]/50 text-center max-w-sm backdrop-blur-md shadow-2xl">
                    <Crosshair className="w-10 h-10 text-[#0084ff] mx-auto mb-2 animate-bounce" />
                    <h4 className="text-sm font-black text-white uppercase tracking-wide">
                      Mapeamento Limpo ({currentScheme.name})
                    </h4>
                    <p className="text-xs text-[#94a3b8] mt-1 leading-relaxed">
                      Toque na <b>bolha flutuante do BlueStacks</b> ou no botão de teclado na barra lateral para abrir o <b>Editor de Controles</b> e arrastar o analógico WASD e a mira FPS F1!
                    </p>
                  </div>
                </div>
              )}

              {/* Editor Mode Fine-Tuning Nudge Bar (Bottom Left) */}
              {(isEditorOpen || isEditMode) && selectedControl && (
                <div className="absolute bottom-4 left-4 z-40 bg-[#0d1524]/95 border border-[#233554] rounded-xl p-2.5 backdrop-blur-md flex items-center gap-3 shadow-2xl">
                  <div>
                    <span className="text-[10px] font-bold text-[#38bdf8] uppercase block">
                      Ajuste Fino ({selectedControl.name || selectedControl.hotkey})
                    </span>
                    <span className="text-[9px] font-mono text-[#64748b]">
                      X: {selectedControl.x}% · Y: {selectedControl.y}%
                    </span>
                  </div>

                  {/* Nudge arrow buttons */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => nudgeControl(0, -0.5)}
                      className="w-7 h-7 bg-[#162238] hover:bg-[#0084ff] text-white rounded flex items-center justify-center transition"
                      title="Cima"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => nudgeControl(-0.5, 0)}
                      className="w-7 h-7 bg-[#162238] hover:bg-[#0084ff] text-white rounded flex items-center justify-center transition"
                      title="Esquerda"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => nudgeControl(0.5, 0)}
                      className="w-7 h-7 bg-[#162238] hover:bg-[#0084ff] text-white rounded flex items-center justify-center transition"
                      title="Direita"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => nudgeControl(0, 0.5)}
                      className="w-7 h-7 bg-[#162238] hover:bg-[#0084ff] text-white rounded flex items-center justify-center transition"
                      title="Baixo"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    onClick={() => setSelectedControlForAdvanced(selectedControl)}
                    className="px-2.5 py-1.5 bg-[#0084ff] hover:bg-[#0074e0] text-white font-bold text-[10px] rounded-lg transition"
                  >
                    Tweaks 16450
                  </button>

                  <button
                    onClick={() => handleDeleteControl(selectedControl.id)}
                    className="p-1.5 bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white rounded transition"
                    title="Excluir"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Bottom In-Game Bar (Print switcher & Exit game) */}
              <div className="absolute bottom-3 right-4 z-30 flex items-center gap-2 bg-[#0b101b]/90 border border-[#1f2d48] rounded-xl px-3 py-1.5 backdrop-blur-md text-xs">
                <button
                  onClick={() => {
                    const presets: ('freefire' | 'pubg' | 'arena')[] = ['freefire', 'pubg', 'arena'];
                    const nextIdx = (presets.indexOf(currentScheme.bgPreset as any) + 1) % presets.length;
                    setSchemes((prev) =>
                      prev.map((s) => (s.id === currentScheme.id ? { ...s, bgPreset: presets[nextIdx], bgUrl: undefined } : s))
                    );
                  }}
                  className="text-[#94a3b8] hover:text-white font-semibold transition flex items-center gap-1"
                >
                  Fundo: <span className="text-white capitalize font-bold">{currentScheme.bgPreset}</span>
                </button>

                <span className="text-[#1f2d48]">|</span>

                <button
                  onClick={() => {
                    const url = prompt('Cole o link do print do seu HUD do Free Fire / Jogo:');
                    if (url !== null) {
                      setSchemes((prev) =>
                        prev.map((s) => (s.id === currentScheme.id ? { ...s, bgUrl: url } : s))
                      );
                    }
                  }}
                  className="text-[#38bdf8] hover:underline font-semibold flex items-center gap-1"
                >
                  <ImageIcon className="w-3 h-3" />
                  Print do Jogo
                </button>

                <span className="text-[#1f2d48]">|</span>

                <button
                  onClick={() => {
                    exitPointerLock();
                    setIsInGame(false);
                  }}
                  className="text-red-400 hover:text-white font-bold flex items-center gap-1"
                >
                  <LogOut className="w-3 h-3" />
                  Sair do Jogo
                </button>
              </div>
            </div>

            {/* CONTROLS EDITOR SIDEBAR (SLIDES IN WHEN OPENED) */}
            {isEditorOpen && (
              <BlueStacksControlsEditor
                schemes={schemes}
                activeSchemeId={activeSchemeId}
                onSelectScheme={(id) => {
                  setActiveSchemeId(id);
                  setSelectedControlId(null);
                }}
                onCreateNewScheme={handleCreateNewScheme}
                onExportScheme={handleExportScheme}
                onImportScheme={handleImportScheme}
                onResetScheme={handleResetScheme}
                onClose={() => setIsEditorOpen(false)}
                onSave={handleSaveEditor}
                onDiscard={handleDiscardEditor}
                onAddControlDirectly={handleAddControlDirectly}
                hasUnsavedChanges={hasUnsavedChanges}
              />
            )}

            {/* BLUESTACKS ICONIC RIGHT VERTICAL SIDEBAR TOOLBAR */}
            <BlueStacksSidebar
              isEditorOpen={isEditorOpen}
              onToggleEditor={() => setIsEditorOpen(!isEditorOpen)}
              showControlsOnScreen={settings.showControlsOnScreen}
              onToggleShowControls={() =>
                setSettings((prev) => ({ ...prev, showControlsOnScreen: !prev.showControlsOnScreen }))
              }
              hudOpacity={settings.hudOpacity}
              onChangeHudOpacity={(val) => setSettings((prev) => ({ ...prev, hudOpacity: val }))}
              onOpenMacroManager={() => setIsMacroModalOpen(true)}
              onOpenSettings={() => setIsSettingsModalOpen(true)}
              onTakeScreenshot={() => showToast('Captura de tela salva na galeria do celular!')}
              isPointerLocked={isPointerLocked}
              onTogglePointerLock={togglePointerLock}
              activeSchemeName={currentScheme.name}
            />
          </div>
        </div>
      )}

      {/* 3. MODALS */}
      {/* Advanced Settings Modal for individual controls */}
      <AdvancedSettingsModal
        control={selectedControlForAdvanced}
        onClose={() => setSelectedControlForAdvanced(null)}
        onSave={(updated) => {
          setSchemes((prev) =>
            prev.map((s) =>
              s.id === currentScheme.id
                ? {
                    ...s,
                    controls: s.controls.map((c) => (c.id === updated.id ? updated : c))
                  }
                : s
            )
          );
          setHasUnsavedChanges(true);
          showToast(`Configurações de "${updated.name || updated.hotkey}" salvas!`);
        }}
      />

      {/* BlueStacks Macro Manager Modal */}
      <MacroManagerModal
        isOpen={isMacroModalOpen}
        onClose={() => setIsMacroModalOpen(false)}
        onExecuteMacro={(macro) => {
          showToast(`Executando macro: "${macro.name}"...`);
        }}
      />

      {/* BlueStacks Settings Modal */}
      <BlueStacksSettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onUpdateSettings={(updated) => setSettings((prev) => ({ ...prev, ...updated }))}
      />

      {/* Android Activation Modal */}
      <AndroidActivationModal
        isOpen={isActivationModalOpen}
        onClose={() => setIsActivationModalOpen(false)}
        isActivated={isActivated}
        activeMethod={activationMethod}
        onActivate={(method) => {
          setIsActivated(true);
          setActivationMethod(method);
          showToast(`Mapeador ativado com sucesso via ${method}!`);
        }}
      />
    </div>
  );
}
