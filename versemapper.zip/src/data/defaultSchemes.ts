import { ControlScheme } from '../types/bluestacks';

export const DEFAULT_SCHEMES: ControlScheme[] = [
  {
    id: 'freefire_smart',
    name: 'Free Fire MAX (Smart Scheme BlueStacks 5)',
    gameTitle: 'Free Fire MAX',
    resolution: '1080p',
    category: 'Battle Royale',
    bgPreset: 'freefire',
    controls: [
      {
        id: 'ff_aim_pan',
        type: 'AIM_PAN_SHOOT',
        name: 'Olhar, Mirar e Atirar (Modo FPS)',
        hotkey: 'F1',
        x: 62,
        y: 52,
        startStopKey: 'F1',
        suspendKey: 'L-Alt',
        sensX: 1.40,
        sensY: 1.85,
        tweaks: 16450,
        mouseAcceleration: false,
        fireWithLeftClick: true,
        lookAroundWithRight: false
      },
      {
        id: 'ff_fire_btn',
        type: 'FIRE_BUTTON',
        name: 'Gatilho de Tiro (Mouse 1)',
        hotkey: 'Mouse 1',
        x: 88,
        y: 34
      },
      {
        id: 'ff_dpad',
        type: 'DPAD',
        name: 'D-Pad Movimento (WASD)',
        hotkey: 'WASD',
        x: 18,
        y: 72,
        upKey: 'W',
        downKey: 'S',
        leftKey: 'A',
        rightKey: 'D',
        dpadRadius: 12
      },
      {
        id: 'ff_scope',
        type: 'TAP',
        name: 'Mirar com Mira Telescópica',
        hotkey: 'Mouse 2',
        x: 14,
        y: 18
      },
      {
        id: 'ff_jump',
        type: 'TAP',
        name: 'Pular',
        hotkey: 'Space',
        x: 92,
        y: 62
      },
      {
        id: 'ff_crouch',
        type: 'TAP',
        name: 'Agachar',
        hotkey: 'C',
        x: 86,
        y: 76
      },
      {
        id: 'ff_prone',
        type: 'TAP',
        name: 'Deitar',
        hotkey: 'Z',
        x: 88,
        y: 90
      },
      {
        id: 'ff_reload',
        type: 'TAP',
        name: 'Recarregar',
        hotkey: 'R',
        x: 85,
        y: 15
      },
      {
        id: 'ff_sprint',
        type: 'TAP',
        name: 'Correr',
        hotkey: 'Shift',
        x: 25,
        y: 52
      },
      {
        id: 'ff_w1',
        type: 'TAP',
        name: 'Arma 1',
        hotkey: '1',
        x: 72,
        y: 14
      },
      {
        id: 'ff_w2',
        type: 'TAP',
        name: 'Arma 2',
        hotkey: '2',
        x: 78,
        y: 14
      },
      {
        id: 'ff_w3',
        type: 'TAP',
        name: 'Pistola',
        hotkey: '3',
        x: 83,
        y: 14
      },
      {
        id: 'ff_bag',
        type: 'TAP',
        name: 'Mochila / Inventário',
        hotkey: 'Tab',
        x: 10,
        y: 65
      },
      {
        id: 'ff_medkit',
        type: 'TAP',
        name: 'Kit Médico',
        hotkey: '5',
        x: 15,
        y: 85
      },
      {
        id: 'ff_skill',
        type: 'TAP',
        name: 'Habilidade Ativa (Alok/Chrono)',
        hotkey: 'E',
        x: 52,
        y: 78
      },
      {
        id: 'ff_free_look',
        type: 'FREE_LOOK',
        name: 'Olhar Livre (Olho)',
        hotkey: 'Alt',
        x: 62,
        y: 32
      },
      {
        id: 'ff_loot1',
        type: 'TAP',
        name: 'Pegar Item 1',
        hotkey: 'F',
        x: 70,
        y: 35
      },
      {
        id: 'ff_loot2',
        type: 'TAP',
        name: 'Pegar Item 2',
        hotkey: 'G',
        x: 70,
        y: 42
      }
    ]
  },
  {
    id: 'pubg_smart',
    name: 'PUBG MOBILE (Esquema Tático 1080p)',
    gameTitle: 'PUBG MOBILE',
    resolution: '1080p',
    category: 'Battle Royale',
    bgPreset: 'pubg',
    controls: [
      {
        id: 'pubg_aim',
        type: 'AIM_PAN_SHOOT',
        name: 'Modo FPS',
        hotkey: 'F1',
        x: 65,
        y: 50,
        startStopKey: 'F1',
        suspendKey: 'L-Alt',
        sensX: 1.25,
        sensY: 1.65,
        tweaks: 16450,
        mouseAcceleration: false,
        fireWithLeftClick: true
      },
      {
        id: 'pubg_fire',
        type: 'FIRE_BUTTON',
        name: 'Atirar',
        hotkey: 'Mouse 1',
        x: 86,
        y: 36
      },
      {
        id: 'pubg_dpad',
        type: 'DPAD',
        name: 'WASD Movimento',
        hotkey: 'WASD',
        x: 20,
        y: 72,
        upKey: 'W',
        downKey: 'S',
        leftKey: 'A',
        rightKey: 'D'
      },
      {
        id: 'pubg_scope',
        type: 'TAP',
        name: 'Mira ADS',
        hotkey: 'Mouse 2',
        x: 90,
        y: 48
      },
      {
        id: 'pubg_jump',
        type: 'TAP',
        name: 'Pular / Escalar',
        hotkey: 'Space',
        x: 93,
        y: 65
      },
      {
        id: 'pubg_crouch',
        type: 'TAP',
        name: 'Agachar',
        hotkey: 'C',
        x: 85,
        y: 78
      },
      {
        id: 'pubg_prone',
        type: 'TAP',
        name: 'Deitar',
        hotkey: 'Z',
        x: 92,
        y: 88
      },
      {
        id: 'pubg_peek_l',
        type: 'TAP',
        name: 'Inclinar Esquerda',
        hotkey: 'Q',
        x: 78,
        y: 48
      },
      {
        id: 'pubg_peek_r',
        type: 'TAP',
        name: 'Inclinar Direita',
        hotkey: 'E',
        x: 84,
        y: 48
      }
    ]
  },
  {
    id: 'blood_strike_pro',
    name: 'Blood Strike (Competitivo FPS)',
    gameTitle: 'Blood Strike',
    resolution: '1080p',
    category: 'FPS Rápido',
    bgPreset: 'arena',
    controls: [
      {
        id: 'bs_aim',
        type: 'AIM_PAN_SHOOT',
        name: 'Modo FPS',
        hotkey: 'X',
        x: 62,
        y: 50,
        startStopKey: 'X',
        suspendKey: 'L-Ctrl',
        sensX: 1.55,
        sensY: 2.10,
        tweaks: 21058,
        mouseAcceleration: false,
        fireWithLeftClick: true
      },
      {
        id: 'bs_fire',
        type: 'FIRE_BUTTON',
        name: 'Gatilho de Tiro',
        hotkey: 'Mouse 1',
        x: 88,
        y: 35
      },
      {
        id: 'bs_dpad',
        type: 'DPAD',
        name: 'WASD',
        hotkey: 'WASD',
        x: 18,
        y: 72,
        upKey: 'W',
        downKey: 'S',
        leftKey: 'A',
        rightKey: 'D'
      },
      {
        id: 'bs_slide',
        type: 'TAP',
        name: 'Deslizar / Slide',
        hotkey: 'C',
        x: 85,
        y: 75
      },
      {
        id: 'bs_jump',
        type: 'TAP',
        name: 'Pulo Duplo',
        hotkey: 'Space',
        x: 92,
        y: 60
      }
    ]
  }
];

export const BLUESTACKS_TWEAKS_PRESETS = [
  { value: 16450, label: '16450 (Padrão Ouro Free Fire BlueStacks 5 - Menor delay)' },
  { value: 21058, label: '21058 (Ajuste Competitivo / Puxada Suave de Capa)' },
  { value: 71458, label: '71458 (Ultra Suavização / Anti-tremor de mira)' },
  { value: 8080, label: '8080 (Ajuste Mobilador Raiz / Resposta Direta)' },
  { value: 2, label: '2 (Modo Padrão Emulador Clássico)' },
  { value: 10, label: '10 (Ajuste de Precisão Cirúrgica)' }
];
