export type ControlType =
  | 'TAP'                // Ponto de toque simples
  | 'REPEATED_TAP'       // Repetir toque (toque contínuo)
  | 'DPAD'               // Analógico / D-Pad (WASD)
  | 'AIM_PAN_SHOOT'      // Olhar, mirar e atirar (Modo FPS F1/X)
  | 'FIRE_BUTTON'        // Gatilho de tiro (Clique esquerdo)
  | 'FREE_LOOK'          // Mirar livremente (Olho / Alt)
  | 'ZOOM'               // Zoom / Pinça (Scroll do mouse)
  | 'SWIPE'              // Deslizar direcional
  | 'MOBA_SKILL'         // Roda de habilidade MOBA
  | 'MOUSE_MOVE'         // Giro da câmera
  | 'SCROLL'             // Rolar tela
  | 'EDGE_SCROLL'        // Borda de rolagem
  | 'SCRIPT';            // Macro / Scripting do BlueStacks

export interface ControlItem {
  id: string;
  type: ControlType;
  hotkey: string;
  name: string;
  x: number; // percentage (0 - 100)
  y: number; // percentage (0 - 100)
  radius?: number; // size percentage
  // Specific properties for Aim, Pan & Shoot (FPS Mode BlueStacks)
  startStopKey?: string;       // ex: 'F1', 'X', '~'
  suspendKey?: string;         // ex: 'L-Alt', 'L-Ctrl'
  sensX?: number;              // ex: 1.40
  sensY?: number;              // ex: 1.85
  tweaks?: number;             // ex: 16450, 21058, 71458
  mouseAcceleration?: boolean;
  fireWithLeftClick?: boolean;
  fireButtonId?: string;       // link to Fire button
  lookAroundWithRight?: boolean;
  // Specific for Repeated Tap
  repeatCount?: number;        // taps per second (e.g. 10)
  repeatMode?: 'HOLD' | 'TAP';
  // Specific for D-Pad
  upKey?: string;
  downKey?: string;
  leftKey?: string;
  rightKey?: string;
  dpadRadius?: number;
  // Specific for Script / Macro
  scriptCode?: string;
}

export interface ControlScheme {
  id: string;
  name: string;
  gameTitle: string;
  resolution: '720p' | '1080p' | '1440p' | 'Personalizado';
  category: string;
  bgUrl?: string;
  bgPreset: 'freefire' | 'pubg' | 'arena' | 'grid';
  controls: ControlItem[];
  isCustom?: boolean;
}

export interface BlueStacksSettings {
  mousePollingHz: 500 | 800 | 1000;
  cursorStyle: 'classic' | 'yellow' | 'gamer_crosshair' | 'neon_blue';
  hudOpacity: number; // 0 to 100
  showControlsOnScreen: boolean;
  pointerLockKey: string;
  enableVibration: boolean;
  fpsLimit: 60 | 90 | 120 | 240;
  gamePadDetection: boolean;
  lowLatencyEngine: boolean;
}

export type AndroidActivationMethod = 'Shizuku' | 'Wireless' | 'Root' | 'Wired';

export interface AndroidGameApp {
  id: string;
  title: string;
  category: string;
  iconColor: string;
  schemeId: string;
}
