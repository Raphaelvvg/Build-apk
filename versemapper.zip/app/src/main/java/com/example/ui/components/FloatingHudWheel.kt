package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ControlCamera
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun FloatingHudWheel(
    isOpen: Boolean,
    onClose: () -> Unit,
    onEditHud: () -> Unit,
    onMostraHud: () -> Unit,
    onDigitaJogar: () -> Unit,
    onMacro: () -> Unit,
    onConfigRecuo: () -> Unit,
    onImportExport: () -> Unit,
    onBasicSettings: () -> Unit,
    onHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isOpen,
        enter = slideInHorizontally(initialOffsetX = { -it }),
        exit = slideOutHorizontally(targetOffsetX = { -it }),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(310.dp)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xF0050810),
                            Color(0xE60A0E1A),
                            Color(0x990A0E1A)
                        )
                    )
                )
        ) {
            // Neon blue circular arc indicator along the right curve
            Canvas(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(40.dp)
                    .align(Alignment.CenterEnd)
            ) {
                val tickCount = 28
                val stepY = size.height / (tickCount + 1)
                for (i in 1..tickCount) {
                    val y = stepY * i
                    val isCyan = i % 3 == 0
                    drawLine(
                        color = if (isCyan) AccentCyan else PrimaryBlueGlow,
                        start = androidx.compose.ui.geometry.Offset(x = 10f, y = y),
                        end = androidx.compose.ui.geometry.Offset(x = 32f, y = y),
                        strokeWidth = 3f,
                        cap = StrokeCap.Round
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(end = 42.dp, top = 16.dp, bottom = 16.dp, start = 16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top icons (Home + Settings + Close)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        IconButton(onClick = onHome) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "Home",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        IconButton(onClick = onBasicSettings) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Configurações",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fechar Menu",
                            tint = TextMuted,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Text(
                    text = "VERSEMAPPER HUD",
                    color = AccentCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Hexagonal/Card Buttons (2 columns as in Screenshot 7/8)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HudHexButton(
                        icon = Icons.Default.Share,
                        label = "IMPORTA &\nEXPORTA HUD",
                        onClick = onImportExport,
                        modifier = Modifier.weight(1f)
                    )
                    HudHexButton(
                        icon = Icons.Default.Edit,
                        label = "EDITAR\nHUD",
                        onClick = onEditHud,
                        modifier = Modifier.weight(1f),
                        isHighlight = true
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HudHexButton(
                        icon = Icons.Default.Visibility,
                        label = "MOSTRA\nHUD",
                        onClick = onMostraHud,
                        modifier = Modifier.weight(1f)
                    )
                    HudHexButton(
                        icon = Icons.Default.Keyboard,
                        label = "DIGITA &\nJOGAR",
                        onClick = onDigitaJogar,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HudHexButton(
                        icon = Icons.Default.FlashOn,
                        label = "MACRO\nCOMBO",
                        onClick = onMacro,
                        modifier = Modifier.weight(1f)
                    )
                    HudHexButton(
                        icon = Icons.Default.ControlCamera,
                        label = "CONFIG DO\nRECUO",
                        onClick = onConfigRecuo,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Basic Settings Row
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF131C2E))
                        .border(1.dp, PrimaryBlueGlow.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .clickable { onBasicSettings() }
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "CONFIGURAÇÕES BÁSICAS",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}

@Composable
fun HudHexButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isHighlight: Boolean = false
) {
    Box(
        modifier = modifier
            .height(96.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (isHighlight) PrimaryBlue.copy(alpha = 0.25f)
                else Color(0xFF101726)
            )
            .border(
                1.5.dp,
                if (isHighlight) PrimaryBlueGlow else Color(0xFF233047),
                RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isHighlight) AccentCyan else Color.White,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
