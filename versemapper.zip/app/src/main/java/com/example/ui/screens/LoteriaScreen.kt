package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.DarkCard
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun LoteriaScreen(modifier: Modifier = Modifier) {
    val rotation = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var isSpinning by remember { mutableStateOf(false) }
    var rewardResult by remember { mutableStateOf("Gire para ganhar itens VIP!") }
    var spinsLeft by remember { mutableIntStateOf(5) }

    val rewards = listOf(
        "Cursor Mira Neon",
        "Sensibilidade Pro HUD",
        "Macro Gel Rápido",
        "Chave VIP 7 Dias",
        "Aceleração Zero Lag",
        "100 Moedas Verse",
        "Cursor Crosshair Cyan",
        "Preset Free Fire Sniper"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "LOTERIA VERSEMAPPER",
            color = AccentAmber,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Text(
            text = "Gire a roleta diária e desbloqueie estilos de mira e presets pro",
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Roulette Wheel Box
        Box(
            modifier = Modifier
                .size(240.dp)
                .clip(CircleShape)
                .background(Color(0xFF0F172A))
                .border(4.dp, AccentAmber, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .rotate(rotation.value)
            ) {
                val c = Offset(size.width / 2, size.height / 2)
                val colors = listOf(
                    Color(0xFF1E293B),
                    Color(0xFF2563EB),
                    Color(0xFF0F172A),
                    Color(0xFFD97706),
                    Color(0xFF059669),
                    Color(0xFF7C3AED),
                    Color(0xFFDC2626),
                    Color(0xFF0891B2)
                )

                val sweep = 360f / 8f
                for (i in 0 until 8) {
                    drawArc(
                        color = colors[i],
                        startAngle = i * sweep,
                        sweepAngle = sweep,
                        useCenter = true
                    )
                }

                // Inner circle
                drawCircle(Color.Black, radius = 30.dp.toPx(), center = c)
                drawCircle(AccentAmber, radius = 28.dp.toPx(), center = c, style = Stroke(width = 3.dp.toPx()))
            }

            // Center Pin
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black)
                    .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Casino,
                    contentDescription = null,
                    tint = AccentAmber,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Result notification
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(DarkCard)
                .border(1.dp, PrimaryBlueGlow.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = rewardResult,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (!isSpinning && spinsLeft > 0) {
                    isSpinning = true
                    spinsLeft--
                    val randomTarget = rotation.value + 1440f + Random.nextInt(0, 360)
                    scope.launch {
                        rotation.animateTo(
                            targetValue = randomTarget,
                            animationSpec = tween(durationMillis = 3000, easing = androidx.compose.animation.core.FastOutSlowInEasing)
                        )
                        isSpinning = false
                        val winIndex = Random.nextInt(rewards.size)
                        rewardResult = "Parabéns! Você ganhou: ${rewards[winIndex]}"
                    }
                }
            },
            enabled = !isSpinning && spinsLeft > 0,
            modifier = Modifier
                .fillMaxWidth(0.7f)
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentAmber),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = if (isSpinning) "GIRANDO..." else "GIRAR ROLETA ($spinsLeft RESTANTES)",
                color = Color.Black,
                fontWeight = FontWeight.Black,
                fontSize = 13.sp
            )
        }
    }
}
