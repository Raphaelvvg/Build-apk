package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SampleData
import com.example.model.ActivationMethod
import com.example.model.AppSettings
import com.example.model.GameItem
import com.example.model.GameProfile
import com.example.model.KeyMapping
import com.example.ui.components.ActivationModal
import com.example.ui.components.BasicSettingsDialog
import com.example.ui.components.FpsSensConfigDialog
import com.example.ui.components.HudEditorOverlay
import com.example.ui.components.MostraHudDialog
import com.example.ui.components.PromptViewerDialog
import com.example.ui.components.RecoilConfigDialog
import com.example.ui.components.VersemapperTopBar
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCard
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

enum class AppTab(val title: String, val icon: ImageVector) {
    JOGAR("JOGAR", Icons.Default.Gamepad),
    DISPOSITIVOS("DISPOSITIVOS", Icons.Default.Mouse),
    CONTA("CONTA", Icons.Default.Person),
    CONFIG("CONFIG", Icons.Default.Settings)
}

@Composable
fun MainScreen() {
    var currentTab by remember { mutableStateOf(AppTab.JOGAR) }
    var appSettings by remember { mutableStateOf(AppSettings()) }

    // Games state
    val gamesList = remember { mutableStateListOf<GameItem>().apply { addAll(SampleData.initialGames) } }
    var selectedGame by remember { mutableStateOf(gamesList.first()) }

    // In-Game HUD overlay state
    var isOverlayActive by remember { mutableStateOf(false) }

    // Global Dialogs
    var showActivationModal by remember { mutableStateOf(false) }
    var showFpsSensDialog by remember { mutableStateOf(false) }
    var showBasicSettingsDialog by remember { mutableStateOf(false) }
    var showMostraHudDialog by remember { mutableStateOf(false) }
    var showRecoilDialog by remember { mutableStateOf(false) }
    var showPromptDialog by remember { mutableStateOf(false) }

    if (isOverlayActive) {
        // FULLSCREEN IN-GAME HUD KEYMAPPER OVERLAY
        val activeMappings = selectedGame.profiles.firstOrNull()?.keyMappings ?: SampleData.freeFireDefaultMappings
        HudEditorOverlay(
            game = selectedGame,
            settings = appSettings,
            initialMappings = activeMappings,
            onExit = { isOverlayActive = false },
            onSaveMappings = { newMappings ->
                val gameIdx = gamesList.indexOfFirst { it.id == selectedGame.id }
                if (gameIdx >= 0) {
                    val updatedGame = selectedGame.copy(
                        profiles = listOf(GameProfile("default", "Preset Padrão", newMappings))
                    )
                    gamesList[gameIdx] = updatedGame
                    selectedGame = updatedGame
                }
            },
            onOpenBasicSettings = { showBasicSettingsDialog = true },
            onOpenFpsSens = { showFpsSensDialog = true },
            onOpenMostraHud = { showMostraHudDialog = true },
            onOpenRecoil = { showRecoilDialog = true }
        )
    } else {
        // MAIN APP LAUNCHER & CONFIG INTERFACE
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBg),
            topBar = {
                VersemapperTopBar(
                    settings = appSettings,
                    onOpenActivation = { showActivationModal = true },
                    onToggleMouse = {
                        appSettings = appSettings.copy(isMouseConnected = !appSettings.isMouseConnected)
                    },
                    onToggleKeyboard = {
                        appSettings = appSettings.copy(isKeyboardConnected = !appSettings.isKeyboardConnected)
                    },
                    onOpenPrompt = { showPromptDialog = true }
                )
            },
            bottomBar = {
                VersemapperBottomBar(
                    currentTab = currentTab,
                    onTabSelected = { currentTab = it }
                )
            },
            containerColor = DarkBg
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    AppTab.JOGAR -> {
                        LauncherScreen(
                            games = gamesList,
                            selectedGame = selectedGame,
                            onSelectGame = { selectedGame = it },
                            onLaunchGame = { gameToLaunch ->
                                selectedGame = gameToLaunch
                                isOverlayActive = true
                            },
                            onAddGame = { title, pkg ->
                                val newGame = GameItem(
                                    id = "game_${System.currentTimeMillis()}",
                                    title = title,
                                    packageName = pkg,
                                    profiles = listOf(GameProfile("default", "Preset Personalizado", SampleData.freeFireDefaultMappings.take(14)))
                                )
                                gamesList.add(newGame)
                                selectedGame = newGame
                            }
                        )
                    }

                    AppTab.DISPOSITIVOS -> {
                        DispositivosScreen(
                            settings = appSettings,
                            onOpenFpsSens = { showFpsSensDialog = true },
                            onOpenBasicSettings = { showBasicSettingsDialog = true }
                        )
                    }

                    AppTab.CONTA -> {
                        ContaScreen()
                    }

                    AppTab.CONFIG -> {
                        ConfigScreen(
                            settings = appSettings,
                            onOpenActivation = { showActivationModal = true },
                            onOpenFpsSens = { showFpsSensDialog = true },
                            onOpenBasicSettings = { showBasicSettingsDialog = true },
                            onOpenRecoil = { showRecoilDialog = true },
                            onOpenPrompt = { showPromptDialog = true },
                            onAccountInfo = { currentTab = AppTab.CONTA }
                        )
                    }
                }
            }
        }
    }

    // Dialog overlays
    if (showActivationModal) {
        ActivationModal(
            currentMethod = appSettings.activationMethod,
            isActivated = appSettings.isActivated,
            onDismiss = { showActivationModal = false },
            onSelectMethod = { method ->
                appSettings = appSettings.copy(activationMethod = method)
            },
            onActivateSuccess = {
                appSettings = appSettings.copy(isActivated = true)
            }
        )
    }

    if (showFpsSensDialog) {
        FpsSensConfigDialog(
            settings = appSettings,
            onDismiss = { showFpsSensDialog = false },
            onSave = { updated ->
                appSettings = updated
                showFpsSensDialog = false
            }
        )
    }

    if (showBasicSettingsDialog) {
        BasicSettingsDialog(
            settings = appSettings,
            onDismiss = { showBasicSettingsDialog = false },
            onSave = { updated ->
                appSettings = updated
                showBasicSettingsDialog = false
            }
        )
    }

    if (showMostraHudDialog) {
        MostraHudDialog(
            settings = appSettings,
            onDismiss = { showMostraHudDialog = false },
            onSave = { updated ->
                appSettings = updated
                showMostraHudDialog = false
            }
        )
    }

    if (showRecoilDialog) {
        RecoilConfigDialog(
            settings = appSettings,
            onDismiss = { showRecoilDialog = false },
            onSave = { updated ->
                appSettings = updated
                showRecoilDialog = false
            }
        )
    }

    if (showPromptDialog) {
        PromptViewerDialog(
            onDismiss = { showPromptDialog = false }
        )
    }
}

@Composable
fun VersemapperBottomBar(
    currentTab: AppTab,
    onTabSelected: (AppTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Black)
            .border(1.dp, Color(0xFF1E293B))
            .navigationBarsPadding()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppTab.values().forEach { tab ->
            val isSelected = currentTab == tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onTabSelected(tab) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.title,
                        tint = if (isSelected) PrimaryBlueGlow else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = tab.title,
                        color = if (isSelected) PrimaryBlueGlow else TextMuted,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold
                    )
                }
            }
        }
    }
}
