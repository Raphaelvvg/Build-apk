package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Versemapper Cyberpunk / High-Tech Gaming Palette
val DarkBg = Color(0xFF090D16)
val DarkSurface = Color(0xFF0F172A)
val DarkCard = Color(0xFF131C2E)
val DarkElevated = Color(0xFF1E293B)
val DarkBorder = Color(0xFF1E293B)

val PrimaryBlue = Color(0xFF2563EB)
val PrimaryBlueGlow = Color(0xFF3B82F6)
val AccentCyan = Color(0xFF06B6D4)
val AccentAmber = Color(0xFFF59E0B)
val AccentRed = Color(0xFFEF4444)
val AccentGreen = Color(0xFF10B981)
val AccentPurple = Color(0xFF8B5CF6)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// HUD Overlay Key Colors
val KeyIndicatorBg = Color(0xCC0F172A)
val KeyIndicatorBorder = Color(0xFF3B82F6)
val KeyJoystickBg = Color(0x442563EB)
val KeyViewFpsBg = Color(0x663B82F6)
