package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ControlCamera
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppSettings
import com.example.model.ComponentType
import com.example.model.GameItem
import com.example.model.KeyMapping
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.DarkBg
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlin.math.roundToInt

@Composable
fun HudEditorOverlay(
    game: GameItem,
    settings: AppSettings,
    initialMappings: List<KeyMapping>,
    onExit: () -> Unit,
    onSaveMappings: (List<KeyMapping>) -> Unit,
    onOpenBasicSettings: () -> Unit,
    onOpenFpsSens: () -> Unit,
    onOpenMostraHud: () -> Unit,
    onOpenRecoil: () -> Unit,
    modifier: Modifier = Modifier
) {
    val mappings = remember { mutableStateListOf<KeyMapping>().apply { addAll(initialMappings) } }
    var selectedKeyForConfig by remember { mutableStateOf<KeyMapping?>(null) }
    var showAddComponentDialog by remember { mutableStateOf(false) }
    var isSideWheelOpen by remember { mutableStateOf(false) }
    var isTestPlayMode by remember { mutableStateOf(false) } // Testing real clicks / ripples
    var statusMessage by remember { mutableStateOf("") }
    var backgroundType by remember { mutableStateOf(0) } // 0: Tactical Arena, 1: Golden Lobby, 2: Cyber Grid

    // Touch ripple simulation list
    val ripples = remember { mutableStateListOf<Offset>() }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        val maxWidthPx = constraints.maxWidth.toFloat()
        val maxHeightPx = constraints.maxHeight.toFloat()
        val density = LocalDensity.current

        // 1. GAME BACKGROUND SIMULATION (Free Fire MAX / Mobile Game View)
        GameBackgroundCanvas(
            backgroundType = backgroundType,
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isTestPlayMode) {
                    if (isTestPlayMode) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                ripples.add(offset)
                                if (ripples.size > 8) ripples.removeAt(0)
                            },
                            onDrag = { change, _ ->
                                ripples.add(change.position)
                                if (ripples.size > 8) ripples.removeAt(0)
                            }
                        )
                    }
                }
        )

        // Touch feedback ripples
        Canvas(modifier = Modifier.fillMaxSize()) {
            ripples.forEach { pos ->
                drawCircle(
                    color = AccentCyan.copy(alpha = 0.5f),
                    radius = 24.dp.toPx(),
                    center = pos,
                    style = Stroke(width = 3.dp.toPx())
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.8f),
                    radius = 8.dp.toPx(),
                    center = pos
                )
            }
        }

        // 2. MAPPED KEYS LAYER (Draggable key nodes on the screen)
        if (settings.showIndicator) {
            val indicatorColor = Color(settings.indicatorColorHex)
            val indicatorAlpha = (settings.indicatorAlpha / 100f).coerceIn(0.1f, 1f)

            mappings.forEach { keyItem ->
                val xPosPx = (keyItem.xRatio * maxWidthPx).coerceIn(20f, maxWidthPx - 80f)
                val yPosPx = (keyItem.yRatio * maxHeightPx).coerceIn(20f, maxHeightPx - 80f)

                KeyNodeView(
                    keyMapping = keyItem,
                    indicatorColor = indicatorColor,
                    indicatorAlpha = indicatorAlpha,
                    isEditing = !isTestPlayMode,
                    onClick = {
                        if (!isTestPlayMode) {
                            selectedKeyForConfig = keyItem
                        } else {
                            // Trigger touch ripple at this key location
                            ripples.add(Offset(xPosPx, yPosPx))
                            if (ripples.size > 8) ripples.removeAt(0)
                        }
                    },
                    onDrag = { dragDelta ->
                        if (!isTestPlayMode) {
                            val newX = ((xPosPx + dragDelta.x) / maxWidthPx).coerceIn(0.02f, 0.95f)
                            val newY = ((yPosPx + dragDelta.y) / maxHeightPx).coerceIn(0.05f, 0.95f)
                            val idx = mappings.indexOfFirst { it.id == keyItem.id }
                            if (idx >= 0) {
                                mappings[idx] = keyItem.copy(xRatio = newX, yRatio = newY)
                            }
                        }
                    },
                    modifier = Modifier.offset {
                        IntOffset(xPosPx.roundToInt(), yPosPx.roundToInt())
                    }
                )
            }
        }

        // 3. TOP CENTER FLOATING BAR (From Screenshot 4)
        if (!isTestPlayMode) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 10.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black.copy(alpha = 0.92f))
                    .border(1.5.dp, Color(0xFF222F46), RoundedCornerShape(10.dp))
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    // Top row: SAIR | ADD COMPONENTE | SALVA HUD
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        HudBarAction(
                            label = "SAIR",
                            onClick = onExit
                        )
                        Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color(0xFF374151)))
                        HudBarAction(
                            label = "ADD COMPO\nNENTE",
                            onClick = { showAddComponentDialog = true },
                            isHighlight = true
                        )
                        Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color(0xFF374151)))
                        HudBarAction(
                            label = "SALVA HUD",
                            onClick = {
                                onSaveMappings(mappings.toList())
                                statusMessage = "HUD Salvo com Sucesso!"
                            }
                        )
                    }

                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF26334A)))

                    // Bottom row: COMPARTILHAR | IMPORTA
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        HudBarAction(
                            label = "COMPARTILHAR",
                            onClick = { statusMessage = "Código do HUD copiado: VMAP-${game.id.uppercase()}-9812" }
                        )
                        Box(modifier = Modifier.width(1.dp).height(20.dp).background(Color(0xFF374151)))
                        HudBarAction(
                            label = "IMPORTA",
                            onClick = { statusMessage = "HUD Importado da Nuvem!" }
                        )
                    }
                }
            }
        }

        // 4. FLOATING ACTION WIDGETS & MODES TOGGLE
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color.Black.copy(alpha = 0.85f))
                .border(1.dp, PrimaryBlueGlow.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Mode switch: Edit vs Test Play
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isTestPlayMode) AccentGreen else PrimaryBlue)
                    .clickable { isTestPlayMode = !isTestPlayMode }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isTestPlayMode) Icons.Default.Edit else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isTestPlayMode) "EDITAR HUD" else "TESTAR JOGO",
                    color = Color.Black,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }

            // Change background
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E293B))
                    .clickable { backgroundType = (backgroundType + 1) % 3 }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text(
                    text = when (backgroundType) {
                        0 -> "Cenário: Arena"
                        1 -> "Cenário: Naruto Lobby"
                        else -> "Cenário: Grid Tático"
                    },
                    color = TextPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Menu trigger
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E293B))
                    .clickable { isSideWheelOpen = true }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "MENU LATERAL",
                    color = AccentCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Floating trigger ball on left edge (Always accessible)
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = 8.dp)
                .size(46.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = settings.logoTransparency / 100f))
                .border(2.dp, PrimaryBlueGlow, CircleShape)
                .clickable { isSideWheelOpen = !isSideWheelOpen },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "VM",
                    color = AccentCyan,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp
                )
            }
        }

        // Status Toast
        AnimatedVisibility(
            visible = statusMessage.isNotEmpty(),
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(AccentGreen)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(statusMessage, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        // 5. SIDE RADIAL ARC MENU (Screenshot 7 & 8)
        FloatingHudWheel(
            isOpen = isSideWheelOpen,
            onClose = { isSideWheelOpen = false },
            onEditHud = {
                isTestPlayMode = false
                isSideWheelOpen = false
            },
            onMostraHud = {
                isSideWheelOpen = false
                onOpenMostraHud()
            },
            onDigitaJogar = {
                isTestPlayMode = true
                isSideWheelOpen = false
                statusMessage = "Modo Digita & Jogar ativado!"
            },
            onMacro = {
                isSideWheelOpen = false
                statusMessage = "Editor de Macro Combo aberto"
            },
            onConfigRecuo = {
                isSideWheelOpen = false
                onOpenRecoil()
            },
            onImportExport = {
                isSideWheelOpen = false
                statusMessage = "Compartilhamento de HUD gerado!"
            },
            onBasicSettings = {
                isSideWheelOpen = false
                onOpenBasicSettings()
            },
            onHome = onExit,
            modifier = Modifier.align(Alignment.CenterStart)
        )

        // 6. COMPONENT & KEY CONFIG DIALOGS
        if (showAddComponentDialog) {
            AddComponentDialog(
                onDismiss = { showAddComponentDialog = false },
                onSelectComponent = { comp ->
                    val newId = "key_${System.currentTimeMillis()}"
                    val defaultLabel = when (comp) {
                        ComponentType.TOUCH -> "E"
                        ComponentType.JOYSTICK -> "WASD"
                        ComponentType.FPS_VIEW -> "View"
                        ComponentType.FREE_LOOK -> "L-Alt"
                        ComponentType.MOUSE_PICK -> "L-Ctrl"
                        ComponentType.MACRO -> "Macro"
                        ComponentType.SWIPE -> "Flick"
                        ComponentType.MOUSE_SCROLL -> "Scroll"
                        ComponentType.LONG_PRESS -> "Hold"
                        ComponentType.FLOATING_BALL -> "Ball"
                    }
                    mappings.add(
                        KeyMapping(
                            id = newId,
                            hotkey = defaultLabel,
                            label = defaultLabel,
                            componentType = comp,
                            xRatio = 0.5f,
                            yRatio = 0.5f
                        )
                    )
                    statusMessage = "Componente $defaultLabel adicionado!"
                }
            )
        }

        selectedKeyForConfig?.let { targetKey ->
            if (targetKey.componentType == ComponentType.FPS_VIEW) {
                FpsSensConfigDialog(
                    settings = settings,
                    onDismiss = { selectedKeyForConfig = null },
                    onSave = { updatedSettings ->
                        selectedKeyForConfig = null
                        statusMessage = "Sensibilidade salva!"
                    }
                )
            } else {
                KeyConfigDialog(
                    keyMapping = targetKey,
                    onDismiss = { selectedKeyForConfig = null },
                    onSave = { updatedKey ->
                        val idx = mappings.indexOfFirst { it.id == updatedKey.id }
                        if (idx >= 0) mappings[idx] = updatedKey
                        selectedKeyForConfig = null
                        statusMessage = "Tecla ${updatedKey.hotkey} configurada!"
                    },
                    onDelete = {
                        mappings.removeAll { it.id == targetKey.id }
                        selectedKeyForConfig = null
                        statusMessage = "Tecla removida!"
                    }
                )
            }
        }
    }
}

@Composable
fun HudBarAction(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isHighlight: Boolean = false
) {
    Box(
        modifier = modifier
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isHighlight) AccentCyan else Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 13.sp
        )
    }
}

@Composable
fun KeyNodeView(
    keyMapping: KeyMapping,
    indicatorColor: Color,
    indicatorAlpha: Float,
    isEditing: Boolean,
    onClick: () -> Unit,
    onDrag: (Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val dragModifier = if (isEditing) {
        Modifier.pointerInput(Unit) {
            detectDragGestures { change, dragAmount ->
                change.consume()
                onDrag(dragAmount)
            }
        }
    } else Modifier

    when (keyMapping.componentType) {
        ComponentType.JOYSTICK -> {
            // WASD 4-arrow joystick control pad (as in Screenshot 4)
            Box(
                modifier = modifier
                    .then(dragModifier)
                    .size(90.dp)
                    .clickable { onClick() },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val c = Offset(size.width / 2, size.height / 2)
                    val stroke = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)

                    // Draw 4 directional arrows (WASD)
                    val blueColor = PrimaryBlueGlow.copy(alpha = indicatorAlpha)

                    // North
                    drawLine(blueColor, c, Offset(c.x, 10f), strokeWidth = 3f)
                    drawPath(
                        Path().apply {
                            moveTo(c.x - 12f, 22f)
                            lineTo(c.x, 6f)
                            lineTo(c.x + 12f, 22f)
                        },
                        blueColor,
                        style = stroke
                    )
                    // South
                    drawLine(blueColor, c, Offset(c.x, size.height - 10f), strokeWidth = 3f)
                    drawPath(
                        Path().apply {
                            moveTo(c.x - 12f, size.height - 22f)
                            lineTo(c.x, size.height - 6f)
                            lineTo(c.x + 12f, size.height - 22f)
                        },
                        blueColor,
                        style = stroke
                    )
                    // West
                    drawLine(blueColor, c, Offset(10f, c.y), strokeWidth = 3f)
                    drawPath(
                        Path().apply {
                            moveTo(22f, c.y - 12f)
                            lineTo(6f, c.y)
                            lineTo(22f, c.y + 12f)
                        },
                        blueColor,
                        style = stroke
                    )
                    // East
                    drawLine(blueColor, c, Offset(size.width - 10f, c.y), strokeWidth = 3f)
                    drawPath(
                        Path().apply {
                            moveTo(size.width - 22f, c.y - 12f)
                            lineTo(size.width - 6f, c.y)
                            lineTo(size.width - 22f, c.y + 12f)
                        },
                        blueColor,
                        style = stroke
                    )
                }

                Text(
                    text = "WASD",
                    color = Color.White.copy(alpha = indicatorAlpha),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        ComponentType.FPS_VIEW -> {
            // Blue circle "View" camera tracker
            Box(
                modifier = modifier
                    .then(dragModifier)
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF3B82F6).copy(alpha = indicatorAlpha))
                    .border(2.dp, Color.White.copy(alpha = indicatorAlpha), CircleShape)
                    .clickable { onClick() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "View",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        ComponentType.FLOATING_BALL -> {
            // Floating ball display
            Box(
                modifier = modifier
                    .then(dragModifier)
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFD97706).copy(alpha = indicatorAlpha))
                    .clickable { onClick() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Floating\nball\ndisplay",
                    color = Color.White,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    lineHeight = 9.sp
                )
            }
        }

        else -> {
            // Standard rounded button badge matching Screenshot 4 (Mouse 2, R, 1, 2, Space, etc.)
            val isMouseKey = keyMapping.hotkey.contains("Mouse", ignoreCase = true)
            val isYellowCaps = keyMapping.hotkey.contains("Caps", ignoreCase = true)

            Box(
                modifier = modifier
                    .then(dragModifier)
                    .size(if (keyMapping.hotkey.length > 5) 44.dp else 36.dp)
                    .clip(CircleShape)
                    .background(
                        if (isYellowCaps) Color(0xFFCA8A04).copy(alpha = indicatorAlpha)
                        else Color.Black.copy(alpha = (indicatorAlpha * 0.85f))
                    )
                    .border(
                        1.5.dp,
                        if (isYellowCaps) Color(0xFFFACC15).copy(alpha = indicatorAlpha)
                        else indicatorColor.copy(alpha = indicatorAlpha),
                        CircleShape
                    )
                    .clickable { onClick() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = keyMapping.hotkey,
                    color = if (isYellowCaps) Color.Black else indicatorColor.copy(alpha = indicatorAlpha),
                    fontSize = if (keyMapping.hotkey.length > 5) 8.5.sp else 10.5.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    maxLines = 2,
                    lineHeight = 10.sp
                )
            }
        }
    }
}

@Composable
fun GameBackgroundCanvas(
    backgroundType: Int,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        when (backgroundType) {
            0 -> {
                // Tactical Battle Arena background (Dark battleground with crosshairs and horizon)
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0F172A),
                            Color(0xFF1E293B),
                            Color(0xFF0D1322)
                        )
                    )
                )

                // Simulated game structures & battle map silhouettes
                drawCircle(
                    color = Color(0x22F59E0B),
                    radius = size.width * 0.35f,
                    center = Offset(size.width * 0.5f, size.height * 0.6f)
                )

                // Grid terrain
                val gridStep = 60f
                for (x in 0..(size.width / gridStep).toInt()) {
                    drawLine(
                        color = Color(0x1138BDF8),
                        start = Offset(x * gridStep, size.height * 0.5f),
                        end = Offset(x * gridStep, size.height),
                        strokeWidth = 1f
                    )
                }

                // Center crosshair (Simulating FPS Battle Royale)
                val c = Offset(size.width * 0.5f, size.height * 0.5f)
                val chColor = Color(0x88FFFFFF)
                drawLine(chColor, Offset(c.x - 20f, c.y), Offset(c.x - 6f, c.y), strokeWidth = 2f)
                drawLine(chColor, Offset(c.x + 6f, c.y), Offset(c.x + 20f, c.y), strokeWidth = 2f)
                drawLine(chColor, Offset(c.x, c.y - 20f), Offset(c.x, c.y - 6f), strokeWidth = 2f)
                drawLine(chColor, Offset(c.x, c.y + 6f), Offset(c.x, c.y + 20f), strokeWidth = 2f)
                drawCircle(Color(0xAAEF4444), radius = 2f, center = c)
            }

            1 -> {
                // Golden Lobby (Inspired by Screenshot 2/3/4 Free Fire Crossover lobby with warm amber glow)
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFB45309),
                            Color(0xFF78350F),
                            Color(0xFF1C1917)
                        ),
                        center = Offset(size.width * 0.4f, size.height * 0.4f),
                        radius = size.width * 0.7f
                    )
                )

                // Stylized clouds / flame accents
                drawCircle(
                    color = Color(0x33FBBF24),
                    radius = 160f,
                    center = Offset(size.width * 0.2f, size.height * 0.3f)
                )
            }

            else -> {
                // Tactical Blueprint Grid
                drawRect(Color(0xFF070B14))
                val step = 40f
                for (x in 0..(size.width / step).toInt()) {
                    drawLine(Color(0x1406B6D4), Offset(x * step, 0f), Offset(x * step, size.height), 1f)
                }
                for (y in 0..(size.height / step).toInt()) {
                    drawLine(Color(0x1406B6D4), Offset(0f, y * step), Offset(size.width, y * step), 1f)
                }
            }
        }
    }
}
