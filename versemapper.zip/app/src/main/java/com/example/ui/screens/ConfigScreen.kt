package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppSettings
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.DarkCard
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ConfigScreen(
    settings: AppSettings,
    onOpenActivation: () -> Unit,
    onOpenFpsSens: () -> Unit,
    onOpenBasicSettings: () -> Unit,
    onOpenRecoil: () -> Unit,
    onOpenPrompt: () -> Unit,
    onAccountInfo: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "CONFIGURAÇÕES DO SISTEMA",
            color = AccentCyan,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Main options list matching Screenshot 11
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                ConfigListItem(
                    icon = Icons.Default.Person,
                    title = "Account Info",
                    subtitle = "ID: VM-892041 · VIP Vitalício Ativo",
                    onClick = onAccountInfo
                )

                ConfigDivider()

                ConfigListItem(
                    icon = Icons.Default.Wifi,
                    title = "Activation Mode",
                    badge = "${settings.activationMethod.displayName} >",
                    onClick = onOpenActivation
                )

                ConfigDivider()

                ConfigListItem(
                    icon = Icons.Default.FlashOn,
                    title = "Activation assistant",
                    badge = if (settings.isActivated) "ATIVADO" else "REQUER ATIVAÇÃO",
                    isWarning = !settings.isActivated,
                    onClick = onOpenActivation
                )

                ConfigDivider()

                ConfigListItem(
                    icon = Icons.Default.Security,
                    title = "Permissions management",
                    subtitle = "Sobreposição de Tela & Acessibilidade concedidos",
                    onClick = { }
                )

                ConfigDivider()

                ConfigListItem(
                    icon = Icons.Default.HelpOutline,
                    title = "Official Discord",
                    badge = "CLIQUE AQUI",
                    onClick = { }
                )

                ConfigDivider()

                ConfigListItem(
                    icon = Icons.Default.Lock,
                    title = "MELHOR ORG \uD83D\uDC51",
                    badge = "VERSE TEAM VIP",
                    onClick = { }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "CALIBRAÇÃO DE HARDWARE & JOGABILIDADE",
            color = AccentCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                ConfigListItem(
                    icon = Icons.Default.Tune,
                    title = "Sensibilidade FPS (Eixos X & Y)",
                    subtitle = "X: ${settings.sensX.toInt()} · Y: ${settings.sensY.toInt()} · Contra-aceleração: ${settings.counterAcceleration}",
                    onClick = onOpenFpsSens
                )

                ConfigDivider()

                ConfigListItem(
                    icon = Icons.Default.Mouse,
                    title = "Configurações Básicas do Mouse",
                    subtitle = "Taxa: ${settings.mousePollingRateHz} · Tamanho: ${settings.cursorSize} · Estilo: ${settings.cursorStyle}",
                    onClick = onOpenBasicSettings
                )

                ConfigDivider()

                ConfigListItem(
                    icon = Icons.Default.Tune,
                    title = "Configuração do Recuo (Anti-Recoil)",
                    subtitle = "Força Vertical: ${settings.recoilVerticalForce.toInt()}% · Atraso: ${settings.recoilDelayMs.toInt()}ms",
                    onClick = onOpenRecoil
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // PROMPT MASTER & ESPECIFICAÇÕES BUTTON
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0F172A))
                .border(1.5.dp, PrimaryBlueGlow, RoundedCornerShape(12.dp))
                .clickable { onOpenPrompt() }
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = null,
                        tint = AccentCyan,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Prompt Mestre & Arquitetura",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Ver e copiar o prompt completo do Versemapper",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = AccentCyan
                )
            }
        }
    }
}

@Composable
fun ConfigListItem(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    badge: String? = null,
    isWarning: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isWarning) AccentAmber else AccentCyan,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                subtitle?.let {
                    Text(
                        text = it,
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        badge?.let {
            Text(
                text = it,
                color = if (isWarning) AccentAmber else Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        } ?: Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
fun ConfigDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(Color(0xFF1E293B))
    )
}
