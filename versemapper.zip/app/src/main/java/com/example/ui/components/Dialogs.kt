package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ControlCamera
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Swipe
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.SampleData
import com.example.model.ActivationMethod
import com.example.model.AppSettings
import com.example.model.ComponentType
import com.example.model.KeyMapping
import com.example.model.KeyTriggerType
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

// 1. ADD COMPONENTE DIALOG (Screenshot 3)
@Composable
fun AddComponentDialog(
    onDismiss: () -> Unit,
    onSelectComponent: (ComponentType) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.85f)
                .border(2.dp, PrimaryBlueGlow, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xF20B101D)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ADD COMPONENTE",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Select a component to place on keymap",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fechar",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(ComponentType.values()) { comp ->
                        val icon: ImageVector = when (comp) {
                            ComponentType.TOUCH -> Icons.Default.TouchApp
                            ComponentType.SWIPE -> Icons.Default.Swipe
                            ComponentType.MOUSE_SCROLL -> Icons.Default.Mouse
                            ComponentType.MACRO -> Icons.Default.FlashOn
                            ComponentType.JOYSTICK -> Icons.Default.OpenWith
                            ComponentType.FPS_VIEW -> Icons.Default.ControlCamera
                            ComponentType.FREE_LOOK -> Icons.Default.Visibility
                            ComponentType.MOUSE_PICK -> Icons.Default.Mouse
                            ComponentType.LONG_PRESS -> Icons.Default.TouchApp
                            ComponentType.FLOATING_BALL -> Icons.Default.ControlCamera
                        }

                        Box(
                            modifier = Modifier
                                .height(95.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF131D31))
                                .border(1.dp, PrimaryBlueGlow.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .clickable {
                                    onSelectComponent(comp)
                                    onDismiss()
                                }
                                .padding(10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = comp.title,
                                    tint = AccentCyan,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = comp.title,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = comp.description,
                                    color = TextMuted,
                                    fontSize = 9.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 2. KEY CONFIGURATION DIALOG (Screenshot 2)
@Composable
fun KeyConfigDialog(
    keyMapping: KeyMapping,
    onDismiss: () -> Unit,
    onSave: (KeyMapping) -> Unit,
    onDelete: () -> Unit
) {
    var selectedType by remember { mutableStateOf(keyMapping.triggerType) }
    var tapDuration by remember { mutableFloatStateOf(keyMapping.tapDurationMs) }
    var resetViewFinger by remember { mutableStateOf(keyMapping.resetViewFinger) }
    var resetJoystick by remember { mutableStateOf(keyMapping.resetJoystick) }
    var hotkeyText by remember { mutableStateOf(keyMapping.hotkey) }
    var isListeningKey by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .border(1.5.dp, Color(0xFF2E3D59), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.Start
            ) {
                // Header
                Text(
                    text = "Configuration",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "INTRODUÇÃO",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Simulates screen touching with different types to choose from",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Hotkey Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Hotkey: $hotkeyText",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Button(
                        onClick = {
                            isListeningKey = !isListeningKey
                            if (isListeningKey) {
                                hotkeyText = "Pressione Tecla..."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (isListeningKey) "OUVINDO..." else "ADD",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                // Quick keys suggestion when binding
                if (isListeningKey) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Selecione uma tecla física ou toque rápido:",
                        color = AccentCyan,
                        fontSize = 11.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Mouse 1", "Mouse 2", "Space", "Shift", "E", "F", "Q", "1").forEach { k ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF222C40))
                                    .clickable {
                                        hotkeyText = k
                                        isListeningKey = false
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(k, color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF1E2536)))
                Spacer(modifier = Modifier.height(16.dp))

                // Types bar (Screenshot 2: PRESSIONE | TOQUE | TOQUE FRENÉTICO | TOQUE PARA BAIXO/CIMA | GATILHO DE ALTA)
                Text(text = "Types", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF4B5563)),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    KeyTriggerType.values().forEach { t ->
                        val isSelected = selectedType == t
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .background(if (isSelected) Color.White else Color.Transparent)
                                .clickable { selectedType = t }
                                .padding(2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = t.displayName,
                                color = if (isSelected) Color.Black else Color.White,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                lineHeight = 10.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tap Duration Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Tap Duration(ms)", color = Color.White, fontSize = 13.sp)
                    Text(text = "${String.format("%.1f", tapDuration)} ms", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = tapDuration,
                    onValueChange = { tapDuration = it },
                    valueRange = 0.5f..50.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFDE68A),
                        inactiveTrackColor = Color(0xFF374151)
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF1E2536)))
                Spacer(modifier = Modifier.height(12.dp))

                // Reset switches
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Reset Controlling View Finger", color = Color.White, fontSize = 13.sp)
                    Switch(
                        checked = resetViewFinger,
                        onCheckedChange = { resetViewFinger = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PrimaryBlueGlow
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Reset Joystick", color = Color.White, fontSize = 13.sp)
                    Switch(
                        checked = resetJoystick,
                        onCheckedChange = { resetJoystick = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PrimaryBlueGlow
                        )
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onDelete()
                            onDismiss()
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentRed),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("EXCLUIR", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            onSave(
                                keyMapping.copy(
                                    hotkey = hotkeyText,
                                    label = hotkeyText,
                                    triggerType = selectedType,
                                    tapDurationMs = tapDuration,
                                    resetViewFinger = resetViewFinger,
                                    resetJoystick = resetJoystick
                                )
                            )
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("FECHAR & SALVAR", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// 3. FPS SENSITIVITY CONFIGURATION DIALOG (Screenshot 1)
@Composable
fun FpsSensConfigDialog(
    settings: AppSettings,
    onDismiss: () -> Unit,
    onSave: (AppSettings) -> Unit
) {
    var preventFreezing by remember { mutableStateOf(settings.preventViewFreezing) }
    var premiumSens by remember { mutableStateOf(settings.premiumSensitivity) }
    var counterAcc by remember { mutableFloatStateOf(settings.counterAcceleration) }
    var sensX by remember { mutableFloatStateOf(settings.sensX) }
    var sensY by remember { mutableFloatStateOf(settings.sensY) }
    var isLinked by remember { mutableStateOf(settings.isSensRatioLinked) }
    var hotkey by remember { mutableStateOf(settings.switchSensHotkey) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .border(1.5.dp, Color(0xFF2E3D59), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Configuration",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Freefire prevent view freezing
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Versemapper prevent view freezing\n(Versemapper 3.0 new feature!)",
                        color = Color(0xFFFACC15),
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = preventFreezing,
                        onCheckedChange = { preventFreezing = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PrimaryBlueGlow
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Premium Sensitivity
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Versemapper Premium Sensitivity\n(better than pc emulator)",
                        color = Color(0xFFFACC15),
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = premiumSens,
                        onCheckedChange = { premiumSens = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PrimaryBlueGlow
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Counter acceleration
                Text(
                    text = "Versemapper counter acceleration (Higher=heavy, lower=more acceleration) (VIP)",
                    color = Color(0xFFFACC15),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "${String.format("%.1f", counterAcc)}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = counterAcc,
                    onValueChange = { counterAcc = it },
                    valueRange = 1.0f..30.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFDE68A),
                        inactiveTrackColor = Color(0xFF374151)
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF1E2536)))
                Spacer(modifier = Modifier.height(8.dp))

                // X sensitivity
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "X Axis", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = "${sensX.toInt()}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = sensX,
                    onValueChange = {
                        sensX = it
                        if (isLinked) sensY = it * 1.08f
                    },
                    valueRange = 50f..800f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFDE68A),
                        inactiveTrackColor = Color(0xFF374151)
                    )
                )

                // Link / Unlink icon
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .clip(CircleShape)
                        .background(Color(0xFF222C40))
                        .clickable { isLinked = !isLinked }
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = if (isLinked) Icons.Default.Link else Icons.Default.LinkOff,
                        contentDescription = "Link X/Y",
                        tint = if (isLinked) AccentCyan else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Y sensitivity
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Y Axis", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = "${sensY.toInt()}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = sensY,
                    onValueChange = {
                        sensY = it
                        if (isLinked) sensX = it / 1.08f
                    },
                    valueRange = 50f..800f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFDE68A),
                        inactiveTrackColor = Color(0xFF374151)
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Switch Sensitivity Hotkey
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Switch Sens Hotkey: $hotkey", color = Color.White, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { hotkey = "L-Alt" },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("ADD", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { hotkey = "Nenhum" },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("LIMPAR", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        onSave(
                            settings.copy(
                                preventViewFreezing = preventFreezing,
                                premiumSensitivity = premiumSens,
                                counterAcceleration = counterAcc,
                                sensX = sensX,
                                sensY = sensY,
                                isSensRatioLinked = isLinked,
                                switchSensHotkey = hotkey
                            )
                        )
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("FECHAR", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

// 4. MOSTRA HUD DIALOG (Screenshot 5)
@Composable
fun MostraHudDialog(
    settings: AppSettings,
    onDismiss: () -> Unit,
    onSave: (AppSettings) -> Unit
) {
    var showIndicator by remember { mutableStateOf(settings.showIndicator) }
    var selectedColorHex by remember { mutableStateOf(settings.indicatorColorHex) }
    var alphaVal by remember { mutableFloatStateOf(settings.indicatorAlpha) }

    val colorsList = listOf(
        0xFFFFFFFF to "Branco",
        0xFFEF4444 to "Vermelho",
        0xFF10B981 to "Verde",
        0xFF8B5CF6 to "Roxo",
        0xFFFACC15 to "Amarelo",
        0xFFF97316 to "Laranja",
        0xFF06B6D4 to "Ciano"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .border(1.5.dp, Color(0xFF2E3D59), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "MOSTRA HUD",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Show Indicator", color = Color.White, fontSize = 14.sp)
                    Switch(
                        checked = showIndicator,
                        onCheckedChange = { showIndicator = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PrimaryBlueGlow
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "Indicator Color", color = Color.White, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    colorsList.forEach { (colorVal, _) ->
                        val isSelected = selectedColorHex == colorVal
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(colorVal))
                                .border(
                                    2.dp,
                                    if (isSelected) Color.White else Color.Transparent,
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { selectedColorHex = colorVal }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Indicator Alpha", color = Color.White, fontSize = 14.sp)
                    Text(text = "${alphaVal.toInt()}%", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = alphaVal,
                    onValueChange = { alphaVal = it },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFDE68A),
                        inactiveTrackColor = Color(0xFF374151)
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "Indicator example", color = Color.White, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    val previewAlpha = (alphaVal / 100f).coerceIn(0.1f, 1f)
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(Color(0xFF374151).copy(alpha = previewAlpha))
                            .border(1.dp, Color(selectedColorHex).copy(alpha = previewAlpha)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, Color(selectedColorHex).copy(alpha = previewAlpha), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("A", color = Color(selectedColorHex).copy(alpha = previewAlpha), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(Color(0xFF1F2937).copy(alpha = previewAlpha))
                            .border(1.dp, Color(selectedColorHex).copy(alpha = previewAlpha)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, Color(selectedColorHex).copy(alpha = previewAlpha), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("B", color = Color(selectedColorHex).copy(alpha = previewAlpha), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        onSave(
                            settings.copy(
                                showIndicator = showIndicator,
                                indicatorColorHex = selectedColorHex,
                                indicatorAlpha = alphaVal
                            )
                        )
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("FECHAR", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

// 5. BASIC SETTINGS DIALOG (Screenshot 6)
@Composable
fun BasicSettingsDialog(
    settings: AppSettings,
    onDismiss: () -> Unit,
    onSave: (AppSettings) -> Unit
) {
    var showTouch by remember { mutableStateOf(settings.showTouchRipple) }
    var logoTrans by remember { mutableFloatStateOf(settings.logoTransparency) }
    var sensiCursor by remember { mutableFloatStateOf(settings.cursorSens) }
    var pollingRate by remember { mutableStateOf(settings.mousePollingRateHz) }
    var cursorSize by remember { mutableFloatStateOf(settings.cursorSize) }
    var cursorStyle by remember { mutableStateOf(settings.cursorStyle) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .border(1.5.dp, Color(0xFF2E3D59), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Basic Settings",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "Basic Settings", color = PrimaryBlueGlow, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "MOSTRAR TOQUE", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Switch(
                        checked = showTouch,
                        onCheckedChange = { showTouch = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PrimaryBlueGlow
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "TRANSPARÊNCIA DA LOGO DO VERSEMAPPER", color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    Text(text = "${logoTrans.toInt()}%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = logoTrans,
                    onValueChange = { logoTrans = it },
                    valueRange = 10f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFDE68A),
                        inactiveTrackColor = Color(0xFF374151)
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF1E2536)))
                Spacer(modifier = Modifier.height(12.dp))

                Text(text = "Mouse Settings", color = PrimaryBlueGlow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "SENSI DO CURSOR", color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                    Text(text = String.format("%.1f", sensiCursor), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = sensiCursor,
                    onValueChange = { sensiCursor = it },
                    valueRange = 0.5f..10.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFDE68A),
                        inactiveTrackColor = Color(0xFF374151)
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(text = "TAXA DE HZ DO MOUSE", color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF374151)),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf("500hz", "600hz", "800hz", "1000hz").forEach { hz ->
                        val isSelected = pollingRate == hz
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .background(if (isSelected) Color.White else Color.Transparent)
                                .clickable { pollingRate = hz },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = hz,
                                color = if (isSelected) Color.Black else Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "TAMANHO DO CURSOR", color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                    Text(text = String.format("%.1f", cursorSize), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = cursorSize,
                    onValueChange = { cursorSize = it },
                    valueRange = 3.0f..15.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFDE68A),
                        inactiveTrackColor = Color(0xFF374151)
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(text = "ESTILO DE CURSOR", color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF374151)),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf("OPÇÃO 1", "OPÇÃO 2", "OPÇÃO 3", "OPÇÃO 4", "Personalizado").forEach { op ->
                        val isSelected = cursorStyle == op
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .background(if (isSelected) Color.White else Color.Transparent)
                                .clickable { cursorStyle = op },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = op,
                                color = if (isSelected) Color.Black else Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        onSave(
                            settings.copy(
                                showTouchRipple = showTouch,
                                logoTransparency = logoTrans,
                                cursorSens = sensiCursor,
                                mousePollingRateHz = pollingRate,
                                cursorSize = cursorSize,
                                cursorStyle = cursorStyle
                            )
                        )
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("FECHAR", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

// 6. ACTIVATION MODAL (Screenshots 9 & 10)
@Composable
fun ActivationModal(
    currentMethod: ActivationMethod,
    isActivated: Boolean,
    onDismiss: () -> Unit,
    onSelectMethod: (ActivationMethod) -> Unit,
    onActivateSuccess: () -> Unit
) {
    var step by remember { mutableStateOf(1) } // 1: method selector, 2: 4-step wizard
    var selectedMethod by remember { mutableStateOf(currentMethod) }
    var activatingState by remember { mutableStateOf(isActivated) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.85f)
                .border(1.5.dp, Color(0xFF2E3D59), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header with close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "VERSEMAPPER ATIVAÇÃO",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Fechar", tint = Color.White)
                    }
                }

                if (step == 1) {
                    Text(
                        text = "Please select the activation method. If you want to change the activation method in the future, you can do so in the App by clicking on Config - Activation Mode.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ActivationMethod.values().forEach { method ->
                            val isSelected = selectedMethod == method
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) PrimaryBlue.copy(alpha = 0.3f) else Color(0xFF131D31))
                                    .border(
                                        1.dp,
                                        if (isSelected) PrimaryBlueGlow else Color(0xFF233047),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        selectedMethod = method
                                        onSelectMethod(method)
                                        step = 2
                                    }
                                    .padding(horizontal = 16.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = method.displayName,
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF1E293B))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = method.badge, color = AccentCyan, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Screenshot 10: 4-step wizard
                    Text(
                        text = "Método Selecionado: ${selectedMethod.displayName}",
                        color = AccentCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "1. Turn On \"Developer Options\" from System Settings",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "2. Turn On \"USB debugging\" from Developer Options",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "3. Wait For the Port Being Opened Automatically (Wireless socket)",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "4. Tap to Activate",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Button(
                                onClick = {
                                    activatingState = true
                                    onActivateSuccess()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (activatingState) AccentGreen else Color.White
                                ),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                if (activatingState) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ACTIVATED", color = Color.Black, fontWeight = FontWeight.Black)
                                } else {
                                    Text("TAP TO ACTIVATE", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(onClick = { step = 1 }) {
                            Text("Voltar Métodos", color = Color.White, fontSize = 12.sp)
                        }

                        Text(
                            text = "Assistir tutorial em vídeo",
                            color = AccentCyan,
                            fontSize = 12.sp,
                            textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline,
                            modifier = Modifier.clickable { }
                        )
                    }
                }
            }
        }
    }
}

// 7. RECOIL CONFIG DIALOG (Config do Recuo)
@Composable
fun RecoilConfigDialog(
    settings: AppSettings,
    onDismiss: () -> Unit,
    onSave: (AppSettings) -> Unit
) {
    var enabled by remember { mutableStateOf(settings.recoilCompensationEnabled) }
    var force by remember { mutableFloatStateOf(settings.recoilVerticalForce) }
    var delay by remember { mutableFloatStateOf(settings.recoilDelayMs) }
    var category by remember { mutableStateOf(settings.selectedWeaponCategory) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .border(1.5.dp, Color(0xFF2E3D59), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "CONFIG DO RECUO (ANTI-RECOIL)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Compensação Automática de Recuo", color = Color.White, fontSize = 13.sp)
                    Switch(
                        checked = enabled,
                        onCheckedChange = { enabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PrimaryBlueGlow
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(text = "Categoria da Arma:", color = AccentCyan, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("AR", "SMG", "SNIPER", "PISTOL").forEach { cat ->
                        val isSel = category.startsWith(cat)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSel) PrimaryBlue else Color(0xFF1F2937))
                                .clickable { category = cat }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(cat, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Força de Puxada Vertical (Y Pull-Down)", color = Color.White, fontSize = 13.sp)
                    Text(text = "${force.toInt()}%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = force,
                    onValueChange = { force = it },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFDE68A),
                        inactiveTrackColor = Color(0xFF374151)
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Atraso de Início (ms)", color = Color.White, fontSize = 13.sp)
                    Text(text = "${delay.toInt()} ms", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = delay,
                    onValueChange = { delay = it },
                    valueRange = 0f..500f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFDE68A),
                        inactiveTrackColor = Color(0xFF374151)
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        onSave(
                            settings.copy(
                                recoilCompensationEnabled = enabled,
                                recoilVerticalForce = force,
                                recoilDelayMs = delay,
                                selectedWeaponCategory = category
                            )
                        )
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("SALVAR", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// 8. MASTER PROMPT VIEWER DIALOG
@Composable
fun PromptViewerDialog(onDismiss: () -> Unit) {
    val clipboardManager = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.98f)
                .fillMaxHeight(0.92f)
                .border(2.dp, PrimaryBlueGlow, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF090D16)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PROMPT & ARQUITETURA VERSEMAPPER",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Prompt técnico e especificações para mobile keymapper",
                            color = AccentCyan,
                            fontSize = 11.sp
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Fechar", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable prompt code block
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = SampleData.masterPromptText,
                        color = Color(0xFFE2E8F0),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(SampleData.masterPromptText))
                            copied = true
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (copied) AccentGreen else PrimaryBlue
                        )
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (copied) "PROMPT COPIADO!" else "COPIAR PROMPT COMPLETO", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                    ) {
                        Text("FECHAR", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
