package com.example.model

data class GameProfile(
    val id: String,
    val name: String,
    val keyMappings: List<KeyMapping>
)

data class GameItem(
    val id: String,
    val title: String,
    val packageName: String,
    val category: String = "Ação / Tiro",
    val isInstalled: Boolean = true,
    val profiles: List<GameProfile> = emptyList(),
    val activeProfileId: String = "default"
)
