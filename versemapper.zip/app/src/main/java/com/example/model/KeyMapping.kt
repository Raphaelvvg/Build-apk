package com.example.model

enum class ComponentType(val title: String, val description: String) {
    TOUCH("Touch", "Toque simples na tela"),
    SWIPE("Swipe", "Gesto de arrasto direcional"),
    MOUSE_SCROLL("Mouse Scroll", "Rolagem da roda do mouse (U/D)"),
    MACRO("MACRO", "Sequência automática de toques"),
    JOYSTICK("Joystick", "Controle direcional analógico WASD"),
    FPS_VIEW("FPS View", "Controle de mira e visão pelo mouse"),
    FREE_LOOK("Free Look", "Visão 360 livre com atalho"),
    MOUSE_PICK("Mouse Pick", "Alternar ponteiro do mouse (suspensão)"),
    LONG_PRESS("Long Press", "Toque contínuo ao segurar tecla"),
    FLOATING_BALL("Floating Ball", "Menu flutuante rápido")
}

enum class KeyTriggerType(val displayName: String) {
    PRESSIONE("PRESSIONE"),
    TOQUE("TOQUE"),
    TOQUE_FRENETICO("TOQUE FRENÉTICO"),
    TOQUE_CIMA_BAIXO("TOQUE PARA BAIXO/CIMA"),
    GATILHO_ALTA("GATILHO DE ALTA")
}

data class KeyMapping(
    val id: String,
    val hotkey: String,
    val label: String,
    val componentType: ComponentType = ComponentType.TOUCH,
    val triggerType: KeyTriggerType = KeyTriggerType.TOQUE,
    var xRatio: Float, // 0f to 1f relative to screen width
    var yRatio: Float, // 0f to 1f relative to screen height
    val tapDurationMs: Float = 1.0f,
    val resetViewFinger: Boolean = false,
    val resetJoystick: Boolean = false,
    val macroSteps: String = ""
)
