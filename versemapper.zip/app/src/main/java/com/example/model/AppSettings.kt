package com.example.model

enum class ActivationMethod(val displayName: String, val badge: String) {
    WIRED("Wired/Computer activation", "ADB USB"),
    WIRELESS("Wireless activation", "Wi-Fi"),
    ROOT("Root activation", "Root"),
    SHIZUKU("Shizuku", "Recomendado"),
    SHIZUKU_LEGACY("Shizuku (Legacy Mode)", "Legacy")
}

data class AppSettings(
    // Activation
    val activationMethod: ActivationMethod = ActivationMethod.WIRELESS,
    val isActivated: Boolean = false,
    val wirelessPort: String = "41523",
    val pairingCode: String = "892041",

    // Connected hardware
    val isMouseConnected: Boolean = true,
    val isKeyboardConnected: Boolean = true,
    val deviceName: String = "G-Pro Wireless & Huntsman Mini",

    // Sensitivity & FPS View (Screenshot 1)
    val preventViewFreezing: Boolean = true,
    val premiumSensitivity: Boolean = true,
    val counterAcceleration: Float = 12.0f,
    val sensX: Float = 280f,
    val sensY: Float = 305f,
    val isSensRatioLinked: Boolean = false,
    val switchSensHotkey: String = "Caps",

    // Recoil (Config do Recuo)
    val recoilCompensationEnabled: Boolean = true,
    val recoilVerticalForce: Float = 42.0f,
    val recoilDelayMs: Float = 150f,
    val selectedWeaponCategory: String = "Fuzil de Assalto (AR)",

    // HUD Display / Mostra HUD (Screenshot 5)
    val showIndicator: Boolean = true,
    val indicatorColorHex: Long = 0xFFFFFFFF, // White, Red, Green, Purple, Yellow, Orange, Cyan
    val indicatorAlpha: Float = 90.0f, // 0 - 100

    // Basic Settings (Screenshot 6)
    val showTouchRipple: Boolean = true,
    val logoTransparency: Float = 100.0f,
    val cursorSens: Float = 3.0f,
    val mousePollingRateHz: String = "1000hz", // 500hz, 600hz, 800hz, 1000hz
    val cursorSize: Float = 7.0f,
    val cursorStyle: String = "OPÇÃO 3" // OPÇÃO 1, OPÇÃO 2, OPÇÃO 3, OPÇÃO 4, Personalizado
)
