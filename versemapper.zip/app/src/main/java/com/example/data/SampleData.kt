package com.example.data

import com.example.model.ComponentType
import com.example.model.GameItem
import com.example.model.GameProfile
import com.example.model.KeyMapping
import com.example.model.KeyTriggerType

object SampleData {

    val freeFireDefaultMappings = listOf(
        KeyMapping("ff_mouse2", "Mouse 2", "Mira", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.12f, 0.15f),
        KeyMapping("ff_win", "WIN", "Mapa", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.83f, 0.15f),
        KeyMapping("ff_r", "R", "Recarga", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.89f, 0.14f),
        KeyMapping("ff_1", "1", "Arma 1", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.85f, 0.22f),
        KeyMapping("ff_2", "2", "Arma 2", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.89f, 0.22f),
        KeyMapping("ff_3", "3", "Arma 3", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.93f, 0.22f),
        KeyMapping("ff_mouse1", "Mouse 1", "Atirar", ComponentType.TOUCH, KeyTriggerType.GATILHO_ALTA, 0.93f, 0.30f),
        KeyMapping("ff_tab", "TAB", "Mochila", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.93f, 0.39f),
        KeyMapping("ff_g", "G", "Granada", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.77f, 0.32f),
        KeyMapping("ff_t", "T", "Emote", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.73f, 0.49f),
        KeyMapping("ff_botaod", "BOTÃO D.", "Habilidade", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.94f, 0.49f),
        KeyMapping("ff_space", "Space", "Pular", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.94f, 0.60f),
        KeyMapping("ff_c", "C", "Agachar", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.94f, 0.70f),
        KeyMapping("ff_z", "Z", "Deitar", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.94f, 0.82f),
        KeyMapping("ff_botaoe", "BOTÃO E.", "Secundário", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.84f, 0.90f),
        KeyMapping("ff_scrollu", "Scroll-U", "Arma Prox", ComponentType.MOUSE_SCROLL, KeyTriggerType.TOQUE, 0.75f, 0.93f),
        KeyMapping("ff_scrolld", "Scroll-D", "Arma Ant", ComponentType.MOUSE_SCROLL, KeyTriggerType.TOQUE, 0.73f, 0.88f),
        KeyMapping("ff_lshift", "L-Shift", "Correr", ComponentType.LONG_PRESS, KeyTriggerType.PRESSIONE, 0.72f, 0.74f),
        KeyMapping("ff_view", "View", "Olhar FPS", ComponentType.FPS_VIEW, KeyTriggerType.TOQUE, 0.58f, 0.58f),
        KeyMapping("ff_lctrl", "L-Ctrl", "Suspender", ComponentType.MOUSE_PICK, KeyTriggerType.TOQUE, 0.68f, 0.94f),
        KeyMapping("ff_lalt", "L-Alt", "Olho Livre", ComponentType.FREE_LOOK, KeyTriggerType.PRESSIONE, 0.35f, 0.95f),
        KeyMapping("ff_joystick", "WASD", "Joystick", ComponentType.JOYSTICK, KeyTriggerType.PRESSIONE, 0.16f, 0.72f),
        KeyMapping("ff_caps", "Caps", "Trava Corrida", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.04f, 0.70f),
        KeyMapping("ff_b", "B", "Inventário", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.03f, 0.60f),
        KeyMapping("ff_4", "4", "Kit Médico", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.06f, 0.83f),
        KeyMapping("ff_floating", "Ball", "Display", ComponentType.FLOATING_BALL, KeyTriggerType.TOQUE, 0.24f, 0.17f)
    )

    val pubgDefaultMappings = listOf(
        KeyMapping("pubg_m1", "Mouse 1", "Disparo", ComponentType.TOUCH, KeyTriggerType.GATILHO_ALTA, 0.90f, 0.35f),
        KeyMapping("pubg_m2", "Mouse 2", "Mira ADS", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.85f, 0.50f),
        KeyMapping("pubg_joy", "WASD", "Movimentação", ComponentType.JOYSTICK, KeyTriggerType.PRESSIONE, 0.18f, 0.70f),
        KeyMapping("pubg_view", "View", "Controle Câmera", ComponentType.FPS_VIEW, KeyTriggerType.TOQUE, 0.60f, 0.50f),
        KeyMapping("pubg_space", "Space", "Pulo/Salto", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.92f, 0.65f),
        KeyMapping("pubg_c", "C", "Agachar", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.92f, 0.75f),
        KeyMapping("pubg_z", "Z", "Deitar", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.92f, 0.85f),
        KeyMapping("pubg_r", "R", "Recarregar", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.80f, 0.75f),
        KeyMapping("pubg_1", "1", "Fuzil 1", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.50f, 0.90f),
        KeyMapping("pubg_2", "2", "Fuzil 2", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.60f, 0.90f),
        KeyMapping("pubg_ctrl", "L-Ctrl", "Mouse Cursor", ComponentType.MOUSE_PICK, KeyTriggerType.TOQUE, 0.65f, 0.95f)
    )

    val codDefaultMappings = listOf(
        KeyMapping("cod_m1", "Mouse 1", "Tiro", ComponentType.TOUCH, KeyTriggerType.GATILHO_ALTA, 0.90f, 0.35f),
        KeyMapping("cod_m2", "Mouse 2", "Mira", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.86f, 0.45f),
        KeyMapping("cod_joy", "WASD", "Controle", ComponentType.JOYSTICK, KeyTriggerType.PRESSIONE, 0.18f, 0.70f),
        KeyMapping("cod_view", "View", "FPS Look", ComponentType.FPS_VIEW, KeyTriggerType.TOQUE, 0.58f, 0.55f),
        KeyMapping("cod_f", "F", "Operador", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.88f, 0.60f),
        KeyMapping("cod_c", "C", "Slide / Crouch", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.92f, 0.72f),
        KeyMapping("cod_space", "Space", "Jump", ComponentType.TOUCH, KeyTriggerType.TOQUE, 0.92f, 0.82f)
    )

    val initialGames = listOf(
        GameItem(
            id = "ff_max",
            title = "Free Fire MAX",
            packageName = "com.dts.freefiremax",
            category = "Battle Royale",
            profiles = listOf(
                GameProfile("default", "Preset Padrão PRZ / Verse", freeFireDefaultMappings),
                GameProfile("rush", "Rushador 3 Dedos", freeFireDefaultMappings.take(15)),
                GameProfile("sniper", "Sniper AWM Rápida", freeFireDefaultMappings)
            )
        ),
        GameItem(
            id = "pubg_mobile",
            title = "PUBG MOBILE",
            packageName = "com.tencent.ig",
            category = "Battle Royale",
            profiles = listOf(
                GameProfile("default", "Padrão Tático", pubgDefaultMappings)
            )
        ),
        GameItem(
            id = "cod_mobile",
            title = "Call of Duty: Mobile",
            packageName = "com.activision.callofduty.shooter",
            category = "FPS / Multiplayer",
            profiles = listOf(
                GameProfile("default", "Multijogador Competitivo", codDefaultMappings)
            )
        ),
        GameItem(
            id = "blood_strike",
            title = "Blood Strike",
            packageName = "com.netease.bloodstrike",
            category = "Fast FPS",
            profiles = listOf(
                GameProfile("default", "Rush Ultra Fluido", freeFireDefaultMappings.take(18))
            )
        ),
        GameItem(
            id = "genshin",
            title = "Genshin Impact",
            packageName = "com.miHoYo.GenshinImpact",
            category = "RPG / Ação",
            profiles = listOf(
                GameProfile("default", "Exploração & Combate", freeFireDefaultMappings.take(12))
            )
        )
    )

    val masterPromptText = """
# PROMPT MESTRE PARA DESENVOLVIMENTO DO MAPEADOR "VERSEMAPPER"
## Mapeador de Teclado e Mouse para Celular (Android) com Injeção de Toque e HUD Flutuante

Você é um Engenheiro Sênior de Sistemas Especialista em Android NDK, Input Injection e Game Tools.
Sua missão é projetar e implementar o software **Versemapper**, um aplicativo nativo para Android que permite conectar teclado e mouse via USB (OTG) ou Bluetooth e mapear teclas físicas para eventos de toque digital (Multi-touch) na tela do smartphone sem necessidade de banimento.

---

### 1. ARQUITETURA PRINCIPAL DO SISTEMA
1. **Camada de Captura de Entrada (Input Capture)**:
   - Captura eventos brutos de teclado (`KeyEvent`) e mouse (`MotionEvent`, incluindo delta de movimento do mouse relativo `AXIS_RELATIVE_X` e `AXIS_RELATIVE_Y`).
   - Captura de botões do mouse: Esquerdo (`BUTTON_PRIMARY`), Direito (`BUTTON_SECONDARY`), Botão da Roda (`BUTTON_TERTIARY`), Botões laterais/avançar/voltar (`BUTTON_BACK`, `BUTTON_FORWARD`).
   - Pointer Capture API (`requestPointerCapture()`) para capturar mouse ilimitado sem que a seta saia da tela.

2. **Camada de Injeção de Toques (Touch Injection Engine)**:
   - **Modo Shizuku (Sem Root)**: Usa a API Shizuku / `IInputManager` do Android para injetar `injectMotionEvent` em nível de sistema com latência abaixo de 2ms.
   - **Modo Depuração Sem Fio (Wireless Debugging / ADB)**: Estabelece socket local com o daemon adbd do Android (`adb shell sendevent` ou socket com binário nativo pré-compilado em C++).
   - **Modo Root**: Acesso direto a nós do kernel `/dev/input/event*` usando `uinput` virtual device para simular touchscreen capacitivo indetectável.

3. **Camada de Sobreposição Visual (HUD Overlay)**:
   - Janela de sobreposição usando `WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY`.
   - Modos:
     - **Modo Edição (Editar HUD)**: O overlay recebe eventos de toque, permitindo arrastar, redimensionar, configurar cada tecla mapeada.
     - **Modo Jogo (Digita & Jogar / Ativo)**: Overlay fica totalmente invisível aos toques do jogo (`FLAG_NOT_TOUCHABLE`), enquanto o daemon em segundo plano processa as teclas físicas e injeta os toques nas posições relativas configuradas.

---

### 2. COMPONENTES DE MAPEAMENTO SUPORTADOS
- **Touch (Toque)**: Pressionar a tecla injeta toque na coordenada (X, Y). Tipos de acionamento:
  - *PRESSIONE*: Toque contínuo enquanto a tecla estiver pressionada.
  - *TOQUE*: Toque rápido com duração configurável (`Tap Duration` em ms, ex: 1ms a 50ms).
  - *TOQUE FRENÉTICO (Rapid Fire / Macro Click)*: Disparos repetidos e automáticos em alta velocidade (ex: 20 cliques por segundo).
  - *TOQUE PARA BAIXO/CIMA*: Executa ação separada no KeyDown e KeyUp.
  - *GATILHO DE ALTA*: Prioridade de tempo real no pipeline de input.
- **Joystick (Movimentação WASD)**: Converte teclas W, A, S, D em movimento analógico circular de joystick na tela com suavização e deadzone.
- **FPS View (Trava de Mira / Câmera 3D)**: Converte o movimento relativo do mouse em gestos de arraste contínuo na área de visão do jogo. Possui:
  - Sensibilidade independente para os eixos X e Y (com trava de proporção opcional).
  - Algoritmo anti-travamento de visão (`Prevent View Freezing`).
  - Contra-aceleração configurável para estabilização de mira tipo emulador de PC.
  - Atalho de suspensão rápida (Mouse Pick / L-Ctrl ou Caps Lock) para soltar o cursor e usar inventário.
- **Mouse Scroll (Scroll-U / Scroll-D)**: Converte a rolagem do mouse para toques rápidos (ex: troca de armas).
- **Macro**: Permite gravar e encadear múltiplos toques e tempos (ex: Gel Rápido + Agachar + Tiro).
- **Free Look (Olho Livre)**: Tecla dedicada (ex: L-Alt) que aciona a visão de 360 graus sem mudar a direção do personagem.

---

### 3. INTERFACE E USABILIDADE
- **Dashboard / Launcher**:
  - Seleção de múltiplos jogos (Free Fire, PUBG, COD Mobile, Blood Strike, etc.).
  - Status em tempo real de periféricos (Mouse e Teclado Conectados/Desconectados).
  - Assistente de ativação integrado com diagnóstico passo a passo (Developer Options -> Wireless Debugging -> Pair).
- **Menu Lateral Flutuante em Arco (Radial Arc HUD)**:
  - Barra curva retrátil com indicadores LED azuis futuristas.
  - Atalhos rápidos: Editar HUD, Mostra HUD, Digita & Jogar, Macro, Config do Recuo, Importar/Exportar HUD.
- **Exportação e Compartilhamento**:
  - Exportação e importação de perfis de HUD em formato JSON e códigos curtos de compartilhamento.
""".trimIndent()
}
